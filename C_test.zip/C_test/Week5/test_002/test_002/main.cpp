//
//  main.cpp
//  test_002
//
//  Created by 刘畅 on 2016/12/21.
//  Copyright © 2016年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    
    int row = 0,rol = 0;
    cin >> row >> rol;
    int array[100][100]={0};
    
    for(int i=0;i<row;i++){
        for(int j=0;j<rol;j++){
            cin>>array[i][j];
        }
    }
    
    int x = 0, y = 0;
    for (int i = 0; i < row+rol-1; i++)//控制循环的次数  共行+列-1次
    {
        x = i > rol-1? i-rol+1 : 0;//判断x是在第一行还是第一列  如果是第一行  就让x=0,
                                   //如果是第一列 就让x为i-rol+1
        y = i-x;                   //????????????????????????????
        while (x <= row-1 && y >= 0)
        {
            cout << array[x][y] << endl;
            x++;
            y--;
        }
    }
    
    return 0;
}
