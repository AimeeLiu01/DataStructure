//
//  main.cpp
//  test_003
//
//  Created by 刘畅 on 2016/12/16.
//  Copyright © 2016年 刘畅. All rights reserved.
/*输入
 
 用一个字符串代表小朋友队列。字符串中只会出现两个字符（样例输入里用的是 括号但实际数据则不一定），分别代表小男孩和小女孩，首先出现的字符代表小男孩，另一个字符代表小女孩。小孩总数不超过100
 
 输出
 
 按小女孩编号顺序，顺序输出手拉手离开队列的小男孩和小女孩的编号对，每行一对编号，编号之间用一个空格分隔。
 
样例输入
((()(())())(()))
 样例输出
 2 3
 5 6
 4 7
 8 9
 1 10
 12 13
 11 14
 0 15
 */

#include<iostream>
#include<stdio.h>
using namespace std;

char children[101];
int boy = 0;//记录男生的数目
int couple = 0;//记录男女的数目
char m, f;//男，女


int process() {
    for (int i = 0; i < 2 * boy; i++) { //对所有的小孩进行循环
        bool stay = true;
        if (children[i] == m) {
            for (int j = i + 1; j < 2 * boy; j++) {
                if (children[j] == m)
                    break;//如果下一个还是男孩子， 那就跳出循环
                if (children[j] == f) {//如果下一个是女孩子
                    
                    children[i] = ' ';//将这两个孩子置为空，即该位置的小孩子已经离开
                    children[j] = ' ';//
                    cout << i <<' '<< j << endl;//输出这两个小孩子的编号
                    couple++;
                    stay = false;//约到了，就不用在这浪费时间了，所以把位子清空
                    break;
                }
            }
        }
        
        if (stay == false)
            break;//有人约到就跳出这层循环
    }
    
    if (couple != boy)//因为只考虑异性恋，所以如果情侣数目跟男生数目不相等，就证明还有男的是单身狗，所以继续递归
        process();
    return 0;
}



int main(){
    cin.getline(children, 101);
    m = children[0];//根据题意，无论第一个人长什么样，我们都把他当男的看
    for (int i = 0; i < 100; i++) {
        if (children[i] != m) {
            f = children[i];//不考虑有第三种性别的存在，所以长得跟男的不一样的，一律视为女的
            break;
        }
    }//children[i]这个数组是用来表示该小孩是男孩子还是女孩子
    for (int i = 0; i < 100; i++) {
        if (children[i] == m)
            boy++;//数数有多少个男生
    }
    //在进行匹配之间，我们已经知道每个位置是男孩子还是女孩子
    process();
    return 0;
}



















