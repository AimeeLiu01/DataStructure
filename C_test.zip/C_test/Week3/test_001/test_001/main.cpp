//
//  main.cpp
//  test_001
//
//  Created by 刘畅 on 2016/12/15.
//  Copyright © 2016年 刘畅. All rights reserved.
/*
 描述
 
 输入一个句子（一行），将句子中的每一个单词翻转后输出。
 
 输入
 只有一行，为一个字符串，不超过500个字符。单词之间以空格隔开。所谓单词指的是所有不包含空格的连续的字符。
 
 这道题请用cin.getline输入一行后再逐个单词递归处理。
 
 输出
 翻转每一个单词后的字符串，单词之间的空格需与原文一致。
 
 样例输入
 hello world
 样例输出
 olleh dlrow
 */

#include <iostream>
#include <ctype.h>
using namespace std;
char input[501];
int i = 0;//全局变量

int recur(){
    char c = input[i];
    i++;
    if(c==' '){
        return 1;
    }
    if(c!=' '&&c!='\0'){
        recur();
        cout << c;
    }
    return 1;
}//利用了递归的特性  倒着输出结果

int main(){
    cin.getline(input, 501);
    
    if(recur()==1)//只有最外面一层的recur函数才会返回值到这里，所以可以放心的打‘ ’
        cout<<' ';//第一步进行操作
    
    while (input[i] != '\0') {
        if(recur()==1){//每次遇到空格都会返回1，因此打印一个空格
            cout<<' ';
        }
    }//后面的进行循环
    
    if(input[i]=='\0'){
        cout<<endl;//最后输出换行符
        return 0;
    }//对最后的空格符进行处理
    

    
    
}