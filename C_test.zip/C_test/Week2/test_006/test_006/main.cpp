//
//  main.cpp
//  test_006
//
//  Created by 刘畅 on 2016/12/7.
//  Copyright © 2016年 刘畅. All rights reserved.
/*输入
 
 第一行一个数字n，n不超过100，表示有n*n的宿舍房间。
 
 接下来的n行，每行n个字符，’.’表示第一天该房间住着健康的人，’#’表示该房间空着，’@’表示第一天该房间住着得流感的人。
 
 接下来的一行是一个整数m，m不超过100.
 
 输出
 
 输出第m天，得流感的人数

 样例输入
 
 5
 
 ....#
 .#.@.
 .#@..
 #....
 .....
 
 4
 
 样例输出
 16
 
 */

#include <iostream>
using namespace std;
int f(char a[10][10],int n,int m){
    
    int i,j,k,sum;
    sum=0;
    for(k=1;k<=m;k++)//天数的循环
    {
        //传染
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                if(a[i][j]=='!')
                    a[i][j]='@';
            }
        }
    
      //欲传染
      for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
         {
            if(a[i][j]=='@')
            {
                if(i-1>=0&&a[i-1][j]=='.')       //上
                    a[i-1][j]='!';
                if(i+1<n&&a[i+1][j]=='.')        //下
                    a[i+1][j]='!';
                if(j-1>=0&&a[i][j-1]=='.')       //左
                    a[i][j-1]='!';
                if(j+1<n&&a[i][j+1]=='.')        //右
                    a[i][j+1]='!';
            }
         }
      }
    
    }

   for(i=0;i<n;i++)
   {
      for(j=0;j<n;j++)
     {
        if(a[i][j]=='@')
            sum++;
     }
   }
   printf("%d\n",sum);
    
   return 0;

}



int main(int argc, const char * argv[]) {
    
    int n, m;//其中n代表宿舍区的大小  m代表天数
    int i;
    char a[10][10];
    printf("请输入n\n");
    scanf("%d",&n);
    printf("请输入宿舍区\n");
    for(i=0;i<n;i++){
        scanf("%s",a[i]);
    }
    printf("请输入天数");
    scanf("%d",&m);
    f(a,n,m);
    return 0;
    
   
}
