//
//  main.cpp
//  test_001
//
//  Created by 刘畅 on 2016/11/25.
//  Copyright © 2016年 刘畅. All rights reserved.
//  编程题＃1：寻找下标
/*已知一个整数数组x[],其中的元素彼此都不相同。找出给定的数组中是否有一个元素满足x[i]=i的关系，数组下标从0开始。
 
 举例而言，如果x[]={-2,-1,7,3,0,8},则x[3] = 3,因此3就是答案。
 */

#include <iostream>
#include<vector>
using namespace std;



int main(int argc, const char * argv[]) {
    int n;
    cin>>n;
    vector<int> a(n);
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        if(a[i]==i){
            cout<<a[i]<<endl;
            return 1;
        }
    }
    
    
    cout<<"N"<<endl;
    return 0;
    
}
