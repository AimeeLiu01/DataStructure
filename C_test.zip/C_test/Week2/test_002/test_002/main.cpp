//
//  main.cpp
//  test_002
//
//  Created by 刘畅 on 2016/11/25.
//  Copyright © 2016年 刘畅. All rights reserved.
//编程题＃2：四大湖
/*思路：用计算机语言来表示四个人说的话
 *必须保证四个湖的排名不同
 *每个人说的话中只有一个为真
 */

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    
    int DT,HZ,PY,TH;
    bool flag = false;
    for(DT=1;DT<=4&&!flag;++DT){
        
        for(HZ=1;HZ<=4&&!flag;++HZ){
            if(DT==HZ) continue;
            
            else
                for (PY=1; PY<=4&&!flag; ++PY) {
                    if (PY==DT||PY==HZ)
                       continue;
                    
                    else{
                        TH=10-DT-HZ-PY;
                        if( ((DT==1)+(HZ==4)+(PY==3)==1)&&
                            ((DT==4)+(HZ==1)+(PY==2)+(TH==3)==1)&&
                            ((HZ==4)+(DT==3)==1)&&
                            ((DT==3)+(HZ==2)+(PY==1)+(TH==4)==1)){
                            
                            cout<<"洞庭湖第"<<DT<<"名\n洪泽湖第"<<HZ<<"名\n潘阳湖第"
                            <<PY<<"名\n太湖第"<<TH<<"名"<<endl;
                            
                            flag = true;
                        }
                        
                    }
                }
        }
    }
    return 0;
}
