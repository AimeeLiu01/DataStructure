//
//  main.c
//  test_004
//
//  Created by 刘畅 on 2016/11/29.
//  Copyright © 2016年 刘畅. All rights reserved.
/*读入一个格式为yyyy-mm-dd的日期（即年－月－日），
输出这个日期下一天的日期。可以假定输入的日期不早于1600-01-01，也不晚于2999-12-30。
 */

#include <stdio.h>


int main(void){
    int year,month,day;
    int dayTable[2][13]={
        {0,31,28,31,30,31,30,31,31,30,31,30,31},
        {0,31,29,31,30,31,30,31,31,30,31,30,31}
    };//用一个二维数组巧妙表示了所有的月份（包括闰年和非闰年）
    
    int isLeapYear, dayOfMonth;
    scanf("%d-%d-%d",&year,&month,&day);
    
    isLeapYear = (year%4 == 0 && year %100==0) || (year%400==0);//判断是否为闰年
    dayOfMonth = dayTable[isLeapYear][month];//计算每一个月的天数
    
    ++day;
    if(day>dayOfMonth){
        day = 1;
        ++month;
    }//天数超过，月份加
    if(month>12){
        month=1;
        ++year;
    }//月份超过，年份加
    
    printf("%d-%d-%d",year,month,day);
    return 0;
    
}
