//
//  main.cpp
//  PutApple
//
//  Created by 刘畅 on 2016/12/1.
//  Copyright © 2016年 刘畅. All rights reserved.
//当有m个苹果和n个盘子时，求有多少种方法
/*思路：当m<n时，f(m,n)=f(m,m)
 当m>=n时，分成有盘子空着和无盘子空着两种情况：
 有盘子空着时：f(m,n)=f(m,n-1)
 无盘子空着时：f(m,n)=f(m-n,n)
 */

#include <iostream>
using namespace std;



int count(int m,int n){
    if(m<=1||n<=1) return 1;
    if(m<n)
        return count(m,m);
    else
        return count(m,n-1)+count(m-n,n);
}

int main(int argc, const char * argv[]) {
    int apple, plant;
    cin>>apple>>plant;
    cout<<"共有"<<count(apple,plant)<<"种不同的方法"<<endl;
    return 0;
}
