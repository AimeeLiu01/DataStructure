//
//  main.cpp
//  struct
//
//  Created by 刘畅 on 2016/12/21.
//  Copyright © 2016年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;
struct student{
    char ID[10];
    int month;
    int day;
}student[100];

int main(int argc, const char * argv[]) {
    
    int i,j,k,n,flag,count[100]={0};
    cout<<"how many student?"<<endl;
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>student[i].ID>>student[i].month>>student[i].day;
    
    for(int m=1;m<=12;m++)
        for(int d=1;d<=31;d++){
            flag = 0; j = 0;
            for(int i=0;i<n;i++){
                if(student[i].month==m && student[i].day==d){
                    count[++j]=i;flag++;
                }//count用于记录生日相同的同学的学号
                
                if(flag>1){
                    cout<<m<<' '<<d<<' ';
                    for(k=1;k<=j;k++){
                        cout<<student[count[k]].ID<<" ";
                    }
                    cout<<endl;
                }
            }
            
        }
    return 0;
}
