//
//  main.cpp
//  notation
//
//  Created by 刘畅 on 2016/12/1.
//  Copyright © 2016年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int notation(){
    char str[10];
    cin>>str;
    switch (str[0]) {
            
        case '+':return notation()+notation();
        case '-':return notation()-notation();
        case '*':return notation()*notation();
        case '/':return notation()/notation();

        default:return atof(str);
            
    }
}
int main(int argc, const char * argv[]) {
    
    cout << notation()<<endl;
    
    
}
