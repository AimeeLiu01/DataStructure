//
//  main.cpp
//  pointer
//
//  Created by 刘畅 on 2016/12/4.
//  Copyright © 2016年 刘畅. All rights reserved.
//深入理解指针的含义  一些关于指针的操作

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    int iCount = 18;
    int *iPtr = &iCount;
    *iPtr=58;
    cout<<iCount<<endl;      //58
    cout<<iPtr<<endl;        //iPtr的地址   iCount变量的地址
    cout<<&iCount<<endl;     //iCount的地址
    cout<<*iPtr<<endl;;      //58
    cout<<&iPtr<<endl;       //指针变量的地址         和上边的地址不同
    return 0;
}
