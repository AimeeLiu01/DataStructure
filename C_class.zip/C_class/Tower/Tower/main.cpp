//
//  main.cpp
//  Tower
//
//  Created by 刘畅 on 2016/12/1.
//  Copyright © 2016年 刘畅. All rights reserved.

/*
 汉诺塔问题
 要实现move(n,A,B,C)
 首先：move(n-1,A,C,B)
 move from A to C
 move(n-1,B,A,C)
 */

#include <iostream>
using namespace std;


void move(int n,char x,char y,char z){
    
    if(n==1){
        cout<<"把一个盘子从"<<x<<"移到"<<z<<endl;
    }else{
        move(n-1,x,z,y);
        cout<<"把一个盘子从"<<x<<"移到"<<z<<endl;
        move(n-1,y,x,z);
    }
}

int main(int argc, const char * argv[]) {
    
    int n;
    cin>>n;
    move(n,'A','B','C');
    return 0;
   
}
