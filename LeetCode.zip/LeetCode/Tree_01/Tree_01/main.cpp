//
//  main.cpp
//  Tree_01
//
//  Created by 刘畅 on 2017/8/12.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <queue>
#include <map>
#include <vector>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x)
    :val(x),left(NULL),right(NULL){}
};

//0. 直接强行创建一颗属于自己的二叉树
TreeNode* createTree(){
    
    TreeNode *root = new TreeNode(0);
    TreeNode *node1 = new TreeNode(1);
    TreeNode *node2 = new TreeNode(2);
    TreeNode *node3 = new TreeNode(3);
    TreeNode *node4 = new TreeNode(4);
    TreeNode *node5 = new TreeNode(5);
    TreeNode *node6 = new TreeNode(6);
    TreeNode *node7 = new TreeNode(7);
    TreeNode *node8 = new TreeNode(8);
    root->left = node1;
    root->right = node2;
    node1->left = node3;
    node1->right = node4;
    node2->left = node5;
    node2->right = node6;
    node3->left = node7;
    node3->right = node8;
    return root;
    
    
}

//1. 将一个序列转化为一颗二叉树  不用循环 用的为递归的方法
TreeNode* changeToTree(int *a, int start, int size){
    
    if(a[start] == 0) return NULL;
    TreeNode *root = new TreeNode(a[start]);
   
    
    int lnode = 2 * start;
    int rnode = 2 * start + 1;
    if(lnode > size - 1)
        root->left = NULL;
    else
        root->left = changeToTree(a, lnode, size);
    if(rnode > size - 1)
        root->right = NULL;
    else
        root->right = changeToTree(a, rnode, size);
    return root;
}

//2. 前序遍历_递归方法
void PreOrderTraversal(TreeNode * root){
    
    if(root == NULL) return;
    cout<<root->val<<" ";
    PreOrderTraversal(root->left);
    PreOrderTraversal(root->right);
}

//3. 前序遍历_非递归方法
void PreOrderTraversal_Non(TreeNode *root){
    
    if(root == NULL) return;
    TreeNode *p = root;
    stack<TreeNode*> stack;
   
    //这里均为先进入循环 再进行入栈操作
    while (p || !stack.empty()) {
        if(p){
            cout<<p->val<<" ";
            stack.push(p);
            p = p->left;
        }
        else{
            p = stack.top();
            stack.pop();
            p = p->right;//利用栈中压入的左子树的结点（根结点） 现在来寻找右结点
        }
    }
}

//4. 中序遍历_递归方法
void InOrderTraversal(TreeNode *root){
    
    if(root == NULL) return;
    InOrderTraversal(root->left);
    cout<<root->val<<" ";
    InOrderTraversal(root->right);
}

//5. 中序遍历_非递归方法
void InOrderTraversal_Non(TreeNode* root){
    
    if(root == NULL) return;
    TreeNode *p = root;
    stack<TreeNode *> stack;
    
    while (p || !stack.empty()) {
        if(p){
            stack.push(p);
            p = p->left;
        }
        else{
            p = stack.top();
            stack.pop();
            cout<<p->val<<" ";
            p = p->right;
        }
    }
}

//6. 后序遍历_递归方法
void PostOrderTraversal(TreeNode *root){
    
    if(root == NULL) return;
    PostOrderTraversal(root->left);
    cout<<root->val<<" ";
    PostOrderTraversal(root->right);
    
}

//7. 后序遍历_非递归方法
void PostOrderTraversal_Non(TreeNode *root){
    
    if(root == NULL) return;
    
    TreeNode *p = root;
    stack<TreeNode *> stack;
    TreeNode *last = root;//我们可以保存最后一个访问的节点last，如果满足 (p->right==NULL && last ==p->left) || last==p->right，那么显然p的孩子都访问过了，接下来可以访问p
    
    stack.push(p);
    
    while (!stack.empty()) {
       
        p = stack.top();
        if((p->left == NULL && p->right == NULL) || (p->right == NULL && last == p->left) || last == p->right){
            
            cout<<p->val<<" ";
            last = p;
            stack.pop();
        }
        else{
            if(p->right)
                stack.push(p->right);
            if(p->left)
                stack.push(p->left);
        }
    }

}


//8. 层次遍历
void LevelTraversal(TreeNode *root){
    
    if(root == NULL)  return;
    TreeNode * p = root;
    queue<TreeNode*> queue;
    queue.push(p);
    
    while (!queue.empty()) {
        
        p = queue.front();
        queue.pop();
        cout<<p->val<<" ";
        if(p->left)
            queue.push(p->left);
        if(p->right)
            queue.push(p->right);
    
    }
}


//9. 树的深度优先搜索
void DepthFirstSearch(TreeNode *root){
    
    if(root == NULL)  return;
    TreeNode * q = root;
    stack<TreeNode*> stack;
    stack.push(q);
    
    while(!stack.empty()){
        q = stack.top();
        cout<<q->val<<endl;
        stack.pop();
        if(q->right)
            stack.push(q->right);
        if(q->left)
            stack.push(q->left);
    }
    
}

//10. 求二叉树中结点的个数
int getNumOfTree(TreeNode *root){
    
    if(root == NULL) return 0;
    return 1 + getNumOfTree(root->left) + getNumOfTree(root->right);
    
}

//11. 求二叉树的高度
int getHeightOfTree(TreeNode *root){
    
    if(root == NULL) return 0;
    if(root->left == NULL && root->right == NULL)
        return 1;
    int left = getHeightOfTree(root->left);
    int right = getHeightOfTree(root->right);
    
    return max(left,right) + 1;
    
}

//12. 交换二叉树的左右子树
TreeNode* changeLeftAndRightTree(TreeNode *root){
    
    if(root == NULL) return root;
    if(root->left == NULL && root->right == NULL) return root;
    
    TreeNode *temp;
    temp = root->right;
    root->right = root->left;
    root->left = temp;
    
    changeLeftAndRightTree(root->left);
    changeLeftAndRightTree(root->right);
    
    return root;
    
}

//13. 已知二叉树的前序，中序遍历序列，求后续遍历序列
void PostOrderFromPreAndInOrder(char *pre, char *in, int length){
    
    if(length == 0) return;
    TreeNode *root = new TreeNode(*pre);
    
    int rootIndex = 0;
    for(;rootIndex<length; rootIndex++){
        if(in[rootIndex] == root->val){
            break;
        }
    }
    
    //找到根结点所在位置之后，我们先递归左子树，再递归右子树
    PostOrderFromPreAndInOrder(pre+1, in, rootIndex);
    PostOrderFromPreAndInOrder(pre+rootIndex+1, in+rootIndex+1, length-rootIndex-1);
    cout<<root->val<<" ";
    return;
    
}

//14. 已知二叉树的中序和后序遍历序列，求其前序序列
void PreOrderFromInAndPostOrder(char *inorder, char *postorder, int length){
    
    if(length == 0) return;
    TreeNode *root = new TreeNode(*(postorder+length-1));
    
    int rootIndex = 0;
    for(; rootIndex < length; rootIndex++){
        if(inorder[rootIndex] == *(postorder+length-1)){
            break;
        }
    }
    
    cout<<root->val<<" ";
    //我们先遍历左子树，再遍历右子树
    PreOrderFromInAndPostOrder(inorder, postorder, rootIndex);
    PreOrderFromInAndPostOrder(inorder+rootIndex+1, postorder+rootIndex, length-rootIndex-1);
    
}

//15. 从树构造其线性表表示方法 例如：输入一棵树 [1，2，3，4]  给出其string的表示方法  1(2(4))(3)
string toStringFromTree(TreeNode *root){
    
    string result;
    if(root == NULL) return result;
    result += to_string(root->val);
    
    //不管左子树是否存在，均要输出符号
    
    if(root->left != NULL || root->right != NULL){
        result += "(";
        toStringFromTree(root->left);
        result += ")";
        
        //如果右子树不存在的话，就不需要输出其符号
        if(root->right){
            result += "(";
            toStringFromTree(root->right);
            result += ")";
        }
    }
    return result;
}


//16. 求二叉树每个结点的tilt(每个结点的左右子树的差值的和）
int findTilt(TreeNode *root){
    
    int res = 0;
    if(root == NULL) return 0;
    if(root->left == NULL && root->right == NULL)
        return 0;
    
    if(root->left != NULL && root->right != NULL){
        res += abs(root->left->val - root->right->val);
    }
    if(root->left == NULL && root->right != NULL){
        res += root->right->val;
    }
    if(root->left != NULL && root->right == NULL){
        res += root->left->val;
    }
    
    findTilt(root->left);
    findTilt(root->right);
    return res;
    
}

//17. 合并两颗二叉树 Merge two Binary Tree
TreeNode * mergeTwoTrees(TreeNode *t1, TreeNode *t2){
   
    if(t1 == NULL && t2 == NULL)
        return t1;
    if(t1 == NULL && t2 != NULL)
        return t2;
    if(t1 != NULL && t2 == NULL)
        return t1;
    
    if(t1 != NULL && t2 != NULL){
        t1->val += t2->val;
        t1->left = mergeTwoTrees(t1->left, t2->left);
        t1->right = mergeTwoTrees(t1->right, t2->right);
    }
    return t1;
    
}

//18. 判断两颗树是否为同一棵树
bool isSameTree(TreeNode * t1, TreeNode * t2){
    
    if(t1 == NULL && t2 == NULL)
        return true;
    if((t1 != NULL && t2 == NULL) || (t1 == NULL && t2 != NULL))
        return false;
    
    if(t1->val != t2->val) return false;
    
    bool left = isSameTree(t1->left, t2->left);
    bool right = isSameTree(t1->right, t2->right);
    
    return left&&right;
    
}


//19. 判断一棵树是否为另一棵树的子树 判断T是否是S的子树
bool isSubTree(TreeNode *s, TreeNode *t){
    
    bool res = false;
    if(s != NULL && t != NULL){
        if(t->val == s->val)
            res = isSameTree(t, s);
        if(!res)
            res = isSameTree(s->left, t);
        if(!res)
            res = isSameTree(s->right, t);
    }
    return res;
}


//20. 查找指定的结点
bool FindElemData(TreeNode *root, int data){
    
    if(root == NULL) return false;
    queue<TreeNode*> queue;
    
    TreeNode * p = root;
    queue.push(p);
    
    while (!queue.empty()) {
        p = queue.front();
        if(p->val == data){
            cout<<"True"<<endl;
            return true;
        }
        queue.pop();
        if(p->left)
            queue.push(p->left);
        if(p->right)
            queue.push(p->right);
    }
    
    cout<<"False"<<endl;
    return false;

}

//21. Average of Level in Binary Tree 求二叉树每层结点的平均值
vector<double> averageOfTree(TreeNode *root){
    
    vector<double> res;
    if(root == NULL) return res;
    
    queue<TreeNode*> queue;
    TreeNode *p = root;
    queue.push(p);
    
    while (!queue.empty()) {
        
        unsigned long n = queue.size();
        double sum = 0;
        
        for(int i = 0; i < n; i++){
            p = queue.front();
            queue.pop();
            sum += p->val;
            if(p->left)
                queue.push(p->left);
            if(p->right)
                queue.push(p->right);
        }
        res.push_back(sum/(double)n);
    }
    
    return res;
}

//22. Lowest Common Ancestor of Binary Search Tree 求最近的公共祖先
TreeNode * lowestCommonAncestor(TreeNode *root, TreeNode *p, TreeNode *q){
    
    if((p->val - root->val) * (q->val - root->val) < 0){
        return root;
    }
    else if(p->val - root->val > 0){
        return lowestCommonAncestor(root->right, p, q);
    }
    else
        return lowestCommonAncestor(root->left, p, q);
}


//23. 给定一个二叉树 求其中出现次数最多的元素

void findMap(TreeNode *root, map<int,int> map){
    
    if(root == NULL) return;
    map[root->val]++;
    if(root->left)
        findMap(root->left, map);
    if(root->right)
        findMap(root->right, map);
    
}


int findMode(TreeNode * root){
    
    if(root == NULL) return 0;
    map<int,int> mymap;
    findMap(root,mymap);
    int max = 0;
    
    for(auto it = mymap.begin(); it != mymap.end(); it++){
        if(it->second > max)
            max = it->second;
    }
    
    for(auto it = mymap.begin(); it != mymap.end(); it++){
        if(it->second == max)
            return it->first;
    }
    
    return 0;
}


//24. 给定一颗BST树，求其中第K大的元素 其中BST树按照前序遍历后的序列即为升序排列,首先用的是递归的方法
int KthSmallestElement(TreeNode * root,int k){
    
    if(root == NULL) return 0;
    int left = getNumOfTree(root->left);
    if(left + 1 == k)
        return root->val;
    else if(left + 1 > k)
        return KthSmallestElement(root->left, k);
    else
        return KthSmallestElement(root->right, k-left-1);
    
}

//25. 给定一颗BST树，我们进行中序遍历，第K个元素即可以找到
int KthSmallestElement_PostOrder(TreeNode *root,int k){
    
    TreeNode *p = root;
    stack<TreeNode*> stack;
    int cnt = 0;
    
    while (p || !stack.empty()) {
        if(p){
            stack.push(p);
            p = p->left;
        }
        else{
            p = stack.top();
            stack.pop();
            cnt++;
            if(cnt == k)
                return p->val;
            p = p->right;
            
        }
    }
    return 0;
}

//26. 将string转化为二叉树
TreeNode * str2tree(string s){
    
    if (s.empty())  return NULL;
    
    stack<TreeNode *> stack;
    for(int i = 0 ; i < s.size(); i++){
        int j = i;
        if(s[i] == ')')
            stack.pop();
        else if(s[i] >= '0' && s[i] <= '9'){
            while (i+1 < s.size() && s[i+1] >= '0' && s[i+1] <= '9')  i++;
            TreeNode *cur = new TreeNode(stoi(s.substr(j,i-j+1)));//找到这个值
            if(!stack.empty()){
                TreeNode *t = stack.top();
                if(!t->left)
                    t->left = cur;
                else
                    t->right = cur;
            }
            
            stack.push(cur);
            
        }
    }
    
    return stack.top();
}

//27. 求二叉树中是否有一条路径的和为给定的值
bool hasPathSum(TreeNode * root, int sum){
    if(root == NULL) return false;
    if(root->left == NULL && root->right ==NULL && root->val == sum) return true;
    return hasPathSum(root->left, sum-root->val) || hasPathSum(root->right, sum-root->val);
}

//28. 求二叉树中是否有路径的和为给定值  如果有的话打印出来
void pathSumHelp(TreeNode *root, int sum, vector<int> tmp, vector<vector<int>> &res){
    
    if(!root) return;
    if(root->left == NULL && root->right == NULL && root->val == sum){
        tmp.push_back(root->val);
        res.push_back(tmp);
        return;
    }
    tmp.push_back(root->val);
    pathSumHelp(root->left, sum-root->val, tmp, res);
    pathSumHelp(root->right, sum-root->val, tmp, res);
    
}

vector<vector<int>> pathSum(TreeNode * root, int sum){
    vector<vector<int>> result;
    vector<int> tmp;
    pathSumHelp(root, sum, tmp, result);
    return result;
}


//29. 将一个向量序列转化为二叉树  根结点为向量中的最大值  左子树为最大值左边的向量序列  右子树为最大值右边的向量序列
TreeNode* constructMaximumBinaryTree(vector<int>& nums) {
    
    int maxIndex = 0;
    for(int i = 0; i < nums.size(); i++){
        if(nums[i] > nums[maxIndex])
            maxIndex = i;
    }
    
    TreeNode *root = new TreeNode(nums[maxIndex]);
    if(maxIndex <= 0)
        root->left = NULL;
    else{
        vector<int> left = vector<int>(nums.begin(), nums.begin()+maxIndex);
        root->left =constructMaximumBinaryTree(left);
    }
    
    if(maxIndex >= nums.size()-1)
        root->right = NULL;
    else{
        vector<int> right = vector<int>(nums.begin()+maxIndex+1, nums.end());
        root->right = constructMaximumBinaryTree(right);
    }
    return root;
    
}

// 30. 寻找两个结点之间的最远距离
int height(TreeNode * root, int & diameter){
    if(root == NULL) return 0;
    int lh = height(root->left, diameter);
    int rh = height(root->right, diameter);
    diameter = max(diameter, lh+rh);
    return 1 + max(lh,rh);
}


int diameterOfBinaryTree(TreeNode * root){
    
    int diameter = 0;
    height(root, diameter);
    return diameter;
}



int main(int argc, const char * argv[]) {

    
    char* pre = "ACEFDG";
    char* in = "ECFAGD";
    PostOrderFromPreAndInOrder(pre, in, 6);
    cout<<endl;
    return 0;
    
    

    
}
