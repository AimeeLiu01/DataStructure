//
//  main.cpp
//  string003
//
//  Created by 刘畅 on 2017/5/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

int main(int argc, const char * argv[]) {
    
    
    string str1 = "yesterday once more";
    string str2 ("my heart go on");
    string str3 (str1, 6);
    string str4 (str1, 6, 3);
    
    char ch_music[] = {"Roly-Poly"};
    
    string str5 = ch_music;
    string str6 (ch_music);
    string str7 (ch_music,4);
    string str8 (10, 'i');
    string str9 (ch_music + 5, ch_music + 9);
    
    str9.~string();
    
    getchar();
    cout<<str1<<endl;
    return 0;

    
}
