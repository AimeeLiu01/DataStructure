//
//  main.cpp
//  Prim02
//
//  Created by 刘畅 on 2017/9/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//  这里我们是用邻接矩阵来表示图

#include <iostream>
#include <string>
using namespace std;

#define MaxEle 120
int map[MaxEle][MaxEle];
bool visited[MaxEle] = {false};
int low[MaxEle];//low值代表的是到当前点的最小距离

int prim(int n){
    int pos, min, result = 0;
    //从某点开始 分别标记和记录该值
    visited[1] = 1, pos = 1;//代表先访问第一个位置
   
    for(int j = 2; j <= n; j++){
        if(map[pos][j] == 0)
            low[j] = INT_MAX;
        else
            low[j] = map[pos][j];
    }//第一次给low数组赋值  以第一个位置为中心 向四周寻找最近的点
    
    for(int i = 1; i <= n-1; i++){
        
        min = INT_MAX;
        for(int j = 1; j <= n; j++){
            if(visited[j] == false && min > low[j]){
                min = low[j];
                pos = j;
            }
        }
        
        //标记该点
        visited[pos] = true;
        result += min;
        
        //更新low值
        for(int j = 1; j <= n; j++){
            if(visited[j] == false && low[j] > map[pos][j]){
                if(map[pos][j] != 0){
                    low[j] = map[pos][j];
                }
            }
        }//end for
        
    }//end for
    
    for (int i = 1; i <= n; i++) {
        cout<<low[i]<<" ";
    }
    cout<<endl;
    return result;
}


int main1(int argc, const char * argv[]) {
    
    int n;//代表这个图
    while (cin>>n) {
        memset(map, INT_MAX, sizeof(map));
        
        for(int i = 1; i != n+1; i++){
            for (int j = 1; j != n+1; j++) {
                int elem;
                cin>>elem;
                map[i][j] = map[j][i] = elem;
            }
        }
        
        int ans = prim(n);
        cout<<ans<<endl;
    }
    return 0;
}
