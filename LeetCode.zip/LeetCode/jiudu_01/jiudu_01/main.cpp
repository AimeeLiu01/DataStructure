//
//  main.cpp
//  jiudu_01
//
//  Created by 刘畅 on 2017/7/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;


int main() {
   
    char s[5];
    
    while (cin>>s) {
        for(int i = strlen(s)-1; i >=0 ;i--){
            cout<<s[i];
        }
        cout<<endl;
    }
    return 0;
}
