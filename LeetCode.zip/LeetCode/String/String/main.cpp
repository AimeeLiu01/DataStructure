//
//  main.cpp
//  String
//
//  Created by 刘畅 on 2017/8/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//  String‘s Code

#include <iostream>
#include <string>
#include <sstream>
using namespace std;

//1. 对输入的string中的每个单词进行倒置
string reverseEveryWords(string &s){
    
    for(int i = 0; i < s.length(); i++){
        while (i < s.size() && s[i] == ' ') i++;
        int j = i;
        while (j < s.size() && s[j] != ' ') j++;
        reverse(s.begin()+i, s.begin()+j);
        i = j + 1;
    }
    return s;
}

//2. 对输入的string中的单词进行倒排
void reverseAllWords(string &s) {
    
    istringstream is(s);
    s.clear();
    string tem;
    while(is >> tem)
        s = tem + " " + s;
    s = s.substr(0, s.size()-1);//因为尾部多了一个空格
}


//3. 对一个数字进行英语转化  转化为对应的单词

string digits[20] = {"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen"
    ,"Fifteen","Sixteen","Seventeen","Eightteen","Nineteen"};
string tens[10] = {"Zero","Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"};
string lions[4] = {" ","Thoustand","Millions","Billions"};

string lessThan1000(int num){
    
    string ret = "";
    int hundred = num/100;//百位数
    int rest = num%100;//两位数
    
    if(rest < 20)//如果后两位数<20
        ret = digits[rest];//直接进行转换
    else{
        ret = tens[rest/10];//十位数
        if(rest % 10)//个位数
            ret = ret + " " + digits[rest%10] ;//两位数的组成
    }
    
    if(hundred){//如果有百位数
        string tmp = digits[hundred] + " " + "Hundred";//转化为 ？百
        if(!rest)//后两位数不存在
            return tmp;
        else
            return tmp + " " + ret;//返回 百位数 + 两位数
    }
    
    return ret;
    
}

string numberToWords(int num){
    
    if(num == 0) return digits[0];
    if(num < 1000)
        return lessThan1000(num);
    
    int idx = 0;
    string ret = " ";
    for(;num > 0; num /= 100, idx++){
        
        if(num % 1000 == 0) continue; //代表后三位均为0 即000
        string tmp = lessThan1000(num%1000);
        if(ret != " ")
            ret = tmp + " " + lions[idx] + " " + ret;
        else
            ret = tmp + " " + lions[idx];//从后往前 每三位进行一次转化
    }
    return ret;
}




int main(int argc, const char * argv[]) {
    
    string st;
    getline(cin,st);
    //对这句话中的单词进行整体的逆序排列
    reverseAllWords(st);
    cout<<st<<endl;
    
    //对这句话中的每个单词进行倒序排列
    reverseEveryWords(st);
    cout<<st<<endl;
    
    cout<<endl;
    string result;
    result = numberToWords(2454565);
    cout << result<<endl;
    
    return 0;
}
