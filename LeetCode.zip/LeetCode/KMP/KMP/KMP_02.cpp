//
//  KMP_02.cpp
//  KMP
//  Amiee's code
//  Created by 刘畅 on 2017/8/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//  The second practice

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

void setIndex(string s, int * offsetIndex){
    
    offsetIndex[0] = -1;
    for(int i = 1; i < s.size(); i++){
        if(s[i] == s[offsetIndex[i-1]+1])
            offsetIndex[i] = offsetIndex[i-1] + 1;
        else
            offsetIndex[i] = -1;
    }
    
    //将其打印出来检查正确性
    for(int i = 0; i < s.size(); i++){
        cout<<offsetIndex[i]<<" ";
        cout<<endl;
    }
}

int main(){
    
    string str, substr;
    cin>>str>>substr;
    int * offIndex = new int[substr.size()];
    setIndex(substr, offIndex);
    
    int LengthS = str.length();
    int LengthP = substr.length();
    int index = 0, subIndex = 0, result;
    
    while (index < LengthS && subIndex < LengthP) {
        
        
        if(str[index] == substr[subIndex]){
            index++, subIndex++;
        }
        else{
            if(subIndex == 0)
                index++;
            else{
                subIndex = offIndex[subIndex-1] + 1;
            }
            
        }
    }
    
    //最后的失败条件
    if((subIndex < LengthP) || LengthP == 0){
        result = 0;
        cout<<"无法进行匹配。"<<endl;
        return result;
    }
    
    else{
        result = index - LengthP;
        cout<<"匹配成功，成功匹配的位置在："<< result <<endl;
        return result;
    }
      
    
}
