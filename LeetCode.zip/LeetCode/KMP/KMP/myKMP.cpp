//
//  myKMP.cpp
//  KMP
//
//  Created by 刘畅 on 2017/8/3.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
using namespace std;

void setOffsetIndex(string str , int* offsetIndex){
    //遍历字符串
    offsetIndex[0] = -1;
    for(int i = 1; i < str.size() ; i++){
        //和之前最大公共子序列的下一位相比
        if(str[i] == str[offsetIndex[i - 1] + 1]){
            //如果可以就让当前索引的最大子串变大
            offsetIndex[i] = offsetIndex[i-1] + 1;
        }else{
            //如果没有就把最大公共子串重置
            offsetIndex[i] = -1;
        }
    }
    
    //打印
    for (int i = 0; i < str.size(); ++i)
    {
        cout << offsetIndex[i] << endl;
    }
    
}

int main2(){
    
    string str,substr;
    cout<<"请输入字符串序列："<<endl;
    cin>>str;
    cout<<"请输入要匹配的字符串序列："<<endl;
    cin>>substr;
    //算出每一位目标子串的偏移量
    int* offsetIndex = new int[substr.size()];
    
    setOffsetIndex(substr, offsetIndex);
    
    
    int subIndex = 0, index = 0, result;//index表示在字符串上的游标 subindex表示在子字符串上的游标
    int lengthP = substr.size();
    int lengthS = str.size();
    
    while ((index < lengthS) && (subIndex < lengthP)) {
        if(substr[subIndex] == str[index])
            subIndex++,index++;
        else{
            if(subIndex == 0)
                index++;
            else
                subIndex = offsetIndex[subIndex-1]+1;
        }
    }
    
    if(subIndex < lengthP || lengthP == 0)
        result =  -1;
    else
        result =  index-lengthP;

    
    if(result == -1){
        cout<<"无法匹配～"<<endl;
    }
    else{
        cout<<"子字符串可以与字符串进行匹配，匹配的初始位置在："<<result<<endl;
    }
    
    return 0;
    
    
    
}




