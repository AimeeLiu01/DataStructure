//
//  main.cpp
//  dp05
//
//  Created by 刘畅 on 2017/5/14.
//  Copyright © 2017年 刘畅. All rights reserved.
/*
 案例5：
 背包问题，动态规划经典问题，一个背包有滴定的承重W，有N件物品，每件物品都有自己的价值，记录在数组V中，也都有自己的重量，记录在数组W中，每件物品只能选择要装入还是不装入背包，要求在不超过背包承重的前提下，选出的物品总价值最大。
 分析：假设物品编号从1到n，一件一件的考虑是否加入背包，假设dp[x][y]表示前x件物品，不超过重量y的时候的最大价值，枚举一下第x件物品的情况：
 情况1：如果选择了第x件物品，则前x-1件物品得到的重量不能超过y-w[x]。
 情况2：如果不选择第x件物品，则前x-1件物品得到的重量不超过y。
 所以dp[x][y]可能等于dp[x-1][y],也就是不取第x件物品的时候，价值和之前一样，也可能是dp[x-1][y-w[x]]+v[x],也就是拿第x件物品的时候，当然会获得第x件物品的价值。两种可能的选择中，应该选择价值较大的那个，也就是：
 dp[x][y] = max{dp[x-1][y],dp[x-1][y-w[x]]+v[x]}
 因此，对于dp矩阵来说，行数是物品的数量n，列数是背包的重量w，从左到右，从上到下，依次计算出dp值即可。
 */

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

int main(int argc, const char * argv[]) {
    
    //物品数量
    int n = 4;
    //背包承重
    int cap = 10;
    int v[4] = {42,12,40,25};
    int w[4] = {7,3,4,5};
    
    //二维动态规划表
    vector<int> p(cap+1,0);
    vector<vector<int>> dp(n+1,p);
    
    for(int i = 1; i <= n; i++){//枚举物品
        for(int j = 1; j < cap+1; j++){//枚举重量
            
            //判断 枚举的重量和 和 当前选择的物品重量 的关系
            //如果枚举的和大于等于选择物品 则需要判断是否选择当前物品
            if(j - w[i-1] >= 0)
                dp[i][j] = max(dp[i-1][j], dp[i-1][j-w[i-1]]+v[i-1]);
            else
                dp[i][j] = dp[i-1][j];

            
        }
    }
    cout<< dp[n][cap] << endl;

    
    
}
