//
//  main.cpp
//  Floyd02
//
//  Created by 刘畅 on 2017/9/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//  Floyd最短路径算法  有向图中  每个点到其他点的最短距离



#include <iostream>
using namespace std;



int main(int argc, const char * argv[]) {
    
    
    int e[10][10];
    int inf = 9999999;
    
    //输入图的顶点个数和边的条数
    int m,n;
    cin>>m>>n;
    for(int i = 1; i <= n; i++){
        for (int j = 1; j <= n; j++) {
            if(i == j){
                e[i][j] = 0;
            }
            else{
                e[i][j] = inf;
            }
        }
    }
    
    //读入边
    for(int i = 1; i <= m; i++){
        int t1,t2,t3;
        cin>>t1>>t2>>t3;
        e[t1][t2] = t3;
    }
    
    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(e[i][j] > e[i][k] + e[k][j])
                    e[i][j] = e[i][k] + e[k][j];
            }
        }
    }
    
    //输出结果
    
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            cout<<e[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
    
    
}
