//
//  main.cpp
//  2Darray
//
//  Created by 刘畅 on 2017/8/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//  对于二维数组的实现问题 在迷宫问题等很多问题中会用到

#include <iostream>
#include <string>
using namespace  std;

int maze(int **ma){
    cout<<"I am here: "<<ma[0][0]<<endl;
    return 0;
}

int value(int wap[5][5]){
    cout<<"利用静态数组，我现在在:"<<wap[0][0]<<endl;
    return 0;
}

int main(int argc, const char * argv[]) {
 
    int height,width;
    cin>>height>>width;
    //用一个动态数组来记录走过的位置
    int **marked = new int*[height];
    
    for (int i = 0; i < height; ++i)
    {
        marked[i] = new int[width];
        
        for (int j = 0; j < width; ++j)
        {
            marked[i][j] = 0;
        }
    }
    
    cout<<"***********动态输出的数组!******************"<<endl;
    for(int i = 0; i < height; i++){
        for(int j = 0; j < width; j++){
            cout<<marked[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<"****************下面是静态数组！*********************"<<endl;
    
    int value4[5][5] = {{1,1},{2}};
    for(int i = 0; i < 5; i++){
        for (int j = 0; j < 5; j++) {
            cout<<value4[i][j]<<" ";
        }
        cout<<endl;
    }
    
    
    maze(marked);
    value(value4);//数组参数的传递问题
    
    
}
