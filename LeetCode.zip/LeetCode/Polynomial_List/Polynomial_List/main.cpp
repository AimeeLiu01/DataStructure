//  main.cpp
//  Polynomial_List
//
//  Created by 刘畅 on 2017/8/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//  链式多项式


/*
 我们用Polynomial来表示多项式，其唯一的数据成员时一个List<Type>的对象poly,每个ListNode<Type>结点表示多项式中的一个项，为此，需要把模板Type实例化为struct Term，其中，Term由数据成员coef和exp组成。
 用struct可以使Term的数据成员可公共访问，从而使任何可访问Term对象的函数也可访问其数据成员。
 同时，这样并不影响Polynomial的数据封装性，因为List<Term>对象poly及其包含Term对象的全部结点时私有的。
 */

#include <iostream>
#include <string>
using namespace std;

template<class Type> class List;
template<class Type> class ListIterator;

//结点类
template<class Type>
class ListNode{
    
    friend class List<Type>;
    friend class ListIterator<Type>;
    
public:
    ListNode(Type x = 0);//构造函数中可以写默认值
private:
    Type data;
    ListNode* link;
};

//链表类
template<class Type>
class List{
    
    friend class ListIterator<Type>;
    
public:
    List(){
        first = 0;
    };
    void Create2();
    void Insert80(ListNode<Type> *x);
    void Delete(ListNode<Type> *y);
    void Attach(Type k);
    
private:
    ListNode<Type> *first;
};

//ListNode的构造函数
template<class Type>
ListNode<Type>::ListNode(Type element){
    data = element;
    link = 0;
}


//List的成员函数
template<class Type>
void List<Type>::Create2(){
    first = new ListNode<Type>(10);
    first->link = new ListNode<Type>(20);
}

//List的成员函数(插入操作）
template<class Type>
void List<Type>::Insert80(ListNode<Type> *x){//将80插入到x之后
    ListNode<Type> *t = new ListNode<Type>(80);
    if(!first){
        first = t;
        return;
    }
    t->link = x->link;
    x->link = t;
    
}
//List的删除函数（删除操作）
template<class Type>
void List<Type>::Delete(ListNode<Type> *y){
    ListNode<Type> *x;
    if(!y){
        x = first;
        first = first->link;
    }
    else{
        x = y->link;
        y->link = x->link;
    }
}



//游标类  用来访问结点 并输出每一个结点的值
template<class Type>
class ListIterator{
public:
    ListIterator(const List<Type>& a): list(a),current(a.first){};
    bool NotNull();
    bool NextNotNull();
    Type *first();
    Type *Next();
    Type sum(const List<Type>& a);
private:
    const List<Type>& list;
    ListNode<Type>* current;
    
};

//游标类来判断链表是否为空
template<class Type>
bool ListIterator<Type>::NotNull(){
    if(current)
        return true;
    else
        return false;
}

//游标类来判断链表的下一个字段是否为空
template<class Type>
bool ListIterator<Type>::NextNotNull(){
    if(current && current->link)
        return true;
    else
        return false;
}
//返回链表的首元素的值的地址
template<class Type>
Type* ListIterator<Type>::first(){
    
    if(list.first) return &list.first->data;
    else
        return 0;
    
}

//返回链表的游标所在元素的下一个结点的值的地址
template<class Type>
Type* ListIterator<Type>::Next(){
    if(current){
        current = current->link;
        if(current)
            return &current->data;
    }
    return 0;
}

//对于链表中的每一个元素进行求和操作
template<class Type>
Type ListIterator<Type>::sum(const List<Type>& a){
    
    ListIterator<Type> ai(a);
    if(!ai.NotNull())//如果链表为空表
        return 0;
    int retvalue = *ai.first();
    while (ai.NextNotNull()) {
        retvalue += *ai.Next();
    }
    return retvalue;
}




//代表的是多项式的一个项，由系数和指数构成
struct Term{
    float coef;
    int exp;
    void Init(float c, int e){
        coef = c;
        exp = e;
    }
};

class Polynomial{
    friend Polynomial operator+(const Polynomial&, const Polynomial&);//友元函数
private:
    List<Term> poly;
};

char compare(int a, int b){
    if(a == b)
        return '=';
    else if(a > b)
        return '>';
    else
        return '<';
    
}

//多项式加法
Polynomial operator + (const Polynomial& a, const Polynomial& b){
    Term *p, *q, temp;
    ListIterator<Term> Aiter(a.poly);
    ListIterator<Term> Biter(b.poly);
    Polynomial c;//存放结果
    p = Aiter.first(); q = Biter.first();//取得a和b的第一项指针
    while (Aiter.NotNull() && Biter.NotNull()) {
        
        switch (compare(p->exp, q->exp)) {
            case '=' :
                int x;
                x = p->coef + q->coef;
                temp.Init(x, q->exp);
                if(x)
                c.poly.Attach(temp);
                p = Aiter.Next();
                q = Biter.Next();
                break;
                
            case '<' :
                temp.Init(q->coef, q->exp);
                c.poly.Attach(temp);
                q = Biter.Next();
                break;
                
            case '>' :
                temp.Init(p->coef, p->exp);
                c.poly.Attach(temp);
                p = Aiter.Next();
                break;
 
        }
    }
    while (Aiter.NotNull()) {
        temp.Init(p->coef, p->exp);
        c.poly.Attach(temp);
        p = Aiter.Next();
    }
    
    while (Biter.NotNull()) {
        temp.Init(q->coef, q->exp);
        c.poly.Attach(temp);
        q = Biter.Next();
    }
    
    return c;
    
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}














