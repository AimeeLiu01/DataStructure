//
//  main.cpp
//  dp01
//
//  Created by 刘畅 on 2017/5/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//案例一：
//有n级台阶，一个人每次上一级或者两级，问有多少种走完n级台阶的方法。

#include <iostream>
using namespace std;

int fun(int n){
    
    int dp[100] = {0};
    
    if(n == 1 || n == 2){
        return n;
    }
    if(!dp[n-1]){
        dp[n-1] = fun(n-1);
    }
    if(!dp[n-2]){
        dp[n-2] = fun(n-2);
    }
    
    return dp[n-1] + dp[n-2];
    
    
}

int main(int argc, const char * argv[]) {
   
    
    int n = 5;
    
    cout<<fun(5)<<endl;
 
}
