//
//  main.cpp
//  Polynomial_Array
//
//  Created by 刘畅 on 2017/8/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

struct Term{
    float coef;//系数
    int exp;//指数
};

class Polynomial{
public:
    Polynomial();//构造函数，返回多项式p(x)=0
    int operator !();//若*this是零多项式则返回1 ，否则返回0
    Polynomial operator =(const Polynomial p);
    float Coef(int e); //返回*this中指数为e的项的(系数)
    int LeadExp();//返回*this中的最大（指数）
    void AddTerm(float c,int e); //将<e,c>加入到*this,从而使多项式可动态增加项
    Polynomial Add(Polynomial poly); //返回多项式*this与poly之和
    float Eval(float f);             //计算并返回x=f时*this (多项式的值)
    void print(Polynomial p);
   
    
private:
    const static int MaxSize = 100;
    static Term termArray[MaxSize];//静态成员声明
    static int free;//静态成员声明   free给出数组termArray中下一个可用单元
    int start, finish;//多项式的起始位置
};



char compare(int a,int b){
    
    if(a == b) return '=';
    else if(a > b) return '>';
    else return '<';
    
}

int Polynomial::operator!(){//判断多项式是否为空
    if(free == 0) return 1;
    else
        return 0;
}

float Polynomial::Coef(int e){//返回*this中指数为e的项的(系数)
    int a = start;
    while (a <= finish) {
        if(termArray[a].exp == e){
            return termArray[a].coef;
        }
        else
            a++;
    }
    return -1;
}

int Polynomial::LeadExp(){//返回*this中的最大（指数）

    if(termArray[0].exp != 0)
       return termArray[0].exp;
    else
        return -1;
}


void Polynomial::AddTerm(float c,int e){//向动态数组中加入新的项
    
    if(free >= MaxSize){
        cout<<"空间不够。"<<endl;
        return;
    }
    termArray[free].coef = c;
    termArray[free].exp = e;
    
}

float Polynomial::Eval(float f){//计算并返回x=f时*this (多项式的值)
    
    float res = 0;
    while (start <= finish) {
        int tempExp = termArray[start].exp;
        for(int i = 0; i < tempExp; i++){
            res *= f;
        }//指数相乘
        res *= termArray[start].coef;
        start++;
    }
    
    return res;
}

void Polynomial::print(Polynomial p){
    
    int i = p.start;
    while (i < p.finish) {
        cout<< p.termArray[i].coef<<"X^"<<p.termArray[i].exp<<"+";
        i++;
    }
    cout<<p.termArray[finish].coef<<"X^"<<p.termArray[i].exp;
    cout<<endl;
}

Polynomial Polynomial::Add(Polynomial B){//多项式相加
    
    Polynomial C;//结果多项式
    int a = start; int b = B.start; C.start = free;//a b为a和b的扫描指针
    float c;
    
    while (a <= finish && b <= B.finish) {
        switch (compare(termArray[a].exp, termArray[b].exp)) {
                
            case '=':
                c = termArray[a].coef + termArray[b].coef;
                if(c) AddTerm(c, termArray[a].exp);
                a++,b++;
                break;
            case '<':
                AddTerm(termArray[b].coef, termArray[b].exp);
                b++;
                break;
            case '>':
                AddTerm(termArray[a].coef, termArray[a].exp);
                a++;
                break;
                
        }
    }//end while
    for(; a <= finish; a++)
        AddTerm(termArray[a].coef, termArray[a].exp);//加入A(x)的剩余项
    
    for(; b <= B.finish; b++)
        AddTerm(termArray[b].coef, termArray[b].exp);//加入B(x)的剩余项
    
    return C;
    
}

Polynomial::Polynomial(){
    start = 0;
    finish = 0;
    free = 0;
}



int main(int argc, const char * argv[]) {
    
    Polynomial p;
    p.print(p);
    Polynomial B;
    B.print(B);
    Polynomial res;
    
    
    
    
    
    return 0;
    
    
    
    
    
    
    
    
    
    
    
}
