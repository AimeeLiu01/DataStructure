//
//  main.cpp
//  liu002
//
//  Created by 刘畅 on 2017/5/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//

//括号匹配   同样使用栈求解


#include <iostream>
#include <stack>
using namespace std;


bool isRect(char tmp[], int lo, int hi){
    
    stack<char> mystack;
    
    for(int i=0; i<hi; i++){
        if(tmp[i] == '('){
            
            mystack.push(tmp[i]);
        }
        
        
        else if(tmp[i] == ')'){
            mystack.pop();
        }
        else
            return false;
    }
    
    if(!mystack.empty()){
        return false;
    }
    else{
        return true;
    }
    
    
}

int main(int argc, const char * argv[]) {
    char mytmp[] = "(((((())))))";
    
    if(isRect(mytmp, 0, 12)){
        cout<<"True"<<endl;
    }
    else{
        cout<<"False"<<endl;
    }
    return 0;
}
