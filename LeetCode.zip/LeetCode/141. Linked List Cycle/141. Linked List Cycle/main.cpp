//
//  main.cpp
//  141. Linked List Cycle
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//


#include <iostream>
#include <stack>
#include <vector>
using namespace std;

//本题是判断一个链表中是否会形成环路
//思路：我们可以设置快慢指针，如果无环 则快慢指针不可能会相遇   如果有环  一旦快慢指针均进入到环中 则必然会相遇
struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution{
public:
    bool hasCycle(ListNode *head) {
        ListNode *slow = head;
        ListNode *fast = head;
        while (fast->next && fast->next->next) {
            slow = slow->next;
            fast = fast->next->next;
            if(slow == fast){
                return true;
            }
        }
        
        return false;
    }
};

int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(4);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;

    Solution s = *new Solution();
    if(s.hasCycle(node1))
        cout<<"YES!!!!"<<endl;
    else
        cout<<"False!!!"<<endl;
    
    return 0;
}






