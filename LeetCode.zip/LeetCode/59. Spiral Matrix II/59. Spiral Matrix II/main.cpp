//
//  main.cpp
//  59. Spiral Matrix II
//
//  Created by 刘畅 on 2017/6/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//
#include <vector>
#include <iostream>
using namespace std;
class Solution {
public:
    vector<vector<int> > generateMatrix(int n) {
        
        vector<vector<int> > res(n, vector<int>(n));
        int left, right, top, down, index;
        left = top = index = 0, right = down = n-1;
        
        while (left <= right && top <= down) {
            for ( int j = left; j <= right; j++)
                res[top][j] = ++index;
            top++;
            for ( int i = top; i <= down; i++)
                res[i][right] = ++index;
            right--;
            for (int j = right; j >= left; j--)
                res[down][j] = ++index;
            down--;
            for (int i = down; i >= top; i--)
                res[i][left] = ++index;
            left++;
        }
        for(int i = 0 ; i < res.size(); i++){
            for(int j = 0; j < res[0].size(); j++){
                cout<<res[i][j]<<"  ";
            }
            cout<<endl;
        }

        return res;
    }
    
};
int main(int argc, const char * argv[]) {
    
    Solution s = *new Solution();
    s.generateMatrix(6);
    return 0;
}

