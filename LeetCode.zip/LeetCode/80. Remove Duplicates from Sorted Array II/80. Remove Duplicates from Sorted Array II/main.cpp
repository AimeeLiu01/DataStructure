//
//  main.cpp
//  80. Remove Duplicates from Sorted Array II
//
//  Created by 刘畅 on 2017/6/12.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;

/*class Solution{
public:
    int removeDuplicates(int A[], int n){
        if(n <= 1)
            return n;
        
        int index = 2;
        for(int i = 2; i < n; i++){
            if(A[i] != A[i-2]){
                A[index++] = A[i];
            }
            else{
                continue;
            }
        }
        return index;
    }
};*/
class Solution {
public:
    int removeDuplicates(vector<int> &nums) {
        
        int n = nums.size();
        if(n < 3)        //最多含有2个元素，一定满足题意
            return n;
        int index = 2; //可能不合法的位置
        for(int i = 2; i < n; i++)
        {
            if(nums[i] != nums[index - 2] )
                nums[index++] = nums[i];
        }
        return index;
    }
};


int main(int argc, const char * argv[]) {
    
    int result;
    Solution solution;
    vector<int> vec;
    vec.push_back(1);
    vec.push_back(1);
    vec.push_back(1);
    vec.push_back(3);
    vec.push_back(3);
    vec.push_back(4);
    vec.push_back(5);
    result = solution.removeDuplicates(vec);
    
    for(int i = 0;i < result;i++){
       cout<<vec[i]<<" ";
    }
    return 0;
}
