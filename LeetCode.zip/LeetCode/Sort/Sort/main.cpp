//
//  main.cpp
//  Sort
//
//  Created by 刘畅 on 2017/8/23.
//  Copyright © 2017年 刘畅. All rights reserved.

#include <iostream>
using namespace std;


void swap(int a[], int i, int j){
    int tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
}

void SelectSort(int a[], int n){
    
    //选择排序的思想是从数组中每次选出未排序部分最小的元素，加入到已排序元素之后
    for(int i = 0; i < n; i++){
        
        int min = i;//表示第i个位置
        for(int j = i+1; j < n; j++){
            if(a[j] < a[min]){
                
                min = j;
            }
        }
        swap(a,min,i);
    }
    
    for(int i = 0; i < n; i++)
        cout<<a[i]<<" ";
    cout<<endl;
}

void InsertSort(int a[], int n){
    
    //插入排序的思想是，每一次选择的元素从后向前进行比较，如果要插入的元素比当前元素小，那么当前元素向后移动位置，直到插入的元素比当前元素要大，就坐下
    for(int i = 1; i < n; i++){//从第二个元素开始，而不是从第一个元素开始
        
        int j = i-1;
        while (a[i] < a[j] && j >= 0) {
                
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = a[i];
    }
    
    for(int i = 0; i < n; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}

void BubbleSort(int a[], int n){
    
    //冒泡排序，每次消灭一对逆序数，每次都可以将最小的元素放到相对应的位置
    for(int i = 0; i < n-1; i++){
        for(int j = i+1; j < n; j++){
            if(a[i] > a[j]){
                swap(a,i,j);
            }
        }
    }
    
    for(int i = 0; i < n; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}


//快速排序
void QuickSort(int a[], int low, int high){
    
    int privt = a[low];
    
    int i = low;
    int j = high;
    
    if(i > j)
        return;
    
    while (i != j) {
        
        while (a[j] >= privt && i < j) {//直到找到比基准小的数，停下
            j--;
        }
        while (a[i] <= privt && i < j) {//直到找到比基准大的数，停下
            i++;
        }
        
        if(i < j){
          swap(a,i,j);
        }

    }
    //跳出循环之后，交换基准
    //循环结束的条件即为i == j
    a[low] = a[j];
    a[j] = privt;
    
    QuickSort(a, low, i-1);
    QuickSort(a, i+1, high);
    
}


//归并排序
void Recursive(int a[], int low, int mid, int high, int *tmp){
    
    int i = low;
    int j = mid + 1;
    int k = 0;
    while (i <= mid && j <= high) {//数组a[low,mid]与数组[mid+1, high]均没有全部归入数组temp中去
        
        if(a[i] <= a[j]){
            tmp[k] = a[i];
            k++;
            i++;
        }
        
        else{
            tmp[k] = a[j];
            k++;
            j++;
        }
    }
    while (i <= mid) {
        tmp[k] = a[i];
        i++;
        k++;
    }
    while (j <= high) {
        tmp[k] = a[j];
        j++;
        k++;
    }
    
    //然后我们将归并后的数组的值逐一赋给数组a[low,high]   注意，应从a[low+i]开始赋值
    for(i = 0; i < k; i++){
        a[low + i] = tmp[i];
    }
}

void MergeSort(int a[], int low, int high, int *tmp){
    
    if(low >= high){
        return;
    }
    
    int middle = (low + high)/2;
    
    MergeSort(a, low, middle, tmp);//左边有序
    MergeSort(a, middle+1, high, tmp);//右边有序
    Recursive(a, low, middle, high, tmp);//再将两个有序序列合并

}


//堆排序

void adjustHeap(int a[], int p, int size){
    
    int curParent = a[p];
    int child = 2 * p + 1;// 左孩子
    
    while (child < size) {
        if(child + 1 < size && a[child] < a[child+1]){
            child++;//找到孩子中的最大值
        }
        
        if(curParent < a[child]){//如果当前父节点比子女结点还要小
            a[p] = a[child];//我们让子结点当父节点
            
            //没有将curParent赋值给孩子是因为还要迭代子树，
            //如果其孩子中有大的，会上移，curParent还要继续下移。
            
            p = child;
            child = 2 * p + 1;
        }
        else
            break;
    }
    
    a[p] = curParent;
}

//********这个函数的意思和删除堆中最大元素 然后进行调整的意思很像了****************

void adjustHeap1(int heap[], int i, int size){
    
  
    int k = heap[i];//我们要调整以i为父节点的堆  相当于我们删除了堆的根结点 现在让最后一个元素顶替 进行堆的调整
    
    //j为i的子女
    for(int j = 2 * i + 1; j < size; ){
        
        if(j+1 < size && heap[j+1] > heap[j])
            j++;//找到最大的子女
        
        if(k >= heap[j])
            break;//说明当前结点比子女中的最大值还要大 我们让其就坐
        else{
            heap[i] = heap[j];//我们让子女中的较大值当父节点
            i = j;//将父节点下移  寻找自己的位置
            j = 2 * i + 1;//因为根结点是a[0]
        }
            
    }
    heap[i] = k;
    
    
}



void heapSort(int a[], int size){
    //建立堆，从最底层的父节点开始
    for(int i = size/2 - 1; i >= 0; i--)
        adjustHeap(a,i,size);
    
    for(int i = size-1; i >= 0; i--){
        int maxEle = a[0];
        a[0] = a[i];
        a[i] = maxEle;
        
        adjustHeap1(a, 0, i);
    }
    
}



int main(int argc, const char * argv[]) {
    
    int a[] = {6,5,3,1,9,10,8,0};
    int *tmp = new int[7];
    cout<<"After SelectSort, the array is:"<<endl;
    SelectSort(a,8);
    cout<<"After InsertSort, the array is:"<<endl;
    InsertSort(a,8);
    cout<<"After BubbleSort, the array is:"<<endl;
    BubbleSort(a,8);
    
    cout<<"After QuickSort, the array is:"<<endl;
    QuickSort(a, 0, 7);
    for(int i = 0; i < 8; i++){
        cout<<a[i]<<" ";
    }
   
    cout<<"\nAfter MergeSort, the array is:"<<endl;
    MergeSort(a, 0, 7, tmp);
    for(int i = 0; i < 8; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
    
    int b[] = {6,5,3,1,9,11,14,2,8};
    heapSort(b, 9);
    cout<<"After HeapSort, the array is:"<<endl;
    for(int i = 0; i < 9; i++){
        cout<<b[i]<<" ";
    }
    cout<<endl;
    
    return 0;
}
