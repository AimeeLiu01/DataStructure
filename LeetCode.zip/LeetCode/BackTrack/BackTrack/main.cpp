//
//  main.cpp
//  BackTrack
//
//  Created by 刘畅 on 2017/8/31.
//  Copyright © 2017年 刘畅. All rights reserved.
//  回溯算法

#include <iostream>
#include <string>
#include <stack>
using namespace std;

//问题2 输出不重复数字的全排列

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
