//
//  main.cpp
//  ListNode3
//
//  Created by 刘畅 on 2017/8/26.
//  Copyright © 2017年 刘畅. All rights reserved.
//  双向链表的基本操作

#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode *prior;
    ListNode *next;
    ListNode(int x):val(x),prior(nullptr),next(nullptr){}
};

//创建一个带有头结点的双向链表
ListNode *createDList()
{
    ListNode *beginNode = new ListNode(-1);
    beginNode->prior = nullptr;
    beginNode->next = nullptr;
    ListNode *p = beginNode;
    int x = 0;
    
    while (1) {
        cout<<"Please input the data: ";
        cin>>x;
        if (x != -1) {
            ListNode *node = new ListNode(x);
            p->next = node;
            node->prior = p;
            p = node;
        }
        else{
            break;
        }
    }
    return beginNode;
}

//打印带有头结点的双向链表
void printDList(ListNode *head){
    if (head->next == nullptr) {
        cout<<"list is empty."<<endl;
        return;
    }
    
    ListNode *p = head->next;
    
    while (p != nullptr) {
        cout<<p->val<<" ";
        p = p->next;
    }
}

//求带有头结点的双向链表的长度
int getDListLength(ListNode *head)
{
    if(head->next==nullptr)
    {
        cout<<"list is empty!"<<endl;
        return 0;
    }
    
    int index=0;
    ListNode *p=head->next;
    while(p!=nullptr)
    {
        ++index;
        p=p->next;
    }
    return index;
}

//判断带有头结点的双向链表是否为空
bool isEmpty(ListNode *head)
{
    if(head->prior==head->next)
        return true;
    else
        return false;
}

//查找带有头结点的双向链表中的第i个元素
ListNode *searchNode(ListNode *head, int pos){
    
    if(head->next == nullptr || pos < 0)
        return nullptr;
    
    if(pos == 0)
        return head;
    
    ListNode *p = head->next;
    while (--pos) {
        p = p->next;
        if(p == nullptr){
            cout<<"error"<<endl;
            break;
        }
    }
    return p;
}


//将值为data的新节点插入到带头结点的双向链表的第i（i=pos）个节点上
//分四种情况，插入到链表头部、链表中间、链表尾部，插入的位置越界

ListNode *insertDList(ListNode *head, int pos, int data){
    int len = getDListLength(head);
    ListNode *newNode = new ListNode(data);
    ListNode *p = nullptr;
    
    if (pos == 0) {//在链表的头部插入结点
        newNode->next = head->next;
        newNode->prior = head;
        head->next = newNode;
        newNode->next->prior = newNode;
    }
    else if(pos > 0 && pos < len + 1){//在链表的中间插入
        
        p = searchNode(head, pos-1);//第pos-1个结点
        newNode->next = p->next;
        newNode->prior = p;
        p->next->prior = newNode;
        p->next = newNode;
        
    }
    
    else if(pos == len + 1){//在链表的尾部插入
        
        p = searchNode(head, pos - 1);
        newNode->next = nullptr;
        newNode->prior = p;
        p->next = newNode;
        
    }
    else{
        cout<<"越界，无法插入."<<endl;
    }
    return head;
}

//删除带头结点的双向链表的第i个位置的结点
//分为5种情况:头结点  中间结点  尾结点  链表为空  删除元素位置为空
//链表的长度为n，则链表删除第i个节点时，必须保证1=<i<=n,否则不合法。
ListNode *deleteNode(ListNode *head, int pos){
    ListNode *p = searchNode(head, pos);//查找第pos个位置的节点  即为要删除的结点
   
    if(p == NULL){
        cout<<"incorrect position to delete node. "<<endl;
    }
    else if(p->prior == nullptr){//删除头结点
        
        if(p->next != nullptr){
            p->next->prior = nullptr;
            ListNode *newBeginNode = new ListNode(-2);
            newBeginNode->next = p->next;
            delete p;
            return newBeginNode;
        }
    }
    
    else if(p->next == nullptr){
        p->prior->next = nullptr;
        delete p;
    }
    
    else{//删除第一个结点到倒数第二个结点
        p->prior->next = p->next;
        p->next->prior = p->prior;
        delete p;
        
    }
    return head;
}


//逆序打印带头结点的双向链表
void printReverse(ListNode *head){
    
    if(head->next != nullptr){
        printReverse(head->next);
        cout<<head->next->val;
    }
    else{
        cout<<"链表为空哦。"<<endl;
    }
}


//清空带有头结点的双向链表
void clearDList(ListNode *head)
{
    ListNode *tmp = nullptr;
    ListNode *p = head->next;
    while (p != nullptr) {
        tmp = p->next;
        delete p;
        p = tmp;
    }
    
    head->next = head->prior = nullptr;
}

int main(int argc, const char * argv[]) {
    
    ListNode *head=createDList();
    cout<<"创建的带头双向链表为："<<endl;
    printDList(head);
    int len=getDListLength(head);
    cout<<"\n双向链表的长度为："<<len<<endl;
    
    int pos1=3;
    ListNode *sNode=searchNode(head,pos1);
    if(sNode!=nullptr)
    {
        cout<<"查找的第"<<pos1<<"个节点元素为："<<sNode->val<<endl;
    }
    
    int pos2=7;
    int data=88;
    ListNode *head1=insertDList(head,pos2,data);
    cout<<"插入新节点后的带头双向链表为："<<endl;
    printDList(head1);
    
    int pos3=1;
    ListNode *head2=deleteNode(head,pos3);
    cout<<"\n删除节点后的带头双向链表为："<<endl;
    printDList(head2);
    //测试删除头结点
    if(pos3==0)
    {
        cout<<endl;
        cout<<head2->val;
    }
    
    bool flag=isEmpty(head);
    if(flag)
    {
        cout<<"\nlist is empty!"<<endl;
    }
    else
    {
        cout<<"\nlist is not empty!"<<endl;
    }
    
    clearDList(head);
    cout<<"清空后的带头双向链表为："<<endl;
    printDList(head);
    
    cout<<"逆序打印的带头双向链表为："<<endl;
    printReverse(head);
    
    cout<<"原带头双向链表为："<<endl;
    printDList(head);
    system("pause");
    return 0;
}
