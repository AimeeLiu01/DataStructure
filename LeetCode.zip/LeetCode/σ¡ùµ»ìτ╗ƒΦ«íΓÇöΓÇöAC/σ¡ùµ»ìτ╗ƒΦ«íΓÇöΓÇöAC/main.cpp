//
//  main.cpp
//  字母统计——AC
//
//  Created by 刘畅 on 2017/7/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
