//
//  islandOfVector.cpp
//  Island_BFS
//
//  Created by 刘畅 on 2017/8/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <queue>
#include <iostream>
using namespace std;

int numOfIslands(vector<vector<int>> &grid){
    
    int dirX[] = {1,0,0,-1};
    int dirY[] = {0,1,-1,0};
    int row = grid.size();
    int col = row>0 ? grid[0].size() : 0;
    if(row == 0 || col == 0)
        return 0;
    
    vector<vector<bool>> visited(col, vector<bool>(col,false));
    queue<pair<int, int>> queue;
    
    int count = 0;
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            if(grid[i][j] == 1 && visited[i][j] == false){
                queue.push(make_pair(i, j));
                visited[i][j] = true;//一旦访问要立刻进行标记
                ++count;//++count 而不是count++
                
                while (!queue.empty()) {
                    auto n = queue.front();
                    int x = n.first;
                    int y = n.second;
                    queue.pop();//记得弹栈
                    
                    for(int k = 0; k < 4; k++){
                        int xx = x + dirX[k];
                        int yy = y + dirY[k];
                        if(xx < 0 || xx >= row || yy < 0 || yy >= col)
                            continue;
                        
                        if(grid[xx][yy] == 1 && visited[xx][yy] == false){
                            queue.push(make_pair(xx, yy));
                            visited[xx][yy] = true;
                        }
                    }
                }
            }
        }
    }
    
    cout<<"There are "<<count<<" islands~~~"<<endl;
    return count;
    
}


int main(){
    
    
    vector<vector<int>> island = {{1,1,1,1,0},{1,1,0,1,0},{1,1,0,0,0},{0,0,0,0,0}};
    vector<vector<int>> island2 ={{1,1,0,0,0},{1,1,0,0,0},{0,0,1,0,0},{0,0,0,1,1}};

    numOfIslands(island);
    numOfIslands(island2);
    return 0;
    
}
