//
//  main.cpp
//  Island_BFS
//
//  Created by 刘畅 on 2017/8/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//
//  求岛屿的个数  给一个二维矩阵  由0和1组成  连在一起的1组成一个岛

/*这份代码出现的问题：
 1.二维数组的创建问题 声明时要带上一个参数
 2.队列的出栈
 3.处理坐标越界时的情况
 */

#include <iostream>
#include <string>
#include <queue>
using namespace std;


int dirX[] = {1,0,0,-1};
int dirY[] = {0,1,1,0};

int findNumberOfIslands(){
  
   
    int count = 0;//代表的是岛屿的个数
    int x = 0, y = 0, xx = 0, yy = 0;//先准备一些变量
    queue<pair<int, int>> que;
    
    int height, width;
    cin>>height>>width;
    
    int **island = new int*[height];
    for (int i = 0; i < height; ++i)
    {
        island[i] = new int[width];
        for (int j = 0; j < width; ++j)
        {
            cin>>island[i][j];
        }
    }

    bool **visited = new bool*[height];
    for (int i = 0; i < height; ++i)
    {
        visited[i] = new bool[width];
        
        for (int j = 0; j < width; ++j)
        {
            visited[i][j] = false;
        }
    }

    
    for(int i = 0; i < height; i++){
        for(int j = 0; j < width; j++){
            
            if(island[i][j] == 1 && visited[i][j] == false){
                que.push(make_pair(i, j));
                ++count;
                
                while (!que.empty()) {
                    auto n = que.front();
                    x = n.first;
                    y = n.second;
                    que.pop();
                    
                    for(int k = 0; k < 4; k++){
                        xx = x + dirX[k];
                        yy = y + dirY[k];
                        
                        if(xx < 0 || xx >= height || yy < 0 || yy >= width)
                            continue;
                        //忘记处理越界的情况了...
                        if(island[xx][yy] == 1 && visited[xx][yy] == false){
                            que.push(make_pair(xx, yy));
                            visited[xx][yy] = true;
                        }
                        
                    }
                }
                
            }
        }
    }
    delete [] island;
    delete [] visited;
    cout<<"There are "<<count<<" 个小岛～"<<endl;
    return count;
    
}





int main2(int argc, const char * argv[]) {
    
    
    findNumberOfIslands();
    return 0;
    

}
