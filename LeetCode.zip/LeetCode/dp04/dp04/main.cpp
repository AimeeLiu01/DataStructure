//
//  main.cpp
//  dp04
//
//  Created by 刘畅 on 2017/5/14.
//  Copyright © 2017年 刘畅. All rights reserved.
/*
 案例四：
 给定两个字符串str1和str2，返回两个字符串的最长公共子序列，例如：str1="1A2C3D4B56",str2="B1D23CA45B6A","123456"和"12C4B6"都是最长公共子序列，返回哪一个都行。
 分析：本题是非常经典的动态规划问题，假设str1的长度为M，str2的长度为N，则生成M*N的二维数组dp，dp[i][j]的含义是str1[0..i]与str2[0..j]的最长公共子序列的长度。
 dp值的求法如下：
 dp[i][j]的值必然和dp[i-1][j],dp[i][j-1],dp[i-1][j-1]相关，结合下面的代码来看，我们实际上是从第1行和第1列开始计算的，而把第0行和第0列都初始化为0，这是为了后面的取最大值在代码实现上的方便，dp[i][j]取三者之间的最大值。
 */

#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int findLCS(string A, int n, string B, int m){
    int dp[500][500]={0};
    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++){
            if(A[i] == B[j])
                dp[i+1][j+1] = dp[i][j] + 1;
            else
                dp[i+1][j+1] = max(dp[i+1][j], dp[i][j+1]);
        }
    }
    
    return dp[n][m];
}

int main(int argc, const char * argv[]) {
    
    string A = "123456";
    string B = "12C4B6";
    int tmp = findLCS(A, 6, B, 6);
    cout<<tmp<<endl;
    return 0;
    
}
