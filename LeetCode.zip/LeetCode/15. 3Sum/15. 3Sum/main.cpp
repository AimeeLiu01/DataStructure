//
//  main.cpp
//  15. 3Sum
//
//  Created by 刘畅 on 2017/6/21.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;

class Solution{
public:
    vector<vector<int>> threeSum(vector<int> &nums){
        sort(nums.begin(), nums.end());
        vector<vector<int>> res;
        
        for(int i = 0 ; i < nums.size(); i++){
            
            if(i == 0 || nums[i] != nums[i-1]){
                
                int sum = -nums[i];
                int pa = i + 1, pb = nums.size() - 1;
                while (pa < pb) {
                    if (nums[pa] + nums[pb] == sum) {//代表后两个数字之和等于第一个数字
                        vector<int> item;
                        item.push_back(nums[i]);
                        item.push_back(nums[pa]);
                        item.push_back(nums[pb]);
                        res.push_back(item);
                        pa++,pb--;
                        
                        while (pa<pb && nums[pa-1] == nums[pa]) {
                            pa++;//消除重复元素
                        }
                        while (pa<pb && nums[pb] == nums[pb+1]) {
                            pb--;//消除重复元素
                        }
                    }
                    else if (nums[pa]+nums[pb]>sum){
                        pb--;
                    }
                    else
                        pa++;
                }
            }
        }
        
        return res;
    }
};

int main(int argc, const char * argv[]) {
   
    Solution s = *new Solution();
    vector<int> vec;
    vec.push_back(1);
    vec.push_back(1);
    vec.push_back(2);
    vec.push_back(3);
    vec.push_back(5);
    vec.push_back(5);
    vector<vector<int>> res = s.threeSum(vec);
    for(int i = 0; i < res.size(); i++){
        for(int j = 0; j < res[0].size(); j++){
            cout<<res[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}








