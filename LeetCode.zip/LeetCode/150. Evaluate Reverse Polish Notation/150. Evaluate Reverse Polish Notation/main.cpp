//
//  main.cpp
//  150. Evaluate Reverse Polish Notation
//
//  Created by 刘畅 on 2017/6/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    //string-->char*
    //c_str()函数返回一个指向正规C字符串的指针, 内容与本string串相同
    
    //这个数组的数据是临时的，当有一个改变这些数据的成员函数被调用后，其中的数据就会失效。
    //因此要么现用先转换，要么把它的数据复制到用户自己可以管理的内存中
    const char *c;
    string s = "1234";
    cout<<"--------"<<endl;
    for(int i = 0 ; i < s.length(); i++){
       
        cout<<s[i]<<" ";
    }
    cout<<endl;
    
    c = s.c_str();
    
    cout<<c<<endl;
    s = "abcde";
    cout<<c<<endl;
}
