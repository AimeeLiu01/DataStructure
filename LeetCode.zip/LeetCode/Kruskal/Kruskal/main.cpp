//
//  main.cpp
//  Kruskal
//
//  Created by 刘畅 on 2017/8/20.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

//带有权重的边
struct Edge{
    int src,dest,weight;
};

struct Graph{
    //V为顶点的个数 E为边的个数
    int V,E;
    struct Edge* edge;
};

//构建一个V个顶点 E条边的图
struct Graph* createGraph(int V, int E){
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;
    graph->E = E;
    graph->edge = (struct Edge*) malloc( graph->E * sizeof(struct Edge));
    return graph;
    
}

//并查集的结构体
struct subset{
    int parent;
    int rank;
};

//使用路径压缩查找元素
int find(struct subset subsets[], int i)
{
    if (subsets[i].parent != i) {
        subsets[i].parent = find(subsets,subsets[i].parent);
    }
    return subsets[i].parent;
}

//按秩合并x,y
void Union(struct subset subsets[], int x,int y)
{
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);
    
    if(subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else{
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
    
}

//根据权重比较两条边
int myComp(const void* a, const void* b)
{
    struct Edge* a1 = (struct Edge*)a;
    struct Edge* b1 = (struct Edge*)b;
    return a1->weight > b1->weight;
}

//Krusal算法
void KrusalMST(struct Graph* graph){
    
    int V = graph->V;
    struct Edge result[V];//存储结果
    int e = 0;//result[]的index
    int i = 0;//已排序的边的index
    
    //第一步排序
    qsort(graph->edge, graph->E, sizeof(graph->edge[0]), myComp);
    
    // 为并查集分配内存
    struct subset *subsets = (struct subset*) malloc( V * sizeof(struct subset));
   
    //初始化并查集
    for(int v = 0; v < V; v++)
    {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }
    
    //边的数量到V-1结束
    while (e < V-1) {
        
        //先选择最小权重的边
        struct Edge next_edge = graph->edge[i++];
        int x = find(subsets, next_edge.src);
        int y = find(subsets, next_edge.dest);
        
        //如果此边不会引起环
        if(x != y){
            result[e++] = next_edge;
            Union(subsets, x, y);
        }
        //否则丢弃，继续
    }
    
    //// 打印result[]
    printf("Following are the edges in the constructed MST\n");
    
    for (i = 0; i < e; ++i)
        cout<<result[i].src<<"  "<<result[i].dest<<"=="<<result[i].weight<<endl;
    return;


}

    
int main(int argc, const char * argv[]) {
    
    
    
    int V = 4;
    int E = 5;
    struct Graph* graph = createGraph(V, E);
    
    graph->edge[0].src = 0;
    graph->edge[0].dest = 1;
    graph->edge[0].weight = 10;
    
    
    graph->edge[1].src = 0;
    graph->edge[1].dest = 2;
    graph->edge[1].weight = 6;
    
    graph->edge[2].src = 0;
    graph->edge[2].dest = 3;
    graph->edge[2].weight = 5;
    
    graph->edge[3].src = 1;
    graph->edge[3].dest = 3;
    graph->edge[3].weight = 15;
    
    graph->edge[4].src = 2;
    graph->edge[4].dest = 3;
    graph->edge[4].weight = 4;
    
    KrusalMST(graph);
    return 0;
    
    
    

}
