//
//  tpSort01.cpp
//  tpSort
//
//  Created by 刘畅 on 2017/8/22.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
using namespace std;

#define maxsize 50

struct node{
    
    int adjvex;
    node* next;
    
};


struct graph
{
    int vexter;
    int in;
    node *firstedge;
};


struct sqStack{
    int *base;
    int *top;
    int stacksize;
};

void initStack(sqStack &S){
    
    
    S.base = (int *)malloc(sizeof(int));
    S.top = S.base;
    S.stacksize = maxsize + 1;
    
}

void createdlist(graph inDegree[], int n, int e){//创建邻接链表
    
    int i, k , j;
    node *q;
    
    for(i = 1; i <= n; i++)
    {
        inDegree[i].vexter = i;
        inDegree[i].in = 0;
        inDegree[i].firstedge = NULL;
    }
    
    cout<<"依次输入每一条边:"<<endl;
    for(k = 1; k <= e; k++)
    {
        cin>>i>>j;
        inDegree[j].in++;
        
        q = (node *)malloc(sizeof(node));
        q->adjvex = j;
        q->next = inDegree[i].firstedge;
        inDegree[i].firstedge = q;
        
    }
}



void TopSort(graph inDegree[],int n)

{
    
    int i,v,count=0;
    
    sqStack S;
    
    node * p;
    
    initStack(S);
    
    for(i=1;i<=n;i++)
        
        if(inDegree[i].in==0)
            
            *S.top++=i;
    
    while(S.top!=S.base)
        
    {
        
        v=*--S.top;
        
        cout<<v<<" ";
        
        count++;
        
        p=inDegree[v].firstedge;
        
        while(p!=NULL)
            
        {
            
            inDegree[p->adjvex].in--;
            
            if(inDegree[p->adjvex].in==0)
                
                *S.top++=p->adjvex;
            
            p=p->next;
            
        }
        
    }
    
    cout<<endl;
    
    if(count<n) cout<<"有回路"<<endl;  
    
    else cout<<"无回路"<<endl;  
    
}


int main1(){
    
    graph inDegree[maxsize];
    int v,e;
    cout<<"该AOV网的顶点数：";
    cin>>v;
    cout<<"该AOV网的边条数：";
    cin>>e;
    createdlist(inDegree, v, e);
    cout<<"拓扑排序序列为："<<endl;
    TopSort(inDegree,v);
    
    return 0;
}



