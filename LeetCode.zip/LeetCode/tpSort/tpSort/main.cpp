//
//  main.cpp
//  tpSort
//
//  Created by 刘畅 on 2017/8/20.
//  Copyright © 2017年 刘畅. All rights reserved.
//  拓扑排序的C++实现(邻接表存图)

#include <iostream>
#include <memory>
#include <queue>
#include <stack>
using namespace std;

//定义图结点的最大个数
const int MaxSize = 10;

struct LinkNode{
    int vex;//邻接的结点在数组中的编号
    LinkNode* next;
};

struct Node{
    int data;
    LinkNode* head;
}Adj[MaxSize];


//记录结点入度数的数组
int inCount[1000] = {0};
int numNode = 0;

//生成图（邻接表实现）
void createLink()
{

    int numLink = 0;
    LinkNode* ptr;
    cout<<"请输入AOV图中顶点的个数:"<<endl;
    cin>>numNode;
    
    for(int i = 1; i <= numNode; i++)
    {
        Adj[i].head = 0;
        cout<<"请输入第"<<i<<"个结点的值:";
        cin>>Adj[i].data;
        cout<<"请输入第"<<i<<"个结点链接的顶点个数:";
        cin>>numLink;
        
        //头插入建表
        for(int j = 1; j <= numLink; j++)
        {
            ptr = new LinkNode;
            cin>>ptr->vex;
            //vex下标所代表的点入度数+1
            ++inCount[ptr->vex];//这里我们是将顶点的值对应的inCount++
            ptr->next = Adj[i].head;
            Adj[i].head = ptr;
        }
    }
    
    cout<<"\n邻接表的存储数据如下："<<endl;
    for(int i = 1; i <= numNode; i++){
        cout<<i<<"号头结点存储的元素为："<<Adj[i].data<<":（邻接的顶点有）";
        ptr = Adj[i].head;
        while (ptr != NULL) {
            cout<<ptr->vex<<" ";
            ptr = ptr->next;
        }
        cout<<endl;
        
    }
    
    cout<<"\n每个元素的入度为："<<endl;
    for(int i = 1; i <= numNode; i++){
        cout<<Adj[i].data<<"---"<<inCount[Adj[i].data]<<endl;
    }
}


//拓扑排序
void tpSort(){
    
    stack<int> stk;
    LinkNode* p;
    int showNum = 0;//记录输出的结点的数目
    
    //在inCount数组中找到入度为0的结点 并分别入栈
    for(int i = 1; i <= numNode; i++)
        if(inCount[Adj[i].data] == 0)
            stk.push(Adj[i].data);
    
    
    //栈不为空时
    while (!stk.empty()) {
        //出栈到v
        int v = stk.top();
        stk.pop();
        cout<<v<<" ";
        
        //将该点入度调为-1
        inCount[v] = -1;
        
        int tempIndex = 0;
        //然后我们要寻找顶点的值为v的数存放在第几个头结点中
        for(int i = 1; i <= numNode; i++){
            if(Adj[i].data == v){
                tempIndex = i;
                break;
            }
        }
        
        ++showNum;
        //遍历以v为起点所临接的点
        p = Adj[tempIndex].head;
        while (p != NULL) {
            //结点入度数减1
            --inCount[p->vex];
            if(inCount[p->vex] == 0)
                stk.push(p->vex);
            
            p = p->next;
        }
    }
    
    cout<<endl;
    if(showNum < numNode)
        cout<<"该图中含有有向环！"<<endl;
}



int main(int argc, const char * argv[]) {
    
    
    //int num = 0;
    createLink();
    cout<<"\n拓扑排序的序列为："<<endl;
    tpSort();
    
    
    
    return 0;
}
