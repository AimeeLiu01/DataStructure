//
//  tpsort.cpp
//  tpSort
//
//  Created by 刘畅 on 2017/8/20.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std;
#define N 7//顶点个数


//邻接表的结构体
typedef struct Node{
    int adjvex;
    struct Node *next;
}edgeNode;


//邻接表的结构体  每个顶点为一个char元素  但是我们为其设定一个编号
typedef struct
{
    char vertex;
    int id;
    edgeNode *link;
}vexNode;


//进行拓扑排序
void TopSort_AdjTable(vexNode ga[N])
{
    int i,j,k, m=0, top=-1;
    edgeNode *p;//
    for(i = 0; i < N; i++)//将入度为0的顶点入栈
        if(ga[i].id == 0){
            ga[i].id = top;
            top = i;
        }
    while (top != -1) {//栈不为空
        j = top;
        top = ga[top].id;
        cout<<ga[j].vertex;
        m++;
        p = ga[j].link;
        while (p) {//删除该结点的所有出边
            
            k = p->adjvex-1;
            ga[k].id--;
            if(ga[k].id == 0){
                ga[k].id = top;
                top = k;
            }
            p = p->next;
        }
        
    }
    
    if(m < N)//当输出的顶点数小于N时，说明有环存在
        cout<<"该图存在环！"<<endl;
}


int main3(){
   
    vexNode ga[N];//创建好一个邻接表
    
    char vertex[N] = {'A','B','C','D','E','F','G'};
    int ID[N] = {0,1,2,0,1,1,3};
    for(int i = 0; i < N; i++)
    {
        ga[i].vertex = vertex[i];
        ga[i].id = ID[i];
    }//初始化顶点表
    
    
    edgeNode *s;
    //初始化边表
    s = (edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex = 2;
    ga[0].link = s;
    
    s = (edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex = 3;
    ga[0].link->next = s;
    s->next = NULL;
    
    s = (edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex = 6;
    ga[1].link = s;
    
    s = (edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex = 7;
    ga[1].link->next = s;
    s->next = NULL;
    
    s = (edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex = 7;
    ga[2].link = s;
    s->next = NULL;
    
    s = (edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex = 3;
    ga[3].link = s;
    s=(edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex=5;
    ga[3].link->next=s;
    s->next=NULL;
    
    s=(edgeNode *)malloc(sizeof(edgeNode));
    s->adjvex=7;
    ga[4].link=s;
    s->next=NULL;
  
    ga[5].link=NULL;
    ga[6].link=NULL;
    //初始化边表结束
    
    TopSort_AdjTable(ga);//进行拓扑排序
    
    cout<<endl;
    return 0;
    
    
}












