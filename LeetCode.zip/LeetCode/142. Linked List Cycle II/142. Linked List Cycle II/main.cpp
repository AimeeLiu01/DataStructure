//
//  main.cpp
//  142. Linked List Cycle II
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
#include <map>
using namespace std;

//本题是返回一个链表的环结点开始的地方  如果没有环  就返回null
//思路：我们可以设置快慢指针，如果无环 则快慢指针不可能会相遇   如果有环  一旦快慢指针均进入到环中 则必然会相遇
struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution {
public:
    ListNode *detectCycle(ListNode *head) {
        
        map<ListNode*, bool> visited;
        
        while(head != NULL){
            if(visited[head] == true){
                cout<<"The begin node is "<<head->val<<endl;
                return head;
            }
            visited[head] = true;
            head = head->next;
        }
        
        return NULL;
        
    }
};

int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(4);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    
    Solution s = *new Solution();
    if(s.detectCycle(node1) != NULL)
        cout<<"YES!!!!"<<endl;
    else
        cout<<"False!!!"<<endl;
    
    return 0;
}






