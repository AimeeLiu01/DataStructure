//
//  main.cpp
//  postfix
//  Aimee的代码
//  Created by 刘畅 on 2017/8/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//中缀表达式转为后缀表达式
//利用栈，并利用运算符的优先级
//在这份代码中，我们自己实现了栈，只是用了标准库，未使用容器库
#include <iostream>
#include <string>
using namespace std;

//目前我们先假设只有+-*／四种运算
//思路：对表达式进行遍历
//如果是运算数，即输出，如果是运算符，和当前栈顶的运算符的优先级相比较，如果优先级高则入栈，如果优先级低则将栈中的运算符弹出

template<class Type>
class Stack{
public:
    Stack(int maxStackSize);//创建一个最大容量为MaxSize的空栈
    bool isFull();//若元素个数等于栈的最大容量则返回true，否则返回false
    bool empty();
    void push(const Type& item);
    void pop();
    Type top();
private:
    int index;
    Type* st;
    int MaxSize;
};

template<class Type>
inline bool Stack<Type>::isFull(){
    if(index == MaxSize-1) return true;
    else return false;
}

template<class Type>
inline bool Stack<Type>::empty(){
    if(index == -1) return true;
    else return false;
}


template<class Type>
void Stack<Type>::push(const Type& x){
    if(isFull()) cout<<"栈已满,无法入栈。"<<endl;
    else st[++index] = x;//用了一个数组来实现栈
}

template<class Type>
void Stack<Type>::pop(){
    if(empty()) cout<<"栈已空,无法删除。"<<endl;
    else --index;
}

template<class Type>
Type Stack<Type>::top(){
    return st[index];
}

template<class Type>
Stack<Type>::Stack(int maxStackSize) :MaxSize(maxStackSize){
    st = new Type[MaxSize];
    index = -1;
}





//下面为正式的中缀表达式转为后缀表达式
void postfix(string s){
    
    //stack<char> stac;//用来存放运算符
    Stack<char> st(100);
   
    for(int i = 0; i < s.length(); i++){
        
        if(s[i] == '#'){//如果是终结符，则直接返回res
            while(!st.empty()){
                cout<<st.top();
                st.pop();
            }
            return;
        }
        
        if(s[i] == '(')//如果是左括号，直接进栈
            st.push(s[i]);
        
        if(s[i] == ')'){//如果是右括号，则将栈中的符号弹出，直至遇到左括号
            
            while(st.top() != '('){
                cout<<st.top();
                st.pop();
            }
            st.pop();//将左括号记得删除
        }
        
        if(s[i] == '+' || s[i] == '-'){//如果当前元素为‘+’或者‘-’
            
            
               while (!st.empty() && st.top() != '(') {
                    cout<<st.top();
                    st.pop();
                }
               
                st.push(s[i]);//栈中的元素全部弹出之后，再将当前元素入栈
           
        }
        
        
        if(s[i] == '*' || s[i] == '/'){//如果当前的元素为‘*’或者'/'
            
            if(st.empty()){
                 st.push(s[i]);
            }
            else if(st.top() == '+' || st.top() == '-'){
                st.push(s[i]);
            }
            else if(st.top() == '*' || st.top() == '/'){
                
                while (!st.empty()&&(st.top() == '*' || st.top() == '/')) {
                    cout<<st.top();
                    st.pop();
                }
                st.push(s[i]);
              
            }
            else{
                st.push(s[i]);
            }
           
        }
        
        if(s[i] > '0' && s[i] < '9'){
           cout<<s[i];
        }
    }
   
}


int main(int argc, const char * argv[]) {
    
    
    string s;
    cout<<"请输入要计算的表达式："<<endl;
    cin>>s;
    for(int i = 0;i < s.length(); i++){
        cout<<s[i]<<" ";
    }
    cout<<endl;
    string res;
    cout<<"后缀表达式如下:"<<endl;
    postfix(s);
    cout<<endl;

    return 0;
    
    
}

