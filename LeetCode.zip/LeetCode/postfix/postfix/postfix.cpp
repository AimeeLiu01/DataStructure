//  postfix.cpp
//  postfix
//
//  Created by 刘畅 on 2017/8/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*
 中缀表达式转后缀表达式的算法较为简单，采用栈来实现。规则如下：
 遇到数字：直接输出
 遇到'('：压栈
 遇到')'：持续出栈，如果出栈的符号不是'('则输出，否则终止出栈。
 
 遇到符号则判断该符号与栈顶符号的运算优先级，如果栈顶符号的运算优先级高，则出栈并输出，直到优先级相等或栈为空；
 如果栈顶符号的运算优先级低于或等于当前符号的运算优先级，则将当前符号压栈。
 
 处理完字符串后将栈中剩余的符号全部输出。
 */

#include <iostream>
#include <string>
#include <stack>
using namespace std;


int main1(){
    cout << "请输入要计算的式子（保证合法）" << endl;
    string in;
    cin >> in;
    stack<char> stack;
    
    for(size_t i = 0; i != in.size(); ++i){
        if(in[i] == ')' ){
            while(true ){
                char tmp = stack.top();
                stack.pop();
                if(tmp != '(' ){
                    std::cout << tmp;
                }
                else{
                    break;
                }
            }
        }
        else if (in[i] == '+' || in[i] == '-'){
            if(stack.top() == '*' || stack.top() == '/'){
                while(stack.top() == '*' || stack.top() == '/'){
                    cout << stack.top();
                    stack.pop();
                }
                cout << in[i];
            }
            else{
                stack.push(in[i]);
            }
        }
        else if (in[i] == '(' || in[i] == '*' || in[i] == '/' ){
            stack.push(in[i]);
        }
        else{
            cout << in[i];
        }
    }
    while(stack.size()){
        cout << stack.top();
        stack.pop();
    }
    
    return 0;
}
