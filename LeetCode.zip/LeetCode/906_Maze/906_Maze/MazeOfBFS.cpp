//
//  MazeOfBFS.cpp
//  906_Maze
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <queue>
#include <iostream>
using namespace std;

struct node{
    int x;
    int y;
    int pre;
}Node[100];

int maze[3][3];

int front = 0;
int rear = 1;

int dirX[4] = {0,-1,0,1};
int dirY[4] = {1,0,-1,0};

void printPath(int i){
    
    if(Node[i].pre != -1){
        printPath(Node[i].pre);
        cout<<"("<<Node[i].x<<","<<Node[i].y<<")"<<endl;
    }
    else{
        cout<<"("<<Node[i].x<<","<<Node[i].y<<")"<<endl;
    }
}

void BFS(int x, int y){
    
    //开始节点（出发）  前面此时没有结点
    Node[front].x = x;
    Node[front].y = y;
    Node[front].pre = -1;
  
    
    while (front < rear) {
        
        
        for (int i = 0; i < 4; i++) {
            
            int xx = Node[front].x + dirX[i];
            int yy = Node[front].y + dirY[i];
            
            if(xx < 0 || yy < 0 || xx > 2 || yy > 2 || maze[xx][yy]){
                continue;
            }
            else{//将可以走的点加入到路径中去
                
                maze[xx][yy] = 1;
                Node[rear].x = xx;
                Node[rear].y = yy;
                Node[rear].pre = front;
                rear++;
            }
            
            if(xx == 2 && yy == 2){
                printPath(rear-1);
                return;
            }
        }
        
        front++;
    }
    
    cout<<"There is no way."<<endl;
    
    
    
}


int main(){
    
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin>>maze[i][j];
        }
    }
    BFS(0, 0);
    return 0;
}
