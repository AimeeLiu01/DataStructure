//
//  main.cpp
//  906_Maze
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//  迷宫问题
//  1.先考虑迷宫问题是否有出路

/*#include <iostream>
#include <stack>
using namespace std;


int dirX[4] = {1,0,-1,0};
int dirY[4] = {0,1,0,-1};

void printStack(stack<pair<int, int>> stk){
    
    stack<pair<int, int>> tmp;
    while (!stk.empty()) {
        auto n = stk.top();
        stk.pop();
        tmp.push(n);
    }
    while (!tmp.empty()) {
        auto n = tmp.top();
        cout<<"("<<n.first<<","<<n.second<<")"<<endl;
        tmp.pop();
    }
    
}
void DfsStack(int **maze, bool **visited, int row, int col, int x, int y){
    
    stack<pair<int, int>> stk;
    stk.push(make_pair(x, y));
    visited[x][y] = true;
    
    while (!stk.empty()) {
        auto n = stk.top();
        int x = n.first;
        int y = n.second;
        if(x == row-1 && y == col-1){
            printStack(stk);
            return;
        }
        
        for (int k = 0; k < 4; k++) {
            int xx = x + dirX[k];
            int yy = y + dirY[k];
            if(xx < 0 || xx >= row || yy < 0 || yy >= col || maze[xx][yy] == 1 || visited[xx][yy] == true)
                continue;
            else{
                stk.push(make_pair(xx, yy));
                visited[xx][yy] = true;
                break;//找到了一个可以走的方向之后 要跳出循环

            }
        }
        auto tmp = stk.top();
        if(tmp == n){
            stk.pop();
        }
        
    }
    
    cout<<"There is no way."<<endl;
}

int main(int argc, const char * argv[]) {
   
    int row, col;
    cin>>row>>col;
    int **maze = new int*[row];
    for (int i = 0; i < row; i++) {
        maze[i] = new int[col];
        for (int j = 0; j < col; j++) {
            cin>>maze[i][j];
        }
    }
    
    bool **visited = new bool*[row];
    for (int i = 0; i < row; i++) {
        visited[i] = new bool[col];
        for (int j = 0; j < col; j++) {
            visited[i][j] = false;
        }
    }
    DfsStack(maze,visited, row, col, 0, 0);

    return 0;
    
    
}*/
