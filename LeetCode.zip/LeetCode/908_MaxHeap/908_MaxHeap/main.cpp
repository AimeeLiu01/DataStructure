//
//  main.cpp
//  908_MaxHeap
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

class MaxHeap{
    
public:
    MaxHeap(int x);
    bool isEmpty();
    bool isFull();
    void Insert(int x);
    void Delete();
    int top();
    int size();
private:
    int *heap;
    int Maxsize;
    int n;
    
};


MaxHeap::MaxHeap(int x){
    Maxsize = x;
    n = 0;
    heap = new int[Maxsize+1];
}

bool MaxHeap::isFull(){
    if(n == Maxsize)
        return true;
    else
        return false;
}

bool MaxHeap::isEmpty(){
    if(n == 0)
        return true;
    else
        return false;
}

void MaxHeap::Insert(int x){
    if(isFull()){
        cout<<"The heap is full, can't insert into it."<<endl;
        return;
    }
    ++n;
    int i;
    for (i = n; i > 1; ) {
        if(x <= heap[i/2])
            break;
        heap[i] = heap[i/2];
        i = i/2;
    }
    heap[i] = x;
    cout<<"We have insert "<<x<<" into the maxheap."<<endl;

}

void MaxHeap::Delete(){
    
    if(isEmpty()){
        cout<<"The heap is empty. can't delete."<<endl;
        return;
    }
    int k = heap[1];//删除的头结点元素
    int t = heap[n];//向上走的尾部元素  找到他的位置所在
    n--;
    
    int i ,j;
    for (i = 1, j = 2; j <= n; ) {
        
        if (j+1 <= n && heap[j+1] > heap[j]) {
            j = j+1;
        }
        if(t >= heap[j])
            break;
        
        heap[i] = heap[j];
        i = j;
        j = 2 * j;
    }
    heap[i] = t;
    
    cout<<"We have delete "<<k<<" successfully."<<endl;
    for (int i = 1; i <= n; i++) {
        cout<<heap[i]<<" ";
    }
    cout<<endl;
    
    
}

int MaxHeap::top(){
    cout<<"The top element is: "<<heap[1]<<endl;
    return heap[1];
}

int MaxHeap::size(){
    cout<<"The size of the heap is "<<n<<endl;
    return n;
}

int main() {
   
    MaxHeap mh = *new MaxHeap(3);
    mh.Insert(4);
    mh.Insert(5);
    mh.Insert(1);
    mh.Insert(7);
    mh.top();
    mh.Delete();
    mh.Delete();
    mh.top();
    mh.size();
    
    
    return 0;
}
