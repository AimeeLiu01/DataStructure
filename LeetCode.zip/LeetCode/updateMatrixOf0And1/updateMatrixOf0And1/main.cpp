//
//  main.cpp
//  updateMatrixOf0And1
//
//  Created by 刘畅 on 2017/8/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*
 本题为给定一个只有0喝1的矩阵，求每个点离0最近的位置
 我们新创建了一个ans  里面的每个元素均为INT_MAX
 我们对原数组进行遍历，如果值为0 我们将其放入队列 并将ans更新为0
 然后取出队列头元素 弹出 对其ans四周进行遍历
 如果其四周的值大于其值+1  代表其ans为无穷大  即原来数组中为1 我们将其ans值更新为其值（当前的ans值）+1
 */

#include <iostream>
#include <string>
#include <queue>
#include <vector>
using namespace std;


vector<vector<int>> updateMatrix(vector<vector<int>> &matrix){
    
    int dirX[] = {1,0,0,-1};
    int dirY[] = {0,1,-1,0};
    
    int row = matrix.size(), col = matrix[0].size();
    if(row == 0 || col == 0)
        return matrix;
    
    vector<vector<int>> ans(row, vector<int>(col,INT_MAX));
    queue<pair<int, int>> queue;
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            if(matrix[i][j] == 0){
                queue.push(make_pair(i, j));
                ans[i][j] = 0;
            }
        }
    }
    
    while (!queue.empty()) {
        auto n = queue.front();
        queue.pop();
        int x = n.first;
        int y = n.second;
        for(int k = 0; k < 4; k++){
            int xx = x + dirX[k];
            int yy = y + dirY[k];
            if(xx < 0 || xx >= row || yy < 0 || yy >= col)
                continue;
            if(ans[xx][yy] > ans[x][y] + 1){
                
                ans[xx][yy] = ans[x][y] + 1;
                queue.push(make_pair(xx, yy));
            }
        }
    }
    
    return ans;
    
}


int main3(int argc, const char * argv[]) {
    
    vector<vector<int>> matrix = {{0,0,0},{0,1,0},{1,1,1}};
    vector<vector<int>> ans = updateMatrix(matrix);
    int m = ans.size();
    int n = ans[0].size();
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            cout<<ans[i][j]<<" ";
        }
        cout<<endl;
    }
    

    
    
    return 0;
    
}
