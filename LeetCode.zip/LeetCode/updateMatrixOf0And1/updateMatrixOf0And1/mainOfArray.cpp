//
//  mainOfArray.cpp
//  updateMatrixOf0And1
//
//  Created by 刘畅 on 2017/8/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <string>
#include <iostream>
#include <queue>
using namespace std;


void updateGrid(){
    
    int dirX[] = {1,0,0,-1};
    int dirY[] = {0,1,-1,0};
    
    int row, col;
    cout<<"Please enter the row and col :"<<endl;
    cin>>row>>col;
    queue<pair<int, int>> queue;
    
    int **grid = new int*[row];
    for(int i = 0; i < row; i++){
        grid[i] = new int[col];
        for(int j = 0; j < col; j++){
            cin>>grid[i][j];
        }
    }
    
    int **ans = new int*[row];
    for(int i = 0; i < row; i++){
        ans[i] = new int[col];
        for(int j = 0; j < col; j++){
            ans[i][j] = INT_MAX;
        }
    }
    
    for(int i = 0; i < row; i++){
        for (int j = 0; j < col; j++) {
            if(grid[i][j] == 0){
                ans[i][j] = 0;
                queue.push(make_pair(i, j));
            }
        }
    }
    
    while (!queue.empty()) {
        auto n = queue.front();
        int x = n.first;
        int y = n.second;
        queue.pop();
        for(int k = 0; k < 4; k++){
            int xx = x + dirX[k];
            int yy = y + dirY[k];
            if(xx < 0 || xx >= row || yy < 0 || yy >= col)
                continue;
            if(ans[xx][yy] > grid[x][y] + 1){
                ans[xx][yy] = grid[x][y] + 1;
                queue.push(make_pair(xx, yy));
            }
        }
    }

    
    for(int i = 0; i < row; i++){
        for (int j = 0; j < col; j++) {
            cout<<ans[i][j]<<" ";
        }
        cout<<endl;
    }

    
}

int main(){
    

    
    updateGrid();
    updateGrid();
    
    return 0;
    
}
