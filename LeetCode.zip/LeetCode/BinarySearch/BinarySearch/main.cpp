//
//  main.cpp
//  BinarySearch
//  Aimee's code
//  Created by 刘畅 on 2017/8/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

int BinarySearch(int *a, const int x, const int n){//数组中一共有n个元素
    
    for(int left = 0, right = n-1; left <= right; ){
        
        int middle = (left+right)/2;
        if(x == a[middle])
            return middle;
        if(x > a[middle])
            left = middle+1;
        if(x < a[middle])
            right = middle-1;
        
    }
    return -1;
}

int main() {
    
    int a[6] = {2,5,8,10,23,45};
    int result;
    result = BinarySearch(a, 45, 6);
    cout<<"The result is : "<<result<<endl;
    return 0;
}
