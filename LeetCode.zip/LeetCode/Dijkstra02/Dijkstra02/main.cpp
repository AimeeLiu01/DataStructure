//
//  main.cpp
//  Dijkstra02
//  单源最短路径算法
//  Created by 刘畅 on 2017/9/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

const int maxNum = 100;
const int maxInt = 999999;

//各数组的下标均从1开始
//函数的意思是  一共有n个点 我们要找第v个点到各个点的最短距离
void Dijkrstra(int n, int v,int *dist, int *prev, int c[maxNum][maxNum]){
    
    
    bool s[maxNum] = {false};
    for (int i = 1; i <= n; i++) {
        dist[i] = c[v][i];
        s[i] = 0;
        if(dist[i] == maxInt)
            prev[i] = 0;
        else
            prev[i] = v;
    }
    
    //将1--1的距离变为0   并将其标记为以访问
    s[v] = 1;
    dist[v] = 0;
   
    
    //核心代码
    for(int i = 2; i <= n; i++){
        
        int tmp = maxInt;
        int u = v;
        for (int j = 1; j <= n; j++) {
            if(!s[j] && dist[j] < tmp){
                u = j;
                tmp = dist[j];
            }
        }
        //更新dist
        s[u] = 1;//代表找到的点
        for (int i = 1; i <= n; i++) {
            if(!s[i] && c[u][i] < maxInt){
               
                int newdist = dist[u] + c[u][i];
                if(newdist < dist[i]){
                    prev[i] = u;
                    dist[i] = newdist;
                }
            }
            
        }
    }
}
void searchPath(int *prev, int v, int u){
  
    
    if(prev[u] != v){
        searchPath(prev, v, prev[u]);
        cout<<u<<" ";
    }
    else{
        cout<<v<<" "<<u<<" ";
    }
}


int main(int argc, const char * argv[]) {
    
    
    
    int dist[maxNum];//表示当前点到源点的最短路径长度
    int prev[maxNum];//记录当前点的前一个结点
    int c[maxNum][maxNum];//记录图的两点间的路径长度
    int n,line;//代表图的结点数和路径数
    
    cin>>n;//输入路径数
    cin>>line;//输入结点数
    int p,q,len;//输入p,q以及其两点之间的路径长度
    
    //先初始化每两点之间的距离
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <=n ;j++){
            c[i][j] = maxInt;
        }
    }
    
    //将输入的数据录入到数组中
    for(int i = 1; i <= line; i++){
        cin>>p>>q>>len;
        if(len < c[p][q]){
            c[p][q] = len;
            c[q][p] = len;
        }
    }
    
    //将每个点到源点的距离都设置为max
    for (int i = 1; i <= n; i++) {
        dist[i] = maxInt;
    }
    
    //我们先尝试输出邻接矩阵
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cout<<c[i][j]<<" ";
        }
        cout<<endl;
    }
    
    //再进行最短路径的寻找
    Dijkrstra(n, 1, dist, prev, c);
    
    cout<<"源点到最后一个顶点的最短路径长度为："<<dist[n]<<endl;
    
    
    
    cout<<"源点到最后一个顶点的路径为：";
    searchPath(prev, 1, n);
    return 0;



}
