//
//  printPathRecur.cpp
//  906_Tree
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

struct TreeNode{
    
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
    
};
void printArray(int paths[], int pathLen){
    
    for(int i = 0; i < pathLen; i++){
        cout<<paths[i]<<" ";
    }
    cout<<endl;
}
void printRecursive(TreeNode *node, int paths[], int pathLen){//递归调用的函数  记得第三个参数为长度
    
    if(node == NULL)
        return;
    
    paths[pathLen] = node->val;
    pathLen++;
    if(node->left == NULL && node->right == NULL){
        printArray(paths, pathLen);
        return;
    }
    else{
        printRecursive(node->left, paths, pathLen);
        printRecursive(node->right, paths, pathLen);
    }
    
}
void printAllPaths(TreeNode *node){
    
    int paths[100];//用来存路径
    printRecursive(node, paths, 0);
    
}*/
