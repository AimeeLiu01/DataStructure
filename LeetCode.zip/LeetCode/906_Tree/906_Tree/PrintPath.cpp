//
//  PrintPath.cpp
//  906_Tree
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <iostream>
#include <stack>
#include <vector>
using namespace std;

struct TreeNode{
    
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
    
};

TreeNode* createTree(int arr[], int start, int length){
    
    if(start == length || arr[start] == '#')
        return NULL;
    
    TreeNode *root = new TreeNode(arr[start]);
    int left = 2 *  start + 1;
    int right = 2 * start + 2;
    if(left > length){
        root->left = NULL;
    }
    else if(arr[left] != 0){
        root->left = createTree(arr, left, length);
    }
    else{
        root->left = NULL;
    }
    
    if(right > length){
        root->right = NULL;
    }
    else if(arr[right] != 0){
        root->right = createTree(arr, right, length);
    }
    else{
        root->right = NULL;
    }
    
    return root;
    
}

void printArray(int arr[], int len){
    for(int i = 0; i < len; i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

void printPathsRecur(TreeNode *node ,int path[], int pathLen){
    
    if(node == NULL)
        return;
    path[pathLen] = node->val;
    pathLen++;
    if(node->left == NULL && node->right == NULL){
        printArray(path, pathLen);
    }
    else{
        printPathsRecur(node->left, path, pathLen);
        printPathsRecur(node->right, path, pathLen);
    }
    
}
void printPaths(TreeNode *node){
    int paths[100];
    printPathsRecur(node, paths, 0);
}


int main1(){
    
    int arr[7] = {1,2,3,0,5,6,7};
    TreeNode *tmp = createTree(arr, 0, 7);
    printPaths(tmp);
   
    return 0;
    
}
*/
