//
//  printPath_NonRecur.cpp
//  906_Tree
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;

struct TreeNode{
    
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
    
};

TreeNode* createTree(int arr[], int start, int length){
    
    if(start == length)
        return NULL;
    
    TreeNode *root = new TreeNode(arr[start]);
    int left = 2 *  start + 1;
    int right = 2 * start + 2;
    if(left > length){
        root->left = NULL;
    }
    else if(arr[left] != 0){
        root->left = createTree(arr, left, length);
    }
    else{
        root->left = NULL;
    }
    
    if(right > length){
        root->right = NULL;
    }
    else if(arr[right] != 0){
        root->right = createTree(arr, right, length);
    }
    else{
        root->right = NULL;
    }
    
    return root;
    
}

void printStack(stack<TreeNode*> stk){
    if(stk.empty())
        return;
    string res;
    while (!stk.empty()) {
        TreeNode *p = stk.top();
        res = to_string(p->val) + " " + res;
        stk.pop();
    }
    cout<<res<<endl;
}


void printAllRoad(int *tree, int length) {
    int *stack = new int[length];
    int index = -1;
    
    //初始化栈
    for (int i = 0; i < length; ++i) {
        stack[i] = 0;
    }
    
    //第一个节点入栈
    index++;
    stack[index] = 1;
    
    //弹栈打印，有右子树不弹栈。
    while (index != -1) {
        while (stack[index] * 2 < length && tree[stack[index] * 2] != -1) {
            //入栈
            index++;
            stack[index] = stack[index - 1] * 2;
            //检查是不是叶节点
            if (stack[index] * 2 >= length || tree[stack[index] * 2] == -1){
                if (stack[index] * 2 + 1 >= length || tree[stack[index] * 2 + 1] == -1){
                    //输出栈
                    for (int i = 0; i <= index ; ++i) {
                        cout << tree[stack[i]] << ",";
                    }
                    cout << endl;
                }
            }
        }
        
        while (true) {
            
            if (index == -1) {
                break;
            }
            
            //右子树没有遍历过就入栈
            if (stack[index] * 2 + 1 < length && tree[stack[index] * 2 + 1] != -1 &&
                tree[stack[index] * 2 + 1] != tree[stack[index + 1]]) {
                //右子树入栈，每次入栈都要检查一下是不是叶节点
                
                index++;
                stack[index] = stack[index - 1] * 2 + 1;
                
                if (stack[index] * 2 >= length || tree[stack[index] * 2] == -1){
                    if (stack[index] * 2 + 1 >= length || tree[stack[index] * 2 + 1] == -1){
                        //输出栈
                        for (int i = 0; i <= index ; ++i) {
                            cout << tree[stack[i]] << ",";
                        }
                        cout << endl;
                    }
                }
                
                //这个不能忘了，找到右子树就要结束弹栈过程
                break;
            }
            
            //输出并弹栈
            index--;
        }
    }
}


int main(){
    
    int arr[7] = {1,2,3,4,5,6,7};
    TreeNode *tmp = createTree(arr, 0, 7);

    
    return 0;
    
}
