//
//  main.cpp
//  906_Tree
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <iostream>
#include <stack>
using namespace std;

struct TreeNode{
    
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
    
};

TreeNode* createTree(int arr[], int start, int length){
    
    if(start == length || arr[start] == '#')
        return NULL;
    
    TreeNode *root = new TreeNode(arr[start]);
    int left = 2 *  start + 1;
    int right = 2 * start + 2;
    if(left > length){
        root->left = NULL;
    }
    else if(arr[left] != 0){
        root->left = createTree(arr, left, length);
    }
    else{
        root->left = NULL;
    }
    
    if(right > length){
        root->right = NULL;
    }
    else if(arr[right] != 0){
        root->right = createTree(arr, right, length);
    }
    else{
        root->right = NULL;
    }
    
    return root;
    
}

void PreOrder(TreeNode *root){
    
    TreeNode *p = root;
    stack<TreeNode *> stk;
    while (p || !stk.empty()) {
        
        while (p) {
            stk.push(p);
            cout<<p->val<<" ";
            p = p->left;
        }
        if(!stk.empty()){
            
            p = stk.top();
            stk.pop();
            p = p->right;
        }
    }
    cout<<endl;
}

void InOrder(TreeNode *root){
    
    TreeNode *p = root;
    stack<TreeNode*> stk;
    while (p || !stk.empty()) {
        
        while (p) {
            stk.push(p);
            p = p->left;
        }
        if(!stk.empty()){
            p = stk.top();
            cout<<p->val<<" ";
            stk.pop();
            p = p->right;
        }
    }
    cout<<endl;
}

void PostOrder(TreeNode *root){
    
    TreeNode *p = root;
    TreeNode *last = root;
    stack<TreeNode *> stk;
    stk.push(p);
    
    while (!stk.empty()) {
       
        p = stk.top();
        if((p->left == NULL && p->right == NULL) || (p->right == NULL && last == p->left) || last == p->right){
            cout<<p->val<<" ";
            last = p;
            stk.pop();
        }
        else{
            if(p->right){
                stk.push(p->right);
            }
            if (p->left) {
                stk.push(p->left);
            }
        }
    }
    cout<<endl;
}

int main(int argc, const char * argv[]) {
   
    
    int arr[7] = {1,2,3,0,5,6,7};
    TreeNode *tmp = createTree(arr, 0, 7);
    PreOrder(tmp);
    InOrder(tmp);
    PostOrder(tmp);
    return 0;
    
    
}*/
