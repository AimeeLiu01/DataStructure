//
//  main.cpp
//  IO_02
//
//  Created by 刘畅 on 2017/7/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    
    int a,b;
    while (cin>>a>>b && (a||b)) {
        cout<<a+b<<endl;
    }
    
    
    return 0;
}
