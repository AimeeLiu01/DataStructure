//
//  main.cpp
//  OJ_03
//
//  Created by 刘畅 on 2017/7/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    
    int n, sum, a;
    while (cin >> n && n) {
        sum = 0;
        while (n--) {
            cin>>a;
            sum += a;
        }
        cout<<sum<<endl;
    }
    
    return 0;
}
