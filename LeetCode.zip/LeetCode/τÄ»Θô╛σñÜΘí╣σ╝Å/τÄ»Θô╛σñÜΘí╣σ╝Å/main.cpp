//
//  main.cpp
//  环链多项式
//
//  Created by 刘畅 on 2017/8/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include "MutiExpression.h"
using namespace std;

int main(int argc, const char * argv[]) {
    
    
    MutiExpression* mutiExpression = new MutiExpression();
    
    mutiExpression->insertNewItem(new Item(1,2,0));
    mutiExpression->insertNewItem(new Item(1,1,0));
    mutiExpression->insertNewItem(new Item(1,3,0));
    
    *mutiExpression = *mutiExpression + *mutiExpression;
    
    cout<<*mutiExpression<<endl;
    
    delete mutiExpression;

    return 0;
}
