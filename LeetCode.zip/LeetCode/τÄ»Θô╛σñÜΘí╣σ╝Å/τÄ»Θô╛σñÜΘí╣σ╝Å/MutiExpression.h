//
//  MutiExpression.h
//  环链多项式
//
//  Created by 刘畅 on 2017/8/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#ifndef MUTIEXPRESSION_H
#define MUTIEXPRESSION_H

//这里是环链多项式的接口部分，我们为这个多项式添加加法操作
//所谓环链就是让链表的第一个节点是空的，然后最后一个节点可以指回来
#include <iostream>
using namespace std;


class Item;

class MutiExpression
{
    friend ostream& operator<<(ostream& out , MutiExpression& mutiExpression);
    
public:
    MutiExpression();
    ~MutiExpression();
    //按照次数插入节点
    void insertNewItem(Item *item);
    
    //重载加法运算符
    MutiExpression& operator+(MutiExpression& exp);
private:
    //表达式链表的首节点
    Item *first;
};


//节点的定义
class Item
{
    friend class MutiExpression;
    friend ostream& operator<<(ostream& out , MutiExpression& mutiExpression);
public:
    Item(int coef,int exp,Item* nextItem);
    
private:
    //系数
    int coef;
    //指数
    int exp;
    Item* nextItem;
};

#endif
