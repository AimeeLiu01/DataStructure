//
//  MutiExpression.cpp
//  环链多项式
//
//  Created by 刘畅 on 2017/8/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include "MutiExpression.h"
#include <ostream>
using namespace std;

MutiExpression::MutiExpression(){
    //初始化
    first = new Item(0,0,0);
    first->nextItem = first;
    //完成一个空结点自己指向自己的操作
}

//相加的函数
MutiExpression& MutiExpression::operator+(MutiExpression &exp){
    //创建一个多项式，然后每一位对应相加
    MutiExpression* mutiEcpression = new MutiExpression();
    
    //使用一个循环分别遍历两个表达式  两个遍历的指针
    Item* thisIndex = this->first->nextItem;
    Item* otherIndex = exp.first->nextItem;
    while (thisIndex != this->first && otherIndex != exp.first) {
        //看两个当前索引的指数大小
        if(thisIndex->exp == otherIndex->exp){
            //如果指数相等 就系数相加
            mutiEcpression->insertNewItem(new Item(thisIndex->coef+otherIndex->coef, thisIndex->exp,0));
            //让两个索引都往前走一步
            thisIndex = thisIndex->nextItem;
            otherIndex = otherIndex->nextItem;
        }
        
        //如果当前项的指数 大于  另一个当前项的指数
        if (thisIndex->exp > otherIndex->exp) {
            //这个时候我们让thisItem向前走，因为它的指数高，先被加入到结果中去
            mutiEcpression->insertNewItem(new Item(thisIndex->coef,thisIndex->exp,0));
            thisIndex = thisIndex->nextItem;
        }
        
        if(thisIndex->exp < otherIndex->exp){
            mutiEcpression->insertNewItem(new Item(otherIndex->coef,otherIndex->exp,0));
            otherIndex = otherIndex->nextItem;
        }
    }
    
    //解决剩下的多项式拷贝问题
    while (thisIndex->nextItem) {
        mutiEcpression->insertNewItem(new Item(thisIndex->coef,thisIndex->exp,0));
        thisIndex = thisIndex->nextItem;
    }
    
    while (otherIndex->nextItem) {
        mutiEcpression->insertNewItem(new Item(otherIndex->coef, otherIndex->exp,0));
        otherIndex = otherIndex->nextItem;
    }
    
    return *mutiEcpression;
    
}

void MutiExpression::insertNewItem(Item *item){
    //我们从我们把指数比较高的放在前面，从一开始扫描，然后找出应该插入的位置，如果发现有指数一样的，那就让系数相加
    //插入位置为指针
    //不要从空的位置开始
    Item *now = first->nextItem;
    Item *pass = first;
    //我们不断扫描
    while(true){
        if(now->exp == item->exp){
            //相同的指数就系数相加
            cout << "叠加" << endl;
            now->coef = item->coef + now->coef;
            return;
        }
        if (now->exp > item->exp)
        {
            //如果指数比要插入的元素大那就
            //他我们就继续找插入位置
            cout << "下一个" << endl;
            pass = now;
            now = now->nextItem;
        }
        if (now->exp < item->exp)
        {
            //如果指数比较少那么就应该插入在这个节点的前面
            //我们放在pass和now之间
            cout << "插入" << endl;
            pass->nextItem = item;
            item->nextItem = now;
            return;
        }
    }
    
    //这个时候一般是要插在尾部了
    // now->nextItem = item;
    // item->nextItem = first;
    // cout << "插入完毕" << endl;
}


MutiExpression::~MutiExpression(){
    
    
    //处理析构函数，使用一个while来一连串析构
    Item* now = first->nextItem;
    Item* pass = 0;
    while (now != pass) {
        pass = now;
        now = now->nextItem;
        delete pass;
        pass = 0;
    }
    delete first;
    

    
}


//打印
//这个函数也同时必须作为Item这个类的友元函数，因为这里会调用Item的私有数据成员
ostream& operator<<(ostream& out , MutiExpression& mutiExpression){
    
    //从第一个结点开始，我们要从第一个结点开始依次输出每个结点的内容
    Item* item = mutiExpression.first->nextItem;
    cout<<"开始输出"<<endl;
    while (item->nextItem != mutiExpression.first) {
        //不断输出
        out<<item->coef<<"x^"<<item->exp<<" ";
        item = item->nextItem;
    }
    
    //这个时候还有尾部一个节点
    if(item != mutiExpression.first){
        out<<item->coef<<"x^"<<item->exp<<" ";
    }
    return out;
}

Item::Item(int coef, int exp, Item* nextItem){
    
    this->coef = coef;
    this->exp = exp;
    this->nextItem = nextItem;
    
}


























