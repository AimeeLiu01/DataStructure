//
//  main.cpp
//  83. Remove Duplicates from Sorted List
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;

//去除链表中重复的元素  例如／1 1 1 2 2 5   返回1 2 5

struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution{
public:
    ListNode* deleteDuplicates(ListNode* head){
        
        if(head == NULL) return NULL;
        ListNode *cur = head;
        ListNode *next = NULL;
        
        while (cur != NULL) {
            
            next = cur->next;
            while (next != NULL && next->val == cur->val) {
                next = next->next;
            }
            cur->next = next;
            cur = next;
        }
        
        return head;
    }
    
};


int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(2);
    ListNode *node4 = new ListNode(2);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    
    Solution s = *new Solution();
    ListNode *result = s.deleteDuplicates(node1);
    
    while (result != NULL) {
        cout<<result->val<<" ";
        result = result->next;
    }
    
    cout<<endl;
    
    return 0;
}


