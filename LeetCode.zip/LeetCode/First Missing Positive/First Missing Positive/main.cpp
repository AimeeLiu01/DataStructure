//
//  main.cpp
//  First Missing Positive
//
//  Created by 刘畅 on 2017/6/12.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

class Solution{
public:
    vector<vector<string>> groupAnageams(vector<string> &strs){
        
        map<string, vector<string>> mp;
        vector<vector<string>> result;
        
        for(auto str : strs){
            string tem = str;
            sort(tem.begin(), tem.end());
            mp[tem].push_back(str);
        }
        
        for(auto val : mp){
            sort(val.second.begin(), val.second.end());
            result.push_back(val.second);
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
   
    vector<string> vec;
    vec.push_back("eat");
    vec.push_back("tea");
    vec.push_back("tan");
    vec.push_back("ate");
    vec.push_back("nat");
    vec.push_back("bat");
    Solution s = *new Solution();
   
    vector<vector<string>> re = s.groupAnageams(vec);
    
    for(int j = 0; j < re[0].size(); j++){
        cout<<re[0][j]<<" ";
    }
    cout<<endl;
    
    
    for(int k = 0; k < re[1].size(); k++){
        cout<<re[1][k]<<" ";
    }
    cout<<endl;
    

    for(int t = 0; t < re[2].size(); t++){
       cout<<re[2][t]<<" ";
    }
    cout<<endl;
}


    

    
