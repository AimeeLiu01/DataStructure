//
//  main.cpp
//  907_tpsort
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <queue>
#include <string>
using namespace std;

struct LinkNode{
    int val;
    LinkNode *next;
    LinkNode(int x){
        val = x;
        next = nullptr;
    }
};

struct Node{
    int val;
    LinkNode *head;
}Adj[100];

int inCount[100] = {0};

void createGraph(int &num){
    
    cin>>num;
    
    for (int i = 0; i < num; i++) {
        cout<<"Please enter the "<<i+1<<" node :";
        cin>>Adj[i].val;
        Adj[i].head = nullptr;
       
        cout<<"Please enter the number of linked node :";
        int count;
        cin>>count;
        
        for (int j = 0; j < count; j++) {
            int temp;
            cin>>temp;
            ++inCount[temp];
            LinkNode *p = new LinkNode(temp);
            p->next = Adj[i].head;
            Adj[i].head = p;
        }
    }
    
    cout<<"Now cout the node and their incount: "<<endl;
    for (int i = 0; i < num; i++) {
        cout<<Adj[i].val<<" ";
        cout<<inCount[Adj[i].val]<<endl;
    }
    
}

void tpsort(int &num){
    
    stack<int> stk;
    int showNum = 0;
    for (int i = 0; i < num; i++) {
        
        if(inCount[Adj[i].val] == 0){
            stk.push(Adj[i].val);
        }//先将入度为0的点放入栈中
    }
    
    while (!stk.empty()) {
        int n = stk.top();
        cout<<n<<" ";
        stk.pop();
        ++showNum;
        
        int index = 0;
        for (int i = 0; i < num; i++) {
            if(Adj[i].val == n){
                index = i;
                break;
            }
        }
       
        LinkNode *p = Adj[index].head;
        while (p != NULL) {
            --inCount[p->val];
            if(inCount[p->val] == 0){
                stk.push(p->val);
            }
            p = p->next;
        }
        
    }
    
    cout<<endl;
    if(showNum < num)
        cout<<"There is cycle."<<endl;
}




int main(int argc, const char * argv[]) {
    
    int num = 0;
    createGraph(num);
    cout<<"The tpsort is :"<<endl;
    tpsort(num);
    return 0;

}

