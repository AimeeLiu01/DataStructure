//
//  main.cpp
//  ACM-02
//
//  Created by 刘畅 on 2017/7/9.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <fstream>
using namespace std;

void move(int n, char x, char y)
{
    cout<<"move "<<n<<" from "<<x<<" to "<<y<<endl;
}

void Hannoi(int n, char a, char b, char c){
    if(n == 1)
        move(1,a,c);
    else{
        Hannoi(n-1, a, c, b);
        move(n,a,c);
        Hannoi(n-1, b, a, c);
    }
}

int main(int argc, const char * argv[]) {
    // insert code here...
    int n;
    cin>>n;
    Hannoi(n, 'a', 'b', 'c');
    return 0;
}
