//
//  main.cpp
//  908_dp
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <iostream>
using namespace std;

int dp[10] = {0};

int calc(int n){
    
    if(n == 1 || n == 2){
        dp[n] = n;
        return dp[n];
    }
   
    if(dp[n-1] == 0)
        dp[n-1] = calc(n-1);
    if(dp[n-2] == 0)
        dp[n-2] = calc(n-2);
   
    return dp[n-1] + dp[n-2];
    
    
}

int main(int argc, const char * argv[]) {
  
    int n;
    cin>>n;
    int res = calc(n);
    cout<<res<<endl;
    return 0;
}*/
