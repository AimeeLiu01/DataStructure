//
//  dp03.cpp
//  908_dp
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

int dp[4][4] = {};//生成动态规划表

int main(){
    
    int arr[4][4];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cin>>arr[i][j];
        }
    }
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            dp[i][j] = INT_MAX;
        }
    }
    
    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 4; col++) {
            if(row == 0 && col == 0)
                dp[row][col] = arr[row][col];
            else if(row == 0 && col != 0)
                dp[row][col] = dp[row][col-1] + arr[row][col];
            else if(row != 0 && col == 0)
                dp[row][col] = dp[row-1][col] + arr[row][col];
            else
                dp[row][col] = max(dp[row-1][col], dp[row][col-1]) + arr[row][col];
            
        }
    }
    
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }
    
    return 0;
    
    
}
*/
