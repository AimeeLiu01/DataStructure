//
//  dp02.cpp
//  908_dp
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

int dp[10] = {1,1,1,1,1,1,1,1,1,1};

void calc(int arr[], int size){
    
    dp[0] = 1;
    for (int i = 1; i < size; i++) {
        
        for (int j = 0; j < i; j++) {
            if(arr[i] > arr[j] && dp[j] >= dp[i]){
                dp[i] = dp[j] + 1;
            }
        }
    }
    
    
    
}


int main(){
    
    int arr[8] = {3,4,6,2,5,1,8,10};
    calc(arr,8);
    int n = 0;
    for (int i = 0; i < 8; i++) {
        if(n < dp[i]){
            n = dp[i];
        }
    }
    cout<<n<<endl;
    return 0;
}*/
