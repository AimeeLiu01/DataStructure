//
//  dp05.cpp
//  908_dp
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

int main(){
    
    int n = 4;//代表有4件物品
    int cap = 10;//代表背包的承重
    int v[4] = {4,32,40,5};
    int w[4] = {7,3,4,5};
    
    int dp[5][11];
    
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= cap; j++) {
            if(j - w[i] >= 0){
                dp[i][j] = max(dp[i-1][j], dp[i-1][j-w[i-1]] + v[i-1]);
            }
            else
                dp[i][j] = dp[i-1][j];
        }
    }
    
    cout<<dp[n][cap]<<endl;
    return 0;
    
}
