//
//  dp04.cpp
//  908_dp
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <string>
#include <iostream>
using namespace std;


int findLCS(string A, int m, string B, int n){
    
    int dp[500][500] = {0};
    
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if(A[i] == B[j]){
                dp[i+1][j+1] = dp[i][j] + 1;
            }
            else{
                dp[i+1][j+1] = max(dp[i][j+1], dp[i+1][j]);
            }
        }
    }
    
    return dp[m][n];

    
    
}

int main(){
    
    string A = "ABCSSER";
    string B = "ACDER";
    int res = findLCS(A,7,B,5);
    cout<<res<<endl;
    return 0;
}*/
