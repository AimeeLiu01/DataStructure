//
//  main.cpp
//  tpSort02
//
//  Created by 刘畅 on 2017/9/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//  topSort的邻接表实现

#include <iostream>
#include <stack>
using namespace std;

const int MaxSize = 10;//结点的最大个数

//后面邻接的结点们
struct LinkNode{
    int vex;
    LinkNode *next;
};

//代表的是头结点
struct Node{
    int data;
    LinkNode *head;
}Adj[MaxSize];

int inCount[100];//代表的是每个点的入度

//创建一个邻接链表
void createLink(int &numNode){
    int numLink = 0;
    LinkNode *ptr;
    cout<<"请输入有多少个结点：";
    cin>>numNode;//输入有多少个结点
    
    for(int i = 1; i <= numNode; i++){
        Adj[i].head = 0;//将头结点的指针置为0
        cout<<"Please input the "<<i<<" node's data : ";
        cin>>Adj[i].data;//输入节点值
        cout<<"Please input the number of node which is linked to it: ";
        cin>>numLink;//输入节点相连接的节点的个数
        
        //头插入进行建表
        for (int j = 0; j < numLink; j++) {
            ptr = new LinkNode;
            cout<<"请分别输入结点的值:"<<endl;
            cin>>ptr->vex;
            ++inCount[ptr->vex];//对应的值入度+1
            ptr->next = Adj[i].head;
            Adj[i].head = ptr;//头结点指向插入的点
        }
        
    }
    
}

void tpSort(int &numNode){
    stack<int> stk;
    LinkNode *p;
    int showNum = 0;//记录的是输出的节点的数目
    
    for(int i = 1; i <= numNode; i++){
        if(inCount[Adj[i].data] == 0)
            stk.push(Adj[i].data);
    }
    
    //栈为空时
    while (!stk.empty()) {
        int v = stk.top();
        stk.pop();
        cout<<v<<" ";
        
        int tempIndex = 0;
        for(int i = 1; i <= numNode; i++){
            if(Adj[i].data == v){
                tempIndex = i;
                break;
            }
        }
        
        ++showNum;//打印结点+1
        
        p = Adj[tempIndex].head;
        while (p != NULL) {
           
            --inCount[p->vex];
            if(inCount[p->vex] == 0)
                stk.push(p->vex);
            p = p->next;
        }
        cout<<endl;
        
    }
    
    if(showNum < numNode)
        cout<<"该图中含有环。"<<endl;

}


int main(int argc, const char * argv[]) {
    
    int num = 0;
    createLink(num);
    tpSort(num);
    return 0;
}
