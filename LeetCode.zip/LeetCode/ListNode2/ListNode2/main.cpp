//
//  main.cpp
//  ListNode2
//
//  Created by 刘畅 on 2017/8/26.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <math.h>
#include <string>

using namespace std;

struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x): val(x), next(nullptr){}
};

//1）.单链表的创建
ListNode *create(){
    ListNode *head = new ListNode(-1);
    ListNode *cur = head;
    ListNode *node = nullptr;
    
    int x = 0;
    
    while (1) {
        cout<<"please input your data : ";
        cin>>x;
        if(x != -1){
            node = new  ListNode(x);
            cur->next = node;
            cur = node;
        }
        else{
            break;
        }
    }
    cur->next = nullptr;//尾结点置为空
    return head;
}


//2）.单链表的打印
void printList(ListNode *head){
    
    if(head->next == NULL){
        cout<<"The list is null."<<endl;
    }
    ListNode *p = head->next;
    while (p != nullptr) {
        cout<<p->val<<" ";
        p = p->next;
    }
    cout<<endl;
}


//1.实现单链表的反转
ListNode *reverse(ListNode *head){
    
    if(head->next == NULL){
        return nullptr;
    }
    ListNode *p = head->next;
    ListNode *q = head->next;
    ListNode *pre = NULL;
    
    while (p != NULL) {
        q = p->next;
        p->next = pre;
        pre = p;
        p = q;
    }
    
    head->next = pre;
    return head;
    
    
}

//2.逆序输出单链表的元素
void printReverse1(ListNode *head){
    stack<ListNode*> stk;
    ListNode *p = head->next;
    
    while (p != NULL) {
        stk.push(p);
        p = p->next;
    }
    
    while (!stk.empty()) {
        auto t = stk.top();
        stk.pop();
        cout<<t->val<<" ";
    }
    
}

//2.逆序输出单链表的元素  递归方法
void printReverse2(ListNode *head){
    
    if(head->next != NULL){
        printReverse2(head->next);
        cout<<head->next->val<<" ";
    }
}


//3.题目，从尾到头输出一个字符串；
//  定义一个函数求字符串的长度，要求该函数体中不能声明任何一个变量； 要求不使用额外变量，实现strlen函数：
int getLen(char *str)
{
    if(*str == '\0')
        return 0;
    
    return getLen(str + 1) + 1;
}



//4.判断单链表是否有环
bool hasCycle(ListNode *head){
    
    if(head->next == NULL)
        return false;
    ListNode *slow = head->next;
    ListNode *fast = head->next;
    
    while (fast != NULL && fast->next != NULL && fast->next->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
        if(slow == fast)
            return true;
    }
    return false;

}


//5.单链表之删除链表的重复元素
/*
 方法一：使用hash表，时间复杂度O(n)，空间复杂度O(n)
 1、建立一个hash表，key为链表中已遍历的节点内容，开始时为空；
 2、从头开始遍历链表中的节点
 1）如果节点内容已经在hash中了，则删除此节点，继续向后遍历；
 2）如果节点内容不在hash中，则保留此节点，将节点内容添加到hash中，继续遍历
 */

ListNode* deleteDuplicateFromUnorderList(ListNode *head){
    if(head->next == NULL || head->next->next == NULL){
        return head;
    }
    int visited[1000] = {false};
    ListNode *pre = head;
    ListNode *cur = head->next;
    ListNode *tmp = nullptr;
    
    while (cur != nullptr) {
        if(visited[cur->val]){
            tmp = cur;
            pre->next = cur->next;
            cur = cur->next;
            delete tmp;
        }
        else{
            visited[cur->val] = true;
            pre = pre->next;
            cur = cur->next;
        }
    }

    return head;
    
}


//6. 将两个有序链表合成一个有序链表
ListNode *mergeRecursive(ListNode *head1, ListNode *head2){
    if(head1 == nullptr)
        return head2;
    if(head2 == nullptr)
        return head1;
    
    ListNode *newHead = nullptr;
    if(head1->val < head2->val){
        newHead->next = head1;
        newHead->next->next = mergeRecursive(head1->next, head2);
    }
    else{
        newHead->next = head2;
        newHead->next->next = mergeRecursive(head1, head2->next);
    }
    return newHead;
}


//7.当两个链表均无环时，求他们的第一个公共结点
ListNode *findFirstCommonNode1(ListNode *head1, ListNode *head2){
    
    if(head1->next == NULL || head2->next == NULL)
    {
        cout<<"空链表，无公共结点。"<<endl;
        return nullptr;
    }
    ListNode *p1 = head1->next;
    ListNode *p2 = head2->next;
    while (p1 != NULL) {
        while (p2 != NULL) {
            if(p1 == p2){
                cout<<"存在公共结点。"<<endl;
                return p1;
            }
            else{
                p2 = p2->next;
            }
        }
        p1 = p1->next;
    }
    return nullptr;
}



int main(int argc, const char * argv[]) {
    
    
    ListNode *tmp = create();
    printList(tmp);
    printReverse1(tmp);
    cout<<endl;
    printReverse2(tmp);
    cout<<endl;
    
    char *my = "hellp";
    
    int size = getLen(my);
    cout<<size<<endl;
    
    
    return 0;
    
    
    
    
    
    
    
    
    
    
    
}
