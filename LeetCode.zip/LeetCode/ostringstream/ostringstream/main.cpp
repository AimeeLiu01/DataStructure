//
//  main.cpp
//  ostringstream
//
//  Created by 刘畅 on 2017/6/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <sstream>
using namespace std;

int main(int argc, const char * argv[]) {
    
    ostringstream ostr("1234");
    cout<<ostr.str()<<endl;//输出1234
    
    ostr.put('5');
    cout<<ostr.str()<<endl;
    
    ostr<<67;
    string str = ostr.str();
    
    cout<<str<<endl;
    return 0;
    
}
