//***********首先我们来实现单链表*************************
//头结点：单链表的开始节点之附设一个【类型相同】的节点，称之为头结点；
//头节点的指针域存储指向开始结点的指针，即第一个元素结点的存储位置；

/*头结点的作用：
1、对带头结点的链表，在表的任何结点之前插入结点或删除表中任何结点，所要做的都是修改前一结点的指针域，因为任何元素结点都有前驱结点。若链表无头结点，则首元素结点无前驱结点，在其前插入结点或删除该结点时操作会复杂些；
2、对带头结点的链表，表头指针是指向首节点的非空指针，因此空表和非空表的处理是一样的；*/

//通常要对链表的开始节点进行操作时，最好添加个头结点。

#include <iostream>
using namespace std;

struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(0){}
};

//1.单链表的创建
ListNode *create(){
    ListNode *head = new ListNode(-1);
    ListNode *cur = head;
    ListNode *node = nullptr;
    
    int x = 0;
   
    while (1) {
        cout<<"please input your data : ";
        cin>>x;
        if(x != -1){
            node = new  ListNode(x);
            cur->next = node;
            cur = node;
        }
        else{
            break;
        }
    }
    cur->next = nullptr;//尾结点置为空
    return head;
}

    
//2.单链表的打印
void printList(ListNode *head){
    
    if(head->next == NULL){
        cout<<"The list is null."<<endl;
    }
    ListNode *p = head->next;
    while (p != nullptr) {
        cout<<p->val<<" ";
        p = p->next;
    }
    cout<<endl;
}

//3.求单链表的长度
int getLength(ListNode *head){
    
    if(head->next == nullptr)
        return 0;
    return 1 + getLength(head->next);
}

//4.求单链表的长度 非递归
int getLengthofCount(ListNode *head){
    
    int count = 0;
    if(head->next == NULL)
        return 0;
    
    ListNode *p = head->next;
    while (p != NULL) {
        ++count;
        p = p->next;
    }
    
    return count;
    
}

//5.单链表的插入操作  将值为data的元素插入到链表的第i（i=pos)个结点上
//那么我们就要寻找前i-1个结点  因此单链表插入操作的时间复杂度为O(n)
/*插入链表分情况讨论：在链表中第i（i从0开始取值）个位置插入
 插入到链表的首部、中间、尾部
*/
ListNode* insertList(ListNode *head, int pos, int data){
    
    ListNode *newNode = new ListNode(data);
    
    ListNode *p = head;//头结点
    int index = 1;//
    
    while (p != NULL && index < pos) {
        p = p->next;
        ++index;
    }
    
    newNode->next = p->next;
    p->next = newNode;
    return head;
    
}

//6.单链表的删除操作
ListNode *deleteNode(ListNode *head, int pos)//pos从1开始，1表示删除链表的头元素
{
    ListNode *p =head;//p开始指向头结点
    if(p->next == NULL){//没有元素  直接返回
        cout<<"The ListNode is Empty."<<endl;
        return nullptr;
    }
    
    ListNode *node = nullptr;
    int index = 1;
    while (p != NULL && index < pos) {
        p = p->next;//p指向要删除的结点的位置
        index++;
    }
    
    if(p != NULL && p->next != NULL){//
        
        node = p->next;// node 指向要删除的元素
        p->next = node->next;//前后连接
        delete node;
    }
    return head;
}

//7.单链表之删除单链表的头元素
void deleteHead2(ListNode *head){//这里的head为链表的头结点
    
   
    ListNode *node = head->next;
    head->next = node->next;
    delete node;
    
}


//8.查找链表中的第i个节点
ListNode *searchNode(ListNode *head, int pos){//这里的head为链表的头结点 而非头元素
    
    if(head->next == nullptr || pos < 0)
        return nullptr;
    
    if(pos == 0)
        return head;
    
    ListNode *p = head->next;
    int count = 1;
    while (count < pos) {
        p = p->next;
        if(p == nullptr){
            cout<<"Incorrect position to search node!"<<endl;
            break;
        }
        ++count;
    }
    cout<<p->val<<endl;
    return p;
    
}

//9. 查找单链表的中间结点
ListNode *searchMiddleNode(ListNode *head){
    if(head->next == NULL) return head;
    
    ListNode *slow = head->next;
    ListNode *fast = head->next;
    
    //当链表长度为奇数时，此时slow指向的即为中间节点；当链表长度为偶数时，此时slow及slow的下一个元素均为中间节点
    while (fast != NULL && fast->next != NULL && fast->next->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }
    cout<<slow->val<<endl;
    return slow;
}


//10. 查找单链表中倒数第k个元素
/*
 两种方法
 1.需要遍历两次链表，先求链表的长度len,然后遍历len-k的距离即可查找到单链表的倒数第k个节点
 2.遍历一次链表，时间复杂度为O(n),设置两个指针p1,p2.让p2先走k-1步，然后p1、p2再同时走，当p2走到链表尾部时，p1所指位置就是要找的结点
 */
ListNode *searchReverseKthNode(ListNode *head, int k){
    
    if(head->next == NULL || k == 0)
        return head;
    
    ListNode *p1 = head->next;
    ListNode *p2 = head->next;
    while (p2 != NULL && --k) {
        p2 = p2->next;
    }
    while (p2->next != NULL) {
        p1 = p1->next;
        p2 = p2->next;
    }
    cout<<p1->val<<endl;
    return p1;
}






int main(){
    
    cout<<"Now, Let's test the 1 function: 单链表的创建"<<endl;
    ListNode *node = create();
    cout<<"Now, Let's test the 2 function: 单链表的遍历"<<endl;
    printList(node);
    cout<<"Now, Let's test the 3 function: 求单链表的元素个数(递归）:"<<endl;
    int size = getLength(node);
    cout<<size<<endl;
    cout<<"Now, Let's test the 4 function: 求单链表的元素个数(非递归）:"<<endl;
    int size2 = getLengthofCount(node);
    cout<<size2<<endl;
    cout<<"Now, Let's test the 5 function: 将值为data的元素插入到链表的第i（i=pos)个结点上）:"<<endl;
    insertList(node, 4, 8);
    printList(node);
    cout<<"Now, Let's test the 6 function: 单链表的删除操作: "<<endl;
    deleteNode(node, 2);
    printList(node);
    cout<<"Now, Let's test the 7 function: 删除单链表的头结点: "<<endl;
    deleteHead2(node);
    printList(node);
    cout<<"Now, Let's test the 8 function: 查找单链表的第i个结点: "<<endl;
    searchNode(node, 3);
    
    cout<<"Now, Let's test the 9 function: 查找单链表的中间结点: "<<endl;
    searchMiddleNode(node);
    
    cout<<"Now, Let's test the 10 function: 查找单链表中倒数第k个元素: "<<endl;
    searchReverseKthNode(node, 3);
    
    return 0;


}
    


    
    
    
    

