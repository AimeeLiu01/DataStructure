//
//  PreTraversal.cpp
//  Tree28
//
//  Created by 刘畅 on 2017/8/28.
//  Copyright © 2017年 刘畅. All rights reserved.
//  前序遍历的非递归算法

/*#include <stdio.h>
#include <stack>
#include <queue>
#include <iostream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};


//栈的实现
template<class Type>
class Stack{
public:
    Stack(int x);
    bool isEmpty();
    bool isFull();
    void push(Type x);
    void pop();
    Type top();
    int getSize();
    
private:
    
    Type *stk;
    int maxsize;
    int topIndex;
    
    
};

template<class Type>
Stack<Type>::Stack(int x){
    maxsize = x;
    stk = new Type[maxsize];
    topIndex = -1;
}

template<class Type>
bool Stack<Type>::isEmpty(){
    if(topIndex == -1)
        return true;
    else
        return false;
}

template<class Type>
bool Stack<Type>::isFull(){
    if(topIndex == maxsize-1)
        return true;
    else
        return false;
}

template<class Type>
int Stack<Type>::getSize(){
    return topIndex+1;
}

template<class Type>
void Stack<Type>::push(Type x){
    topIndex++;
    stk[topIndex] = x;
}

template<class Type>
void Stack<Type>::pop(){
    
    --topIndex;
}


template<class Type>
Type Stack<Type>::top(){
    return stk[topIndex];
}


template<class Type>
class Queue{
public:
    Queue(int x);
    bool isEmpty();
    bool isFull();
    void push(Type x);
    void pop();
    Type front();
    int getSize();
    
private:
    
    Type *que;
    int maxsize;
    int frontIndex;
    int rearIndex;
    
    
};

//下面是   队列类
template<class Type>
Queue<Type>::Queue(int x){
    maxsize = x;
    que = new Type[maxsize];
    frontIndex = 0;
    rearIndex = 0;
}

template<class Type>
bool Queue<Type>::isEmpty(){
    if(frontIndex == rearIndex)
        return true;
    else
        return false;
}

template<class Type>
bool Queue<Type>::isFull(){
    if(rearIndex == maxsize-1)
        return true;
    else
        return false;
}

template<class Type>
int Queue<Type>::getSize(){
    return rearIndex-frontIndex;
}

template<class Type>
void Queue<Type>::push(Type x){
    
    que[rearIndex] = x;
    ++rearIndex;
}

template<class Type>
void Queue<Type>::pop(){
    
    ++frontIndex;
}


template<class Type>
Type Queue<Type>::front(){
    return que[frontIndex];
}
*/
/********************************************************************************/
//树的非递归前序遍历
/*void PreOrderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    TreeNode *p = root;
    Stack<TreeNode*> s(100);
    
    while (!s.isEmpty() || p) {
        if(p){
            cout<<p->val<<" ";
            s.push(p);
            p = p->left;
        }
        else{
            p = s.top();
            s.pop();
            p = p->right;
        }
    }
}

//树的非递归中序遍历
void InOrderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    TreeNode *p = root;
    Stack<TreeNode*> s(100);
    while (!s.isEmpty() || p) {
        
        if(p){
            s.push(p);
            p = p->left;
        }
        else{
            p = s.top();
            s.pop();
            cout<<p->val<<" ";
            p = p->right;
        }
    }
}

//树的非递归后序遍历
void PostOrderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    
    Stack<TreeNode*> s(100);
    TreeNode *p = root;
   
    s.push(p);
    TreeNode *lastVisit = root;
    
    while (!s.isEmpty()) {
        
        p = s.top();
        if((p->left == NULL && p->right == NULL) || (p->right == NULL && lastVisit == p->left) || lastVisit == p->right){
            cout<<p->val<<" ";
            s.pop();
            lastVisit = p;
        }
        else{
           if(p->right)
              s.push(p->right);
           if(p->left)
              s.push(p->left);
        }
    }
}

//树的广度优先遍历  利用队列
void BFS(TreeNode *root){
    
    Queue<TreeNode *> q(100);
    TreeNode *p = root;
    q.push(p);
    
    while (!q.isEmpty()) {
        
        p = q.front();
        cout<<p->val<<" ";
        q.pop();
        if(p->left)
            q.push(p->left);
        if(p->right)
            q.push(p->right);
    }
}

//打印树的所有路径
void prints(int paths[], int len) {
    
    for (int i = 0; i < len; i++) {
        cout<<paths[i]<<" ";
    }
    cout<<endl;
}
void printPathsRecur(TreeNode *root, int paths[], int len){
    
    if(root == NULL){
        return;
    }
    
    paths[len] = root->val;
    len++;
    
    if(root->left == NULL && root->right == NULL){
        prints(paths, len);
    }
    
    printPathsRecur(root->left, paths, len);
    printPathsRecur(root->right, paths, len);
    
    
}

int printPath(TreeNode *root){
    
    int paths[100];
    printPathsRecur(root, paths, 0);
    return 0;
}


//main函数
int main(){
    
    TreeNode *root = new TreeNode(1);
    TreeNode *n1 = new TreeNode(3);
    TreeNode *n2 = new TreeNode(4);
    TreeNode *n3 = new TreeNode(5);
    TreeNode *n6 = new TreeNode(7);
    root->left = n1;
    root->right = n2;
    n1->left = n3;
    n1->right = n6;
    cout<<"PreOrder is: ";
    PreOrderTraversal(root);
    cout<<endl;
    
    cout<<"InOrder is: ";
    InOrderTraversal(root);
    cout<<endl;
    
    cout<<"PostOrder is: ";
    PostOrderTraversal(root);
    cout<<endl;
    
    cout<<"BFS is: ";
    BFS(root);
    cout<<endl;
    
    cout<<"print paths: "<<endl;
    printPath(root);
    return 0;

}*/
