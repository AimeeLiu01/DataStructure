//
//  main.cpp
//  Tree28
//
//  Created by 刘畅 on 2017/8/28.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(NULL),right(NULL){}
};

void printArray(int path[], int len){
    
    for(int i = 0; i < len; i++){
        cout<<path[i]<<" ";
    }
    cout<<endl;
}

void printPathsRecur(TreeNode* node, int path[], int pathLen){
    if(node == NULL)
        return;
    path[pathLen] = node->val;
    pathLen++;
    
    if(node->left == NULL && node->right == NULL){
        printArray(path,pathLen);
    }
    else{
        printPathsRecur(node->left, path, pathLen);
        printPathsRecur(node->right, path, pathLen);
    }
}


void printPaths(TreeNode *root){
    int path[1000];
    printPathsRecur(root, path, 0);
}



int main3(int argc, const char * argv[]) {
    
    
    TreeNode *root = new TreeNode(1);
    TreeNode *n1 = new TreeNode(3);
    TreeNode *n2 = new TreeNode(4);
    TreeNode *n3 = new TreeNode(5);
    TreeNode *n6 = new TreeNode(7);
    root->left = n1;
    root->right = n2;
    n1->left = n3;
    n1->right = n6;
    
    printPaths(root);
    
    return 0;
}
