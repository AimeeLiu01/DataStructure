#include <iostream>
#include <string>
using namespace std;

void printAllRoad(int *tree, int length) {
    
    int *stack = new int[length];
    int stackTopIndex = -1;
    
    //初始化栈
    for (int i = 0; i < length; ++i) {
        stack[i] = 0;
    }
    
    //第一个节点入栈
    stackTopIndex++;
    stack[stackTopIndex] = 1;
    
    //弹栈打印，有右子树不弹栈。
    while (stackTopIndex != -1) {
        while (stack[stackTopIndex] * 2 < length && tree[stack[stackTopIndex] * 2] != -1) {
            //入栈
            stackTopIndex++;
            stack[stackTopIndex] = stack[stackTopIndex - 1] * 2;
            //检查是不是叶节点
            if (stack[stackTopIndex] * 2 >= length || tree[stack[stackTopIndex] * 2] == -1){
                if (stack[stackTopIndex] * 2 + 1 >= length || tree[stack[stackTopIndex] * 2 + 1] == -1){
                    //输出栈
                    for (int i = 0; i <= stackTopIndex ; ++i) {
                        cout << tree[stack[i]] << " ";
                    }
                    cout << endl;
                }
            }
        }
        
        while (true) {
            
            if (stackTopIndex == -1) {
                break;
            }
            
            //右子树没有遍历过就入栈
            if (stack[stackTopIndex] * 2 + 1 < length && tree[stack[stackTopIndex] * 2 + 1] != -1 &&
                tree[stack[stackTopIndex] * 2 + 1] != tree[stack[stackTopIndex + 1]]) {
                //右子树入栈，每次入栈都要检查一下是不是叶节点
                
                stackTopIndex++;
                stack[stackTopIndex] = stack[stackTopIndex - 1] * 2 + 1;
                
                if (stack[stackTopIndex] * 2 >= length || tree[stack[stackTopIndex] * 2] == -1){
                    if (stack[stackTopIndex] * 2 + 1 >= length || tree[stack[stackTopIndex] * 2 + 1] == -1){
                        //输出栈
                        for (int i = 0; i <= stackTopIndex ; ++i) {
                            cout << tree[stack[i]] << " ";
                        }
                        cout << endl;
                    }
                }
                
                //这个不能忘了，找到右子树就要结束弹栈过程
                break;
            }
            
            //输出并弹栈
            stackTopIndex--;
        }
        
    }
}

int main2(int argc, const char * argv[]) {
    
    int tree[8] = {1,2,3,4,5,6,7,8};
    printAllRoad(tree, 8);
    return 0;

}
