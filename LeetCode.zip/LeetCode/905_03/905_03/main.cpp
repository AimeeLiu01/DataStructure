//
//  main.cpp
//  905_03
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
/*  替换空格：
　　 题目描述：请实现一个函数，将一个字符串中的空格替换成“%20”。例如，当字符串为We Are Happy.则经过替换之后的字符串为We%20Are%20Happy。
　　 思路：先计算出空格的数量，然后从后到前遍历移动即可
*/

#include <iostream>
#include <string>
using namespace std;

string myreplace(string str){
    string res;
    for(int i = 0; i < str.size(); i++){
        
        while (str[i] == ' ') {
            i++;
        }
        int j = i;//代表的是单词的开头位置
        while (str[j] != ' ' && j < str.size()) {
            j++;
        }
        string temp = str.substr(i, j-i);
        
        if(j == str.size()){
            res = res + temp;
        }
        else{
            res = res + temp + "%20";
        }
      
        i = j;
    }
    
    cout<<res;
    return res;
    
}

int main1(int argc, const char * argv[]) {
    
    string str;
    getline(cin, str);
    myreplace(str);
    cout<<endl;
    return 0;
}
