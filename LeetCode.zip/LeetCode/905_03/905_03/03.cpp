//
//  03.cpp
//  905_03
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <stdio.h>
#include <iostream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};

TreeNode* createTreeFromPreAndIn(int pre[], int in[], int length){
    
    
    if(length == 0)
        return NULL;
    TreeNode* root = new TreeNode(pre[0]);
    
    int rootIndex = 0;
    for(int i = 0; i < length; i++){
        if(in[i] == root->val){
            rootIndex = i;
            break;
        }
    }
    root->left = createTreeFromPreAndIn(pre+1, in, rootIndex);
    root->right = createTreeFromPreAndIn(pre+rootIndex+1, in+rootIndex+1, length-rootIndex-1);
    
    return root;
    
    
}

void postorderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    cout<<root->val<<" ";
}

int main(){
    
    
    int pre[5] = {10,32,600,8,5};
    int in[5] = {600,32,8,10,5};
    TreeNode *root = createTreeFromPreAndIn(pre, in, 5);
    postorderTraversal(root);
    cout<<endl;
    
    
    return 0;
    
}
