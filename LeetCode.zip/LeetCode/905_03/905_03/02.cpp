//
//  02.cpp
//  905_03
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*
 重建二叉树：
 　　题目描述：输入某二叉树的前序遍历和中序遍历的结果，请重建出该二叉树。假设输入的前序遍历和中序遍历的结果中都不含重复的数字。例如输入前序遍历序列{1,2,4,7,3,5,6,8}和中序遍历序列{4,7,2,1,5,3,8,6}，则重建二叉树并返回。
 　　思路：根据前序遍历可以确定根节点，将中序遍历分为两半，递归即可
 */
/*#include <stdio.h>
#include <iostream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};

TreeNode* createTreeFromPreAndIn(string pre, string in, int length){
    
   
    if(length == 0)
        return NULL;
    TreeNode* root = new TreeNode(pre[0]-'0');

    int rootIndex = 0;
    for(int i = 0; i < in.size(); i++){
        if(in[i]-'0' == root->val){
            rootIndex = i;
            break;
        }
    }
    root->left = createTreeFromPreAndIn(pre.substr(1,rootIndex),in.substr(0,rootIndex),rootIndex);
    root->right = createTreeFromPreAndIn(pre.substr(rootIndex+1, pre.size()-rootIndex-1), in.substr(rootIndex+1, in.size()-rootIndex-1),pre.size()-rootIndex-1);
    
    return root;
    
    
}

void postorderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    cout<<root->val<<" ";
}

int main(){
    
    string pre;
    cout<<"Please enter your preExpression: ";
    getline(cin, pre);
    cout<<"Please enter your InExpression: ";
    string in;
    getline(cin, in);
    int size = pre.size();
    TreeNode *temp = createTreeFromPreAndIn(pre, in, size);
    cout<<"Postorder is :";
    postorderTraversal(temp);
    cout<<endl;

    
    return 0;
    
}*/

