//
//  main.cpp
//  41. First Missing Positive
//
//  Created by 刘畅 on 2017/6/12.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    int firstMissingPositive(vector<int>& nums) {
        int n = nums.size();
        int i = 0;
        while(i < n){
            if (nums[i] >= 1 && nums[i] <= n){
                if (nums[i] == nums[nums[i] - 1]){
                    i++;
                    continue;
                }
                
                swap(nums[i], nums[nums[i] - 1]);
                continue;
            }
            i++;
        }
        
        int target = 1;
        for (int i = 0; i < n; i++){
            if (target != nums[i])
                break;
            else
                target++;
        }
        cout<<"The number is "<< target << endl;
        return target;
    }
};

int main(int argc, const char * argv[]) {
    
    vector<int> val;
    val.push_back(3);
    val.push_back(4);
    val.push_back(-1);
    val.push_back(1);
    Solution s = *new  Solution();
    s.firstMissingPositive(val);
    
    
    return 0;
}
