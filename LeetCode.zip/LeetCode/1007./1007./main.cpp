//
//  main.cpp
//  1007.
//
//  Created by 刘畅 on 2017/7/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, const char * argv[]) {
    int m,n,i,j,k,sum[100],temp;
    char ca[100][51];
    while (cin>>m>>n) {
        for(i=0; i < n; i++){
            sum[i] = 0;
            cin>>ca[i];
            for(j = 0; j < m-1; j++)
                for(k = j + 1; k < m; k++)
                    if(ca[i][j] > ca[i][k])
                        sum[i]++;
        }
        
        for(i = 0; i < n; i++){
            k = 0; temp = 2000;
            for(j = 0; j < n; j++)
                if(sum[j] < temp){
                    temp = sum[j];
                    k = j;
                }
            sum[k] = 2001;
            cout<<ca[k];
        }
    }
    return 0;
}
