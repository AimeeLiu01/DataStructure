#include <iostream>
#include <string>
#include <stack>
#include <vector>
#include <queue>
using namespace std;

int number = 0;

queue<int> que;
stack<int> stk;

void help(vector<int> vec,int count[], int n, int A[])
{
    
    if(count[0] >= 1){
        vec.push_back(1);
        count[0]--;
        help(vec,count, n, A);
        count[0]++;
        vec.pop_back();
    }
    if(count[1] >= 1 && count[1] > count[0]){
        vec.push_back(0);
        count[1]--;
        help(vec,count,n,A);
        count[1]++;
        vec.pop_back();
    }
    
    if(vec.size() == 2 * n){
        
        vector<int>::iterator it;
        int j = 0;
        for( it = vec.begin(); it != vec.end(); it++){
           
            if(*it == 1){
                stk.push(A[j]);
                cout<<A[j]<<"S"<<" ";
                j++;
            }
            else{
                cout<<stk.top()<<"X"<<" ";
                stk.pop();
            }
            
        }
        number++;
        cout<<endl;
    }
}
int main(){
    
    int size;
    cout<<"Please input size ";
    cin>>size;
    int numberArray[100];
 
    for(int i = 0; i < size; i++){
        cin>>numberArray[i];
    }
    int count[2] = {size-1,size};
    vector<int> vec;
    vec.push_back(1);
    help(vec,count,size,numberArray);
    cout<<"There are "<<number<<" possibility."<<endl;
    
    return 0;
    
}
