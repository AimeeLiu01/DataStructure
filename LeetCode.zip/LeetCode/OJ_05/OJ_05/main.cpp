//
//  main.cpp
//  OJ_05
//
//  Created by 刘畅 on 2017/7/11.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;


int main(int argc, const char * argv[]) {
    
    int a[10];
    for(int i = 0; i < 10; i++){
        cin>>a[i];
    }
    for(int i = 0; i < 9; i++){
        for(int j = i+1; j < 10; j++){
            if(a[i] > a[j]){
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    
    for(int i = 0; i < 10; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    return 0;
}
