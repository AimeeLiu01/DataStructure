//
//  main.cpp
//  Island
//  迷宫问题
//  Created by 刘畅 on 2017/9/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;


void Maze(int **maze, int height, int width, int xStart, int yStart, int xEnd, int yEnd) {
    
    int dirX[4] = {0,1,0,-1};
    int dirY[4] = {1,0,-1,0};
    
    //两个栈，一个是历史路径，一个是历史方向
    int stackx[1000];
    int stacky[1000];
    int Index = -1;
    int history[1000];
    
    for (int i = 0; i < 1000; ++i) {
        history[i] = -1;
    }
    
    //根节点进入
    Index++;
    stackx[Index] = xStart;
    stacky[Index] = yStart;
    
    while (Index != -1) {
        
        int hisStack = Index;
        //遍历当前节点的周边节点
        for (int i = history[Index] + 1; i < 4; ++i) {
            int newX = stackx[Index] + dirX[i];
            int newY = stacky[Index] + dirY[i];
            
            if (newX == xEnd && newY == yEnd) {
                for (int i = 0; i <= Index; ++i) {
                    cout << stackx[i] << "," << stacky[i] << "," << history[i] << endl;
                }
                
                cout << "找到了！！" << endl;
            }
            
            bool hasAlready = 0;
            
            if (newX >= width || newY >= height || newX < 0 || newY < 0) {
                continue;
            }
            
            if (maze[newY][newX] == 0) {
                continue;
            }
            
            for (int j = 0; j <= Index; ++j) {
                if (stackx[j] == newX && stacky[j] == newY) {
                    //到过了
                    hasAlready = 1;
                }
            }
            
            if (hasAlready == 1) {
                continue;
            }
            
            //到这里说明没有问题
            //入栈
            Index++;
            stackx[Index] = newX;
            stacky[Index] = newY;
            //这里要存的是旧的方向
            history[Index - 1] = i;
            cout << "入栈的时候" << history[0] << endl;
            //            return;
        }
        
        //如果没有入栈，那就弹栈吧
        if (hisStack == Index) {
            cout << "弹栈" << Index << endl;
            //打印栈里面的内容
            for (int i = 0; i <= Index; ++i) {
                cout << stackx[i] << "," << stacky[i] << "," << history[i] << endl;
            }
            
            cout << endl;
            history[Index] = -1;
            Index--;
        }
    }
    
    cout << "没找到" << endl;
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
