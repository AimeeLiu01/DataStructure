//
//  main.cpp
//  Maximum Binary Tree
//
//  Created by 刘畅 on 2017/8/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};


TreeNode* constructMaximumBinaryTree(vector<int>& nums) {
    
    int maxIndex = 0;
    for(int i = 0; i < nums.size(); i++){
        if(nums[i] > nums[maxIndex])
            maxIndex = i;
    }
    
    TreeNode *root = new TreeNode(nums[maxIndex]);
    if(maxIndex <= 0)
        root->left = NULL;
    else{
        vector<int> left = vector<int>(nums.begin(), nums.begin()+maxIndex);
        root->left =constructMaximumBinaryTree(left);
    }
    
    if(maxIndex >= nums.size()-1)
        root->right = NULL;
    else{
        vector<int> right = vector<int>(nums.begin()+maxIndex+1, nums.end());
        root->right = constructMaximumBinaryTree(right);
    }
    return root;
    
}


void InOrderTraversal(TreeNode *root){
    
    if(root == NULL) return;
    InOrderTraversal(root->left);
    cout<<root->val<<" ";
    InOrderTraversal(root->right);
}


void PreOrderTraversal(TreeNode * root){
    
    if(root == NULL) return;
    cout<<root->val<<" ";
    PreOrderTraversal(root->left);
    PreOrderTraversal(root->right);
}

int main(int argc, const char * argv[]) {
    
    int n[] = {3, 2, 1, 6, 0, 5};
    vector<int> a(n, n+6);
    TreeNode *root = constructMaximumBinaryTree(a);
    cout<<"构造的二叉树的中序遍历顺序为："<<endl;
    InOrderTraversal(root);
    cout<<endl;
    cout<<"构造的二叉树的前序遍历顺序为："<<endl;
    PreOrderTraversal(root);
    cout<<endl;
    
    return 0;
    
    
    
    
    
}
