//
//  main.cpp
//  1008.
//
//  Created by 刘畅 on 2017/7/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string.h>
using namespace std;

int main(int argc, const char * argv[]) {
    
    int a[5] = {0,45,9045,1395495,189414495};
    int b[5] = {0,9,189,2889,38889};
    int c[5] = {0,10,100,1000,10000};
    int d[5] = {1,10,100,1000,10000};
    unsigned long i,j,k,n,t;
    cin>>t;
    while (t--) {
        cin>>n;
        for(i = 1; i < 5; i++)
            if(n <= a[i]) break;
        n-=a[i-1];
        for(k = 0, j = 1; k < n; j++)
            k = b[i-1]*j + i*j*(j+1)/2;
        
        --j;
        n = n - b[i-1]*(j-1) - i*j*(j-1)/2;
        for(i = 1; i < 5; i++)
            if(n <= b[i]) break;
        if(i == 1) cout<<n<<endl;
        else{
            n -= b[i-1];
            k = (n-1)/i + c[i-1];
            cout<<k/d[i-(n-1)%i-1]%10<<endl;
        }
    }
    return 0;
}
