//
//  main.cpp
//  OJ_06
//
//  Created by 刘畅 on 2017/7/11.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

char s[55][55];
int map[55][55];
int n,m,many;
int dfs(int i, int j);


int main(int argc, const char * argv[]) {
  
    while (cin>>n>>m) {
        many = 0;
        memset(map, 0, sizeof(map));
        
        for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                cin>>s[i][j];
        
        for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                if(map[i][j] == 0 && s[i][j] == '@')
                    many += dfs(i,j);
        
        cout<<many<<endl;
    }
    return 0;

}

int dfs(int i, int j){
    
    map[i][j] = 1;
    if(i + 1 < n && s[i+1][j] == '@' && map[i+1][j] == 0)
        dfs(i+1, j);
    if(j + 1 < n && s[i][j+1] == '@' && map[i+1][j] == 0)
        dfs(i, j+1);
    if(i-1 > 0 && s[i][j-1] == '@' && map[i-1][j] == 0)
        dfs(i-1,j);
    if(j-1>=0 && s[i][j-1] == '@' && map[i][j-1] == 0)
        dfs(i,j-1);
    
    return 1;
    
}
