//
//  main.cpp
//  21. Merge Two Sorted Lists
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode(int x) : val(x), next(NULL) {}
};


class Solution {
public:
    ListNode* mergeTwoLists(ListNode* l1, ListNode* l2) {
        
        if(l1 == NULL) return l2;
        if(l2 == NULL) return l1;
        
        if(l1->val < l2->val){
            ListNode* temp = l1;
            temp->next = mergeTwoLists(l1->next, l2);
            return temp;
        }
        else{
            ListNode* temp = l2;
            temp->next = mergeTwoLists(l1, l2->next);
            return temp;
        }
        
    }
};

int main(int argc, const char * argv[]) {
    
    ListNode *l1 = new ListNode(4);
    ListNode *node1 = new ListNode(1);
    ListNode *l2 = new ListNode(6);
    ListNode *node2 = new ListNode(3);
    ListNode *l3 = new ListNode(8);

    l1->next = l2;
    l2->next = l3;
    node1->next = node2;
    
    Solution s = *new Solution();
    ListNode *res;
    res = s.mergeTwoLists(l1, node1);
    while (res) {
        cout<<res->val<<" ";
        res = res->next;
    }
    cout<<endl;
   

    return 0;
}
