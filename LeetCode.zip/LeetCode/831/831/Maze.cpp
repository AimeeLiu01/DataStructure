//
//  Maze.cpp
//  831
//
//  Created by 刘畅 on 2017/8/31.
//  Copyright © 2017年 刘畅. All rights reserved.
//  求迷宫问题的最短路径 BFS

#include <stdio.h>
#include <iostream>
using namespace std;

struct node{
    int pre;
    int x;
    int y;
}path[100];

int front = 0, rear = 1;

int map[5][5];

int dirX[4] = {0,1,0,-1};
int dirY[4] = {1,0,-1,0};


void print(int i){//打印从当前点向前的所有路径
   
    if(path[i].pre != -1){
        print(path[i].pre);
        cout<<"("<<path[i].x<<","<<path[i].y<<")"<<endl;
    }
    else{//最前面那个点
        cout<<"("<<path[i].x<<","<<path[i].y<<")"<<endl;
    }
    
}


void bfsSearch(int x,int y){
    //开始节点（出发）  前面此时没有结点
    path[front].x = x;
    path[front].y = y;
    path[front].pre = -1;
    
    while (front < rear) {
        
        for (int i = 0; i < 4; i++) {
            
            int xx = path[front].x + dirX[i];
            int yy = path[front].y + dirY[i];
            
            if(xx < 0 || yy < 0 || xx > 4 || yy > 4 || map[xx][yy]){
                continue;
            }
            else{//将可以走的点加入到路径中去
                
                map[xx][yy] = 1;
                path[rear].x = xx;
                path[rear].y = yy;
                path[rear].pre = front;
                rear++;
            }
            
            if(xx == 4 && yy == 4){
                print(rear-1);
                return;
            }
        }
        
        front++;
    }
    
    cout<<"There is no way."<<endl;
}

int main(){
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            cin>>map[i][j];
        }
    }
    
    bfsSearch(0, 0);
    return 0;
    
}







