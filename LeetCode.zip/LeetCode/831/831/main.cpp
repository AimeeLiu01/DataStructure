//
//  main.cpp
//  831
//
//  Created by 刘畅 on 2017/8/31.
//  Copyright © 2017年 刘畅. All rights reserved.
//  判断给定的字符串是否是合法的括号字符串
// （）（（（）））


/*#include <iostream>
#include <string>
#include <stack>
using namespace std;

stack<char> stk;


bool IsCorrect(string s){
    
    for (int i = 0; i < s.size(); i++) {
        
        if(s[i] == '('){
            stk.push(s[i]);
        }
        else if(s[i] != ')'){
            stk.pop();
        }
    }
    
    if(!stk.empty()){
        cout<<"False."<<endl;
        return false;
    }
    else{
        cout<<"True."<<endl;
        return true;
    }
}


int main1(int argc, const char * argv[]) {
    
    string s;
    cout<<"Please enter your string: "<<endl;
    getline(cin,s);
    IsCorrect(s);
    
    return 0;
}*/
