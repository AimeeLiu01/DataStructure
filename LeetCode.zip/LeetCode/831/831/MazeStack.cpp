//  MazeStack.cpp
//  831
//  Created by 刘畅 on 2017/8/31.
//  Copyright © 2017年 刘畅. All rights reserved.
//  DFS算法  找到迷宫问题的一条路径  用栈  符合要求的点就进栈 走不下去的时候就弹栈

/*#include <stdio.h>
#include <string>
#include <stack>
#include <iostream>
using namespace std;

int map[5][5];
stack<pair<int, int>> stk;

int dirX[4] = {0,1,0,-1};
int dirY[4] = {1,0,-1,0};

int history[1000];//用来记录某个点进栈时的方向问题


void printPath(stack<pair<int, int>> stk){
    
   
    stack<pair<int, int>> tmp;
    
    while (!stk.empty()) {
        auto n = stk.top();
        stk.pop();
        tmp.push(n);
    }
    
    while (!tmp.empty()) {
     
     auto n = tmp.top();
     int x = n.first;
     int y = n.second;
     cout<<"("<<x<<","<<y<<")"<<endl;
     tmp.pop();
     }
    
}

void BfsStack(int i, int j){
    

    stk.push(make_pair(i, j));//首先将初始点入栈
    
    
    while (!stk.empty()) {
        
        auto n = stk.top();
        int x = n.first;
        int y = n.second;
       
        if(x == 4 && y == 4){//如果放进去的点是终点 我们就打印栈
            printPath(stk);
            return;
            
           
            
        }
        
        for (int k = 0; k < 4; k++) {
            
            int xx = x + dirX[k];
            int yy = y + dirY[k];
            
            if(xx < 0 || yy < 0 || xx > 4 || yy > 4 || map[xx][yy] == 1)
                continue;
            
            else{
                map[xx][yy] = 1;//为了防止 回溯问题 即已经访问过的点再次入栈
                stk.push(make_pair(xx, yy));
                break;
                
            }
        }
        //for循环结束后  查看是否找到了下一个点（有新的点入栈）  如果有的话就继续     如果没有就弹栈
        auto p = stk.top();
        if(n == p)
            stk.pop();
    }
    
    cout<<"There is no way."<<endl;

}


int main(){
    
    for(int i = 0; i < 5; i++){
        for (int j = 0; j < 5; j++) {
            cin>>map[i][j];
        }
    }
    
    BfsStack(0,0);
    return 0;
    
    
}*/
