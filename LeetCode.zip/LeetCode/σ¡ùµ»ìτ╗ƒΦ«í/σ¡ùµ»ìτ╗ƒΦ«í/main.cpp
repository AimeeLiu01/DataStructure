//
//  main.cpp
//  字母统计
//
//  Created by 刘畅 on 2017/7/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <map>
using namespace std;

int main() {
    
    /*string s;
    map<char,int> hash;
    
    const char num[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    
    while (cin>>s) {
        
        for(int i = 0; i < s.length(); i++){
            hash[s[i]]++;
        }
        for(int i = 0; i < 26; i++){
            cout<<num[i]<<":"<<hash[num[i]]<<endl;
        }
        
    }
    return 0;
     */
    int i, index;
    char string[1000];
    while (cin>>string) {
        int characterCount[26] = {0};
        for(int i = 0 ; i < strlen(string); i++){
            if(string[i] >= 'A' && string[i] <= 'Z'){
                index = string[i] - 'A';
                characterCount[index]++;
            }
        }
        
        for(i = 0; i < 26; i++){
            cout<< char(i+'A')<<":"<<characterCount[i]<<endl;
        }
    }
    return 0;

    
}
