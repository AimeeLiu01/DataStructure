//
//  main.cpp
//  4. Median of Two Sorted Arrays
//
//  Created by 刘畅 on 2017/6/21.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

class Solution {
public:
    double findMedianSortedArrays(vector<int>& nums1, vector<int>& nums2) {
        vector<int> res;
        for(int i = 0; i< nums1.size(); i++){
            res.push_back(nums1[i]);
        }
        for(int j = 0; j < nums2.size(); j++){
            res.push_back(nums2[j]);
        }
        sort(res.begin(), res.end());
        
        int size = res.size();
        
        if(size % 2 == 1){
            return res[size/2];
        }
        else{
            
            double d = (res[size/2-1]+res[size/2])/2;
            cout<<setprecision(2)<<fixed<<d<<endl;
            return d;
        }
    }
};
int main(int argc, const char * argv[]) {
    vector<int> v1;
    v1.push_back(1);
    v1.push_back(3);
    v1.push_back(9);
    vector<int> v2;
    v2.push_back(5);
    v2.push_back(7);
    v2.push_back(4);
    Solution s = *new Solution();
    double result = 0.0;
    result = s.findMedianSortedArrays(v1, v2);
    cout<<result<<endl;
    return result;
}
