#include <iostream>
#include <queue>
#include <cstdio>
using namespace std;

struct node{
    int x;//代表x的值
    int y;//代表y的值
    int step;//代表到现在一共的步数
    int state[50];//代表的是当前步数的方向问题
};

//用来表示四个方向值
int dirX[4] = {1,0,0,-1};
int dirY[4] = {0,1,-1,0};

//迷宫矩阵
int maze[6][6];
//该值是否被访问
bool vis[10][10];


//返回值为结束的点坐标
node bfs(){
    
    //memset(vis, false, sizeof(vis));//将vis标记为均未被访问
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
            vis[i][j] = false;
    
    queue<node> q;//队列代表访问的点坐标
    node next;//代表下一个可以到的点
    node cur;//代表当前的点
    cur.x = 0;
    cur.y = 0;
    cur.step = 0;
    
    q.push(cur);//先将初始点坐标放入队列
    vis[0][0] = true;//并将其标记为已访问
    
    while (!q.empty()) {
        cur = q.front();//取出队列的首元素
        q.pop();//将其删除
        
        if(cur.x == 2 && cur.y == 2){//若当前元素为迷宫的出口，则返回该点
            return cur;
        }
        
        //以该点为中心，进行尝试走
        for(int i = 0; i < 4; i++){
            int tempX = cur.x + dirX[i];//下一个点坐标的x值
            int tempY = cur.y + dirY[i];//下一个点坐标的y值
            
            //如果坐标的值越界或者该点已被访问过 或者该点为1 不可以通过  则continue
            if(tempX < 0 || tempX >= 3 || tempY < 0 || tempY >= 3 || vis[tempX][tempY] || maze[tempX][tempY])
                continue;
            
            //如果该点可以访问，将其标记为以访问
            vis[tempX][tempY] = true;
            
            next = cur;//使前后几个步骤连接起来，当前指向下一个,主要是为了存储state之前的值，使之变成连续的，这样才方便最后的计算
            next.x = tempX;
            next.y = tempY;
            next.step = cur.step + 1;
            next.state[cur.step] = i;//记录到达这个步骤的状态
            q.push(next);
            
        }
    }
    return cur;
}

int main2(){
    

    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            cin>>maze[i][j];
        }
    }
    node ans = bfs();
    int x = 0;
    int y = 0;
    
    for(int i = 0; i < ans.step; i++){
        cout<<"("<<x<<","<<y<<")"<<endl;
        x += dirX[ans.state[i]];
        y += dirY[ans.state[i]];
        
    }
    cout<<"(2,2)"<<endl;
    return 0;
    
    

    
}
