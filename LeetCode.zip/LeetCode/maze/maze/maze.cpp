#include <iostream>

using namespace std;

//杜总的代码
//道理跟简单，使用两个二维数组分别表示已经走过的地方和这个迷宫的构造，最后会输出这个栈里面的内容并且获得使用路径
struct go
{
    int x;
    int y;
};

//坐标是y轴朝下放的
//分别是向下走，向左，向上，向右
struct go DIR[4] = {{0,1},{1,0},{0,-1},{-1,0}};

//找出路的函数，1代表这个位置是可以走的，0代表这个是不能走的
void findMazeOut(int **maze ,int height, int width){
   
    //使用两个栈来分别表示x，y的历史状态
    int *xStack = new int[100];
    int *yStack = new int[100];
    
    //这里执行上一次走完的方向
    int *dirStack = new int[100];
    
    //栈顶指针的索引
    int index = -1;
    
    //然后两个循环，一个是用来搜索的，一个是用来向各个方向循环的
    //用一个数组存不同的方向
    
    //用一个、while来执行所有查找的操作
    //起点先入栈
    //判断下面的while是正常退出的还是因为没有找到的时候退出的
    bool judge = true;
    index++;
    xStack[index] = 0;
    yStack[index] = 0;
    dirStack[index] = -1;
    
    
    //用一个数组来记录走过的位置
    int **marked = new int*[height];
    for (int i = 0; i < height; ++i)
    {
        marked[i] = new int[width];
        
        for (int j = 0; j < width; ++j)
        {
            marked[i][j] = 0;
        }
    }
    
    //00位置是一开始走过的
    marked[0][0] = 1;
    

    while(!(xStack[index] == height - 1 && yStack[index] == width - 1)){//结束的条件
        if(index == -1){
            cout << "栈是空的，并且没有找到终点" << endl;
            judge = false;
            break;
        }
        //向下一个点走
        //选择下一个方向
        if(dirStack[index]+1 > 3){
            cout << "没有方向可以走了" << endl;
            //弹栈
            index--;
            
            continue;
        }
        
        //如果有方向可以走
        struct go nextDir = DIR[++dirStack[index]];//方向的变化体现在这句话上！
        
        //看看这个点能不能到
        
        int x = xStack[index]+nextDir.x;
        int y = yStack[index]+nextDir.y;
        cout << "准备前往" << "（" << x << "，" << y << "）" << endl;
        
        //注意对于二维数组，横坐标在后面
        if (x >= 0 && y >=0 && x< height && y < width && maze[x][y] == 0 && marked[x][y] != 1)
        {
            //这个点是可以到的，入栈
            
            index++;
            xStack[index] = x;
            yStack[index] = y;
            //方向从0开始
            dirStack[index] = -1;
            //新的点被标记为到达过的
            marked[x][y] = 1;
            continue;
        } else{
            //如果这个点到不了那就试试其他的方向
            cout << "这个点到不了" << endl;
        }
    }
    
    if (judge == true)
    {
        cout << "找到了！=========" << endl;
    }
    
    //打印栈中的所有元素
    for (int i = 0; i <= index; ++i)
    {
        cout << "（" << xStack[i] << "," << yStack[i] << "）" << endl;
    }
    
    delete[] xStack;
    delete[] yStack;
    delete[] dirStack;
}

int main(){
    
    //设计一个迷宫
    //    0 0 1
    //    1 0 1
    //    1 0 0
    
    int **maze = new int*[3];
    
    maze[0] = new int[3];
    maze[1] = new int[3];
    maze[2] = new int[3];
    maze[0][0] = 0;
    maze[0][1] = 0;
    maze[0][2] = 1;
    
    maze[1][0] = 1;
    maze[1][1] = 0;
    maze[1][2] = 1;
    
    maze[2][0] = 1;
    maze[2][1] = 1;
    maze[2][2] = 0;

    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            cout<<maze[i][j]<<" ";
        }
        cout<<endl;
    }
    
    
    findMazeOut(maze,3,3);
    
    return 0;
    
}
