//
//  main.cpp
//  35. Search Insert Position
//
//  Created by 刘畅 on 2017/6/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;


class Solution {
public:
    int searchInsert(vector<int>& nums, int target) {
        
        int left = 0, right = nums.size();
        int mid;
        while(left < right)
        {
            mid = (left + right)/2;
            if(target > nums[mid])
                left = mid + 1;
            else
                right = mid;
        }
        cout<<"Class: The num is " <<left<<endl;
        cout<<"-----------------------------"<<endl;
        return left;
        
    }
};


int main(int argc, const char * argv[]) {
    
    vector<int> vec;
    vec.push_back(1);
    vec.push_back(3);
  
    Solution s = *new Solution();
    s.searchInsert(vec, 2);
    return 0;
}
