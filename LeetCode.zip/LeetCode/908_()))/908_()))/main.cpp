//
//  main.cpp
//  908_()))
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;

int longestValid(string s){
    
    
    int maxLength = 0;
    int lastValidIndex = 0;
    stack<int> stk;
    
    for (int i = 0; i < s.size(); i++) {
        if(s[i] == '(')
            stk.push(i);
        else{//如果是右括号
            
            if(stk.empty()){//如果此时栈中为空  那么有效位置从下一位开始
                lastValidIndex = i + 1;
            }
            else{//栈中有左括号
                
                stk.pop();//先删去一个左括号
                if (stk.empty()) {
                    maxLength = max(maxLength, i - lastValidIndex + 1);
                }
                else
                    maxLength = max(maxLength, i - stk.top());
            }
            
        }
    }
    cout<<"The longest is: "<<maxLength<<endl;
    return maxLength;
}

int main(int argc, const char * argv[]) {
   
    string s;
    cin>>s;
    longestValid(s);
    return 0;
}
