//
//  main.cpp
//  solution
//
//  Created by 刘畅 on 2017/5/10.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*
 Given nums = [1,3,-1,-3,5,3,6,7], and k = 3.
 
 Window position                Max
 ---------------               -----
 [1  3  -1] -3  5  3  6  7       3
 1 [3  -1  -3] 5  3  6  7       3
 1  3 [-1  -3  5] 3  6  7       5
 1  3  -1 [-3  5  3] 6  7       5
 1  3  -1  -3 [5  3  6] 7       6
 1  3  -1  -3  5 [3  6  7]      7
 Therefore, return the max sliding window as [3,3,5,5,6,7].
 */

#include <iostream>
#include <vector>
#include <deque>
using namespace std;

class Solution {

    
public:
    
    vector<int> res;
    deque<int> dq;
    
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        
      
        int max1;
        for(int i = 0; i < k; i++){
            dq.push_front(nums[i]);
        }
        for(int i = 0; i<dq.size()-1; i++){
            
            max1 = dq[i];
            if(dq[i+1] > dq[i])
                max1 = dq[i+1];
        }
        
        res.push_back(max1);
        
        
        for(int i = k+1; i <= nums.size(); i++){
            
            if(!dq.empty()){
                dq.pop_back();
                dq.push_front(nums[i]);
            }
            
            for(int i = 0; i< dq.size()-1; i++){
                max1 = dq[i];
                if(dq[i+1] > dq[i])
                    max1 = dq[i+1];
            }
            res.push_back(max1);
        }
        return res;
    }
};
int main(int argc, const char * argv[]) {
    
     vector<int> nums;
     nums.push_back(1);
     nums.push_back(3);
     nums.push_back(-1);
     nums.push_back(-3);
     nums.push_back(5);
     nums.push_back(3);
     nums.push_back(6);
     nums.push_back(7);
   
    Solution s = *new Solution();
    s.maxSlidingWindow(nums,3);
    
    for(int i = 0 ; i < s.res.size(); i++){
        cout<<s.res[i]<<endl;
    }
    
    
    
    
    
    
    
    
}
