//
//  main.cpp
//  61. Rotate List
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//
#include <iostream>
#include <stack>
#include <vector>
#include <map>
using namespace std;



struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution {
public:
     ListNode* rotateRight(ListNode* head, int k) {
    }
};

int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(4);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    
    Solution s = *new Solution();
    ListNode *res = s.rotateRight(node1, 4);
    while (res != NULL) {
        cout<<res->val<<" ";
        res = res->next;
    }
    cout<<endl;
    
    return 0;
}






