//
//  main.cpp
//  sort02
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//  排序算法

/*#include <iostream>
#include <string>
using namespace std;

void swap(int a[], int i, int j){
    int tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
}

//1.选择排序
void SelectSort(int a[], int size){
  
    
    for(int i = 0; i < size; i++){
        int min = i;//表示的是当前元素的下标
        for(int j = i+1; j < size; j++){
            if(a[j] < a[min]){
                min = j;
            }
        }
        int tmp = a[i];
        a[i] = a[min];
        a[min] = tmp;
    }
    
    for(int i = 0; i < size; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
}

//2. 插入排序
void InsertSort(int a[], int size){
    
    for(int i = 0; i < size; i++){
        
        int tmp = a[i];
        int j = 0;
        
        for(j = i-1; j >= 0; j--){
            if(a[j] > tmp){
                a[j+1] = a[j];//向后移位
            }
            else{
                j++;
                break;
            }
        }
        a[j] = tmp;
    }
    
    for (int i = 0; i < size; i++) {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
}

//3. 冒泡排序  双重循环 0...size-1   1...size
void BubbleSort(int a[], int n){
    
    //冒泡排序，每次消灭一对逆序数，每次都可以将最小的元素放到相对应的位置
    for(int i = 0; i < n-1; i++){
        for(int j = i+1; j < n; j++){
            if(a[i] > a[j]){
                swap(a,i,j);
            }
        }
    }
    
    for(int i = 0; i < n; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}


//4. 快速排序 low指的是第一个下标的位置  high指的是最后一个元素的下标位置
void QuickSort(int a[], int low, int high){
    
    int privt = a[low];
    
    int i = low;
    int j = high;
    
    if(i > j)
        return;
    
    while (i != j) {
        
        while (a[j] >= privt && i < j) {//直到找到比基准小的数，停下
            j--;
        }
        while (a[i] <= privt && i < j) {//直到找到比基准大的数，停下
            i++;
        }
        
        if(i < j){
            swap(a,i,j);
        }
        
    }
    //跳出循环之后，交换基准
    //循环结束的条件即为i == j
    a[low] = a[j];
    a[j] = privt;
    
    QuickSort(a, low, i-1);
    QuickSort(a, i+1, high);
    
}

//5. 归并排序
void Recursive(int a[], int low, int mid, int high, int *tmp){
    
    int i = low;
    int j = mid + 1;
    int k = 0;
    while (i <= mid && j <= high) {//数组a[low,mid]与数组[mid+1, high]均没有全部归入数组temp中去
        
        if(a[i] <= a[j]){
            tmp[k] = a[i];
            k++;
            i++;
        }
        
        else{
            tmp[k] = a[j];
            k++;
            j++;
        }
    }
    while (i <= mid) {
        tmp[k] = a[i];
        i++;
        k++;
    }
    while (j <= high) {
        tmp[k] = a[j];
        j++;
        k++;
    }
    
    //然后我们将归并后的数组的值逐一赋给数组a[low,high]   注意，应从a[low+i]开始赋值
    for(i = 0; i < k; i++){
        a[low + i] = tmp[i];
    }
}

void MergeSort(int a[], int low, int high, int *tmp){
    
    if(low >= high){
        return;
    }
    
    int middle = (low + high)/2;
    
    MergeSort(a, low, middle, tmp);//左边有序
    MergeSort(a, middle+1, high, tmp);//右边有序
    Recursive(a, low, middle, high, tmp);//再将两个有序序列合并
    
}



//6. 堆排序
void adjustHeap(int heap[], int i, int size){
    int k = heap[i];//我们要调整以i为父节点的堆 相当于我们删除了堆的根结点 现在让最后一个元素顶替 进行堆的调整
    //j为i的子女
    for (int j = 2*i+1; j < size; ) {
        if(j+1 < size && heap[j+1] > heap[j])
            j = j+1;
        
        if(k >= heap[j])
            break;
        else{
            heap[i] = heap[j];
            i = j;
            j = 2 * i + 1;
        }
    }
    heap[i] = k;
}


void heapSort(int a[], int size){
    
    for(int i = size/2 - 1;i >= 0;i--)
        adjustHeap(a,i,size);
    
    //建立堆、从最底层的父节点开始
    for(int i = size-1; i >= 0; i--){
        int maxEle = a[0];
        a[0] = a[i];
        a[i] = maxEle;
        adjustHeap(a, 0, i);
    }
    
}




int main(int argc, const char * argv[]) {
    
    int *tmp = new int[7];
    int a[] = {1,3,4,2,9,1,13};
    cout<<"Now let's test the SelectSort: "<<endl;
    SelectSort(a, 7);
    cout<<"Now let's test the InsertSort: "<<endl;
    InsertSort(a, 7);
    cout<<"Now let's test the BuddleSort: "<<endl;
    BubbleSort(a, 7);
    cout<<"Now let's test the quickSort: "<<endl;
    QuickSort(a, 0, 6);
    for(int i = 0; i < 7; i++){
        cout<<a[i]<<" ";
    }
    
    cout<<"\nAfter MergeSort, the array is:"<<endl;
    MergeSort(a, 0, 6, tmp);
    for(int i = 0; i < 7; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
    int b[] = {6,5,3,1,9,11,14,2,8};
    heapSort(b, 9);
    cout<<"After HeapSort, the array is:"<<endl;
    for(int i = 0; i < 9; i++){
        cout<<b[i]<<" ";
    }
    cout<<endl;

    
    return 0;
}*/
