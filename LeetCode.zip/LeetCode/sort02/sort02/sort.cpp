//
//  sort.cpp
//  sort02
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

void swap(int a[], int i, int j){
    int temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}

//归并排序
void RecursiveSort(int a[], int low, int mid, int high, int *temp){
    
    int i = low;
    int j = mid+1;
    int k = 0;
    while (i <= mid && j <= high) {
        if(a[i] <= a[j]){
            temp[k++] = a[i++];
        }
        else{
            temp[k++] = a[j++];
        }
    }
    
    while (i <= mid) {
        temp[k++] = a[i++];
    }
    while (j <= high) {
        temp[k++] = a[j++];
    }
    
    for(int i = 0; i < k; i++){
        a[low + i] = temp[i];
    }
}

void MergeSort(int a[], int low, int high, int *temp){
    
    if(low >= high)
        return;
    int mid = (low + high)/2;
    MergeSort(a, low, mid, temp);
    MergeSort(a, mid+1, high, temp);
    RecursiveSort(a,low, mid, high, temp);
   
}


//快速排序
void QuickSort(int a[], int low, int high){
    
    int priovt = a[low];
    int i = low, j = high;
    if(i > j)
        return;
    while (i != j) {
        
        while (a[j] >= priovt && i < j) {
            j--;
        }
        while (a[i] <= priovt && i < j) {
            i++;
        }
        if(i != j){
            swap(a,i,j);
        }
    }
    
    a[low] = a[i];
    a[i] = priovt;
    
    QuickSort(a, low, i-1);
    QuickSort(a, i+1, high);
    

    
    
}

//堆排序
void adjustHeap(int a[], int i, int size){
    
    int tmp = a[i];
    int j;//代表的是儿子结点
    for (j = 2 * i + 1; j < size; ) {//注意为<号而不是小于等于号
        
        if(j+1 < size && a[j+1] > a[j])
            j++;
        if(tmp >= a[j]) break;
        
        a[i] = a[j];
        i = j;
        j = 2 * i + 1;
        
    }
    a[i] = tmp;
    
}


void HeapSort(int a[], int size){
    
    for(int i = size/2-1; i >= 0; i--){
        adjustHeap(a,i,size);
    }
    
    for(int i = size-1; i >= 0; i--){
        int tmp = a[0];
        a[0] = a[i];
        a[i] = tmp;
        adjustHeap(a, 0, i);//调整根结点  一共的大小为size-1
       
    }
    
    
   
    
}
int main(){
    int *temp = new int[7];
    int a[] = {3,4,5,7,1,2,0};
    MergeSort(a, 0, 6, temp);//指向的都是真实的下标
    for(int i = 0; i <= 6; i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
    QuickSort(a, 0, 6);//指向的都是真实的下标
    for (int i = 0; i <= 6; i++) {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
    HeapSort(a, 7);
    for (int i = 0; i < 7; i++) {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    
    return 0;
}
