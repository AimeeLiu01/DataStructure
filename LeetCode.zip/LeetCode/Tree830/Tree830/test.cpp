//
//  StringToTree.cpp
//  PathOfTree829
//
//  Created by 刘畅 on 2017/8/29.
//  Copyright © 2017年 刘畅. All rights reserved.
//


#include <stdio.h>
#include <stack>
#include <string>
#include <iostream>
using namespace std;

stack<int> s;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};

TreeNode* ToTree(string s){
    
    stack<TreeNode*> stk;
    TreeNode *root = new TreeNode(s[0]-'0');
    TreeNode *p = nullptr;
    
    stk.push(root);
    for(int i = 1; i < s.size(); i++){
        if(s[i] == '(')
            continue;
        else if(s[i] >= '0' && s[i] <= '9'){
            p = new TreeNode(s[i]-'0');
            stk.push(p);
        }
        else if(s[i] == ')'){
            p = stk.top();
            stk.pop();
            if(!stk.empty()){
                root = stk.top();
                if(root->left == NULL)
                    root->left = p;
                else
                    root->right = p;
            }
        }
        
    }
    return root;
}

void Traversal(TreeNode *root){
    if(root == NULL)
        return ;
    cout<<root->val<<" ";
    Traversal(root->left);
    Traversal(root->right);
}
int main(){
    
    string s = "1(2(4)(8))(6(3)(4))";
    TreeNode *res = ToTree(s);
    
    Traversal(res);
    return 0;
}


