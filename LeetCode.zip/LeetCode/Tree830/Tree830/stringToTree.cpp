//
//  stringToTree.cpp
//  Tree830
//
//  Created by 刘畅 on 2017/8/30.
//  Copyright © 2017年 刘畅. All rights reserved.
//  这个函数也只能解决完全二叉树  左子树为空格的（）时也无法处理

#include <stdio.h>
#include <iostream>
#include <string>
#include <stack>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(char x): val(x),left(nullptr),right(nullptr){}
};

TreeNode* str2tree(string s){
    
    if(s.empty())
        return NULL;
    stack<TreeNode*> stk;
    for(int i = 0; i < s.size(); i++){
        int j = i;//记录起始位置
        if(s[i] >= '0' && s[i] <= '9'){
            while (i+1 < s.size() && s[i+1] >= '0' && s[i+1] <= '9') {
                i++;
            }//跳出循环后就找到了数字的 终止位置
            TreeNode *cur = new TreeNode(stoi(s.substr(j,i-j+1)));
            if(!stk.empty()){
                TreeNode *t = stk.top();
                if(!t->left)
                    t->left = cur;
                else
                    t->right = cur;
            }
            stk.push(cur);
        }
        else if(s[i] == ')')
            stk.pop();
        
    }
    return stk.top();
}

void Travel(TreeNode *root){
    if(root == nullptr)
        return;
    Travel(root->left);
    cout<<root->val<<" ";
    Travel(root->right);
}

int main1(){
    string s = "4(2(3)(1))(6(5)(10))";
    TreeNode *res = str2tree(s);
    Travel(res);
    return 0;
    
}
