//
//  KMP.cpp
//  Tree830
//
//  Created by 刘畅 on 2017/8/30.
//  Copyright © 2017年 刘畅. All rights reserved.
//  KMP算法

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

int fail[100];

void SetFailArray(string s){
   
    fail[0] = -1;
    
    for(int i = 1; i < s.size(); i++){
        if(s[i] == s[fail[i-1]+1])
            fail[i] = fail[i-1]+1;
        else
            fail[i] = -1;
    }
    
    for(int i = 0; i < s.size(); i++){
        cout<<fail[i]<<" ";
    }
    cout<<endl;
    
}

int main(){
    
    
    string str;
    string substr;
    cout<<"Please enter str: ";
    cin>>str;
    cout<<"Please enter substr: ";
    cin>>substr;
    SetFailArray(substr);
    
    int index = 0;
    int subindex = 0;
    
    while (index < str.size() && subindex < substr.size()) {
        if(str[index] == substr[subindex]){
            index++;
            subindex++;
        }
        else{
           if(subindex == 0)
               index++;
            else
               subindex = fail[subindex-1]+1;
        }
       
    }
    //没有用失败函数 每次匹配失败子序列都从头来过
    /*while (index < str.size() && subindex < substr.size()) {
        if(str[index] == substr[subindex]){
            index++;
            subindex++;
        }
        else{
            index++;
            subindex = 0;
        }
    }*/
    
    if(subindex == substr.size()){
        cout<<"匹配成功位置在："<< index - subindex + 1 <<endl;
    }
    else{
        cout<<"没有匹配成功。"<<endl;
    }
    
    return 0;
    
}
