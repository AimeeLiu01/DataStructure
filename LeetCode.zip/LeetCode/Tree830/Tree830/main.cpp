//
//  main.cpp
//  Tree830
//
//  Created by 刘畅 on 2017/8/30.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

struct TreeNode{
    char val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(char x): val(x),left(nullptr),right(nullptr){}
};

//由前序中序寻找后序---char表示
void PostOrderFromPreAndIn(char *preorder, char *inorder, int length){
    
    if(length == 0)
        return;
    
    TreeNode *root = new TreeNode(*preorder);
    
    //找到根结点所在的位置
    int rootIndex = 0;
    for (; rootIndex < length; rootIndex++) {
        if(inorder[rootIndex] == root->val){
            break;
        }
    }
    
    PostOrderFromPreAndIn(preorder+1, inorder, rootIndex);
    PostOrderFromPreAndIn(preorder+rootIndex+1, inorder+rootIndex+1, length-rootIndex-1);
    cout<<root->val<<" ";
    return;
    
}

//由后序中序寻找前序----char表示
void PreOrderFromPostAndIn(char *postorder, char *inorder, int length){
    
    if(length == 0)
        return;
   
    TreeNode *root = new TreeNode(*(postorder+length-1));
    
    int rootIndex = length-1;
    for (; rootIndex >= 0; rootIndex--) {
        if(inorder[rootIndex] == root->val){
            break;
        }
    }
    cout<<root->val<<" ";
    PreOrderFromPostAndIn(postorder, inorder, rootIndex);
    PreOrderFromPostAndIn(postorder+rootIndex, inorder+rootIndex+1, length-rootIndex-1);
    return;
}


//由前序中序求后序  string表示
void PostFromPreIn(string pre, string in, int length){
    
    if(length == 0)
        return;
    
    TreeNode *root = new TreeNode(pre[0]);
    int rootIndex = 0;
    for (; rootIndex < length; rootIndex++) {
        if(in[rootIndex] == root->val)
            break;
    }
    
    PostFromPreIn(pre.substr(1,rootIndex), in.substr(0,rootIndex), rootIndex);
    PostFromPreIn(pre.substr(rootIndex+1,length-rootIndex-1), in.substr(rootIndex+1, length-rootIndex-1), length-rootIndex-1);
    cout<<root->val<<" ";
    
}

//由后序中序求前序  string表示
void PreFromPostIn(string post, string in, int length){
    
    if(length == 0)
        return;
    
    TreeNode *root = new TreeNode(post[length-1]);
    int rootIndex = 0;
    for (; rootIndex < length; rootIndex++) {
        if(in[rootIndex] == root->val)
            break;
    }
    cout<<root->val<<" ";
    PreFromPostIn(post.substr(0,rootIndex), in.substr(0,rootIndex), rootIndex);
    PreFromPostIn(post.substr(rootIndex,length-rootIndex-1), in.substr(rootIndex+1,length-rootIndex-1), length-rootIndex-1);
}

int main3(int argc, const char * argv[]) {
    
    cout<<"已知前序中序求后序为(char表示）:"<<endl;
    PostOrderFromPreAndIn("ABDEC", "DBEAC", 5);
    cout<<endl;
    cout<<"已知中序后序求前序为(char表示）:"<<endl;
    PreOrderFromPostAndIn("DEBCA", "DBEAC", 5);
    cout<<endl;
    
    
    string in = "DBEAC";
    string pre = "ABDEC";
    string post = "DEBCA";
    cout<<"已知前序中序求后序为(string表示）:"<<endl;
    PostFromPreIn(pre,in,5);
    cout<<endl;
    cout<<"已知中序后序求前序为(string表示）:"<<endl;
    PreFromPostIn(post, in, 5);
    cout<<endl;
    
    
    
    return 0;
}
