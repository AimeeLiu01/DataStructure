//
//  main.cpp
//  File_IO
//
//  Created by 刘畅 on 2017/8/15.
//  Copyright © 2017年 刘畅. All rights reserved.

#include <fstream>
#include <ostream>
#include <iomanip>
#include <iostream>
using namespace std;

//写一句话到文件
void writeToFile(){
    
    ofstream ocout;
    ocout.open("/Users/liuchang/Desktop/text123.txt");
    ocout<<"Hello world!"<<endl;
    ocout.close();
    
}

//将字母表写入TXT文本文件
void writeNumberToTxt(){
    
    ofstream ocout;
    /*ios::trunc表示在打开文件前将文件清空,由于是写入,文件不存在则创建*/
    ocout.open("/Users/liuchang/Desktop/inFile.txt",ios::trunc);
    
    int i;
    char a = 'a';
    for(int i = 1; i <= 26; i++){
        ocout<<setw(2)<<i<<"\t"<<a<<"\n";
        a++;
    }
    ocout.close();

}

//逐字符读取文本
void testByChar(){
    
    ifstream icin;
    char c;
    icin.open("/Users/liuchang/Desktop/inFile.txt",ios::in);
    while (!icin.eof()) {
        icin>>c;
        cout<<c;
    }
    icin.close();
}


//逐行读取文本文件
void testByLine(){
    
    char buffer[256];
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/inFile.txt",ios::in);
    cout<<"\ninFile.txt"<<"-----all file is as bollows:----"<<endl;
    while (!icin.eof()) {
        //getline(char *,int,char) 表示该行字符达到256个或遇到换行就结束
        icin.getline(buffer,256,'\n');
        cout<<buffer<<endl;
    }
    icin.close();
}


//如何统计文本的行数
int CountLines(char *filename){
    
    ifstream icin;
    int n = 0;
    string tmp;
    icin.open(filename, ios::in);//ios::in 表示以只读的方式读取文件
    
    if(icin.fail())//文件打开失败，返回0
    {
        return 0;
    }
    else{
        while (getline(icin, tmp, '\n')) {
            n++;
        }
        icin.close();
        cout<<"Total "<<n<<" Lines"<<endl;
        return n;
    }
}

//如何读取文件的某一行内容
string ReadLine(char * filename, int line)
{
    int lines, i = 0;
    string temp;
    ifstream icin;
    icin.open(filename,ios::in);
    lines = CountLines(filename);
    
    if(line <= 0)
        return "Error1: 行数错误，不能为0或者负数。";
    if(icin.fail())
        return "Error2: 文件不存在.";
    if(line > lines)
        return "Error3: 行数超出文本长度。";
    
    while (getline(icin, temp) && i < line-1) {
        i++;
    }
    icin.close();
    cout<<temp<<endl;
    return temp;
}


//读取文件数据到临时数组
int readDataToTempChar(){
    
    ifstream icin;
    int lines;
    char filename[512] = "/Users/liuchang/Desktop/inFile.txt";
    icin.open(filename, ios::in);
    
    if(icin.fail()){
        cout<<"文件不存在。"<<endl;
        icin.close();
    }
    else{//文件存在
        lines = CountLines(filename);
        int *tempInt = new int[lines];
        char *tempChar = new char[lines];
        int i = 0;
        
        while (!icin.eof()) {
            icin>>tempInt[i];
            icin>>tempChar[i];
            i++;
        }
        icin.close();
        
        for(int i = 0; i < lines; i++)
            cout<<tempInt[i]<<"\t"<<tempChar[i]<<endl;
        
        delete []tempChar;
        delete []tempInt;
    }
    return 0;
}



int main(){
    
    char *filename = "/Users/liuchang/Desktop/inFile.txt";
    writeToFile();
    writeNumberToTxt();
    testByChar();
    testByLine();
    
    CountLines(filename);
    ReadLine(filename, 5);
    
    readDataToTempChar();
    
   
    return 0;
    
}
