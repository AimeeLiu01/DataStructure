//
//  main.cpp
//  32. Longest Valid Parentheses
//
//  Created by 刘畅 on 2017/6/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stack>
#include <string>
#include <iostream>
using namespace std;


class Solution{
public:
    int longestValidParentheses(string s){
        stack<int> stack;
        int maxLength = 0;
        int lastValidIndx = 0;
        
        for(int index = 0; index < s.length(); index++){
            if(s[index] == '('){
                stack.push(index);
            }
            else{
                if(stack.empty())
                    lastValidIndx = index + 1;
                else{
                    stack.pop();
                    if(stack.empty()){
                        maxLength = max(maxLength, index - lastValidIndx + 1);
                    }
                    else{
                        maxLength = max(maxLength, index - stack.top());
                    }
                }
            }
        }
        cout<<"The maxLength is "<< maxLength<<endl;
        return maxLength;
    }
};

int main(int argc, const char * argv[]) {
    string s = "())(())";
    Solution sol = *new Solution();
    sol.longestValidParentheses(s);

    return 0;
}
