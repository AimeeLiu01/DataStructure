//
//  main.cpp
//  ACM-01
//
//  Created by 刘畅 on 2017/7/9.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

const int N  = 11;
int d[N];//d[N]中储存数字0～9分别出现的次数
int value;
void deal(int n);

void deal(int n)
{
    if(n <= 0) return;
    int one, ten;
    one = n % 10;
    n /= 10;
    ten = n;
    
    for(int i = 0; i <= one; i++)
        d[i] += value;
    while (ten) {
        d[ten%10] += (one+1)*value;
        ten/=10;
    }
    
    for(int i = 0; i < 10; i++)
        d[i] += value*n;
    d[0] -= value;
    
    value *= 10;
    deal(n-1);
}

int main(int argc, const char * argv[]) {
   
    int a,b;
    while (cin>>a>>b) {
        if(a == 0 && b == 0) break;
        if(a < b){
            int temp = b;
            b = a;
            a = temp;
        }
        for(int i = 0; i < 10; i++)
            d[i] = 0;
        
        value = 1;
        deal(a);
        value = -1;
        deal(b-1);
        cout<<d[1]<<endl;
        
    }
    
    return 0;
}
