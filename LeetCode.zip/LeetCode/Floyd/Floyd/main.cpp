//
//  main.cpp
//  Floyd
//
//  Created by 刘畅 on 2017/8/21.
//  Copyright © 2017年 刘畅. All rights reserved.
//  Floyd最短路径算法 用于描述【有向图】

#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, const char * argv[]) {
    
    //这里我们用邻接矩阵来存储图
    int e[10][10];
    int inf = 99999999;//存储一个我们以为的正无穷
    int n,m;//其中n为顶点个数，m为边的条数
    cin>>n>>m;
    
    for(int i = 1; i <= n; i++){
        for (int j = 1; j <= n; j++) {
            if(i == j)
                e[i][j] = 0;
            else
                e[i][j] = inf;
        }
    }
    
    //读入边 并将边进行赋值
    int t1,t2,t3;
    for(int i = 1; i <= m; i++){
        cin>>t1>>t2>>t3;
        e[t1][t2] = t3;
    }
    
    //核心代码
    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(e[i][j] > e[i][k] + e[k][j])
                    e[i][j] = e[i][k] + e[k][j];
            }
        }
    }
    
    //输出结果
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            cout<<e[i][j]<<" ";
        }
        cout<<endl;
    }
    
    return 0;
}
