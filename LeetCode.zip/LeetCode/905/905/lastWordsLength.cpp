//
//  lastWordsLength.cpp
//  905
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <string>
#include <iostream>
using namespace std;

int getlen(){
    
    string res;
    getline(cin, res);
    int len = 0;
    for(int i = res.size()-1; i >= 0; i--){
        
        if(res[i] == ' '){
            
            if(len > 0){
                return len;
            }
        }
        else{
            ++len;
        }
        
    }
    
    return 0;
    
    
}

int main4(){
    
    int res = getlen();
    cout<<res<<endl;
    return 0;
    
    
}
