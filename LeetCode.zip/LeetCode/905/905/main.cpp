//
//  main.cpp
//  905
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//  string的一些操作

#include <iostream>
#include <string>
using namespace std;

//我们声明一个二维数组
void createTwoArray(){
    
    //我们声明一个二维数组
    int weight,height;
    cin>>weight>>height;
    
    int **visited = new int*[height];
    
    for(int i = 0; i < height; i++){
        visited[i] = new int[weight];
        for (int j = 0; j < weight; j++) {
            cin>>visited[i][j];
        }
    }
    
    for(int i = 0; i < weight; i++){
        for (int j = 0; j < height; j++) {
            cout<<visited[i][j]<<" ";
        }
        cout<<endl;
    }
    
    int arr[weight][height];
    for(int i = 0; i < weight; i++){
        for (int j = 0; j < height; j++) {
            
            if(i == 0 && j == 0)
                arr[i][j] = visited[i][j];
            else if(i != 0 && j == 0)
                arr[i][j] = arr[i-1][j] + visited[i][j];
            else if(i == 0 && j != 0)
                arr[i][j] = arr[i][j-1] + visited[i][j];
            else
                arr[i][j] = max(arr[i-1][j] , arr[i][j-1]) + visited[i][j];
            
        }
    }
    
    for (int i = 0; i < weight; i++) {
        for (int j = 0; j < height; j++) {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
    
    
    
}



int main1(int argc, const char * argv[]) {
    
    //createTwoArray();
    
    char movestar[15] = "awd sdsd aw";
    char str[10] = "avxde";
    cout<<movestar[4]<<endl;
    cout<<str<<endl;
    cout<<movestar<<endl;
    
    char p[20] = "Hello Liuchang";
    char *pp = "Hello world";
    cout<<p<<endl;
    cout<<pp<<endl;
    cout<<strlen(p)<<endl;
    cout<<strlen(pp);
    
    char s1[10] = {1,2,3,4,5,6,7,8,9,10};
    int size = strlen(s1);
    for (int i = 0; i < size; i++) {
        cout<<s1[i];
    }
    cout<<endl;
    
    char str2[] = "aaaaa";
    char *pcstr = "aa";
    cout<<str2<<endl;
    cout<<pcstr<<endl;
    
    char *str3 = "1111";
    char *str4 = "1111";
    int res = strcmp(str3, str4);
    cout<<res<<endl;
    
    char *a = "Global World";
    char d[20];
    strcpy(d, a);
    cout<<d<<endl;
    
    const char *q = "hellp pz";
    cout<<q<<endl;
    const char *s = "lalalala";
    cout<<s<<endl;
    
    string st("hello world pz pz pz");
    string sss = "LiuXiaoChang";
    cout<<sss<<endl;
    cout<<st<<endl;
    
    const char *s5 = "a try";
    string ss5 = s5;//char转化为string  时可以直接转化
    cout<<ss5<<endl;
    
    const char *str8 = ss5.c_str();
    cout<<str8<<endl;//string转化为char时  需要用到c_str()函数
    
    char ch[] = "LLLLALLLLALLLA";
    string stri(ch);
    cout<<stri<<endl;
    
    cout<<"-----------------"<<endl;
    
    string strstr;
    getline(cin, strstr);//string类型的调用形式
    cout<<strstr<<endl;

    char temp[100];
    cin.getline(temp, 100);//char类型的调用形式
    cout<<temp<<endl;
    return 0;
    
    
}
