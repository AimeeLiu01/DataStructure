//
//  reverseWordsInString.cpp
//  905
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

void reverseWord(string str){
    
    for(int i = str.size()-1; i >= 0; i--){
        
        while (i >= 0 && str[i] == ' '){
            cout<<" ";
            i--;
        }//找到一个单词结束的位置
        int j = i;
        while (j >= 0 && str[j] != ' ') {
            j--;
        }//跳出循环后 j指向的是单词开始的位置
        
        for(int k = j+1; k <= i; k++){
            cout<<str[k];
        }
        
        i = j+1;
        
    }
}


int main2(){
    
    string res;
    getline(cin, res);
    reverseWord(res);
    cout<<endl;
    return 0;
}
