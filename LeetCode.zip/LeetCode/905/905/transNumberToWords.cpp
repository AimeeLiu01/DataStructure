//
//  transNumberToWords.cpp
//  905
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//  将数字转化为words

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

 //小于20的数
string digits[20] = {" ","One","Two","Three","Four","Five","Six","Seven","Eight",
    "Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen",
    "Eighteen","Nineteen"};

//10的倍数
string tens[10] = {" ","Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"};

string zero[1] = {"Zero"};

string lions[4] = {" ","Thousands","Million","Billion"};

string lessThan20(int number){
    return digits[number];
}

string lessThan99(int number){
    if(number < 20){
        return lessThan20(number);
    }
    else{
        int x = number/10;
        int y = number%10;
        string res = tens[x] + " " + digits[y];
        return res;
    }
}


string lessThan999(int number){
    if(number == 0){
        return zero[0];
    }
    if(number < 20){
        return lessThan20(number);
    }
    else if(number < 99){
        return lessThan99(number);
    }
    else{
        int x = number/100;
        int y = number%100;
        
        if(y > 0 && y < 10){
            string res = digits[x] + " " + "hundred and" + " " + lessThan99(y);
            return res;
        }
        else{
            string res = digits[x] + " " + "hundred" + " " + lessThan99(y);
            return res;
        }
    }
    
}


string AnyNumber(int number){
   
    if(number < 999)
        return lessThan999(number);
    
    int idx = 0;
    string res;
    for(; number > 0; number /= 1000, idx++){
        
        if(number%1000 == 0) continue;
        string tmp = lessThan999(number % 1000);
        if(res != ""){
            res = tmp + " " + lions[idx] + " " + res;
        }
        else{
            res = tmp + " " + lions[idx] + " ";
        }
    }
    
    return res;
}


int main(){
    
    string res;
    res = lessThan999(13);
    cout<<res<<endl;
    res = lessThan999(16);
    cout<<res<<endl;
    res = lessThan999(89);
    cout<<res<<endl;
    res = lessThan999(10);
    cout<<res<<endl;
    res = lessThan999(201);
    cout<<res<<endl;
    res = lessThan999(100);
    cout<<res<<endl;
    res = lessThan999(0);
    cout<<res<<endl;
    res = AnyNumber(1234567);
    cout<<res<<endl;
    res = AnyNumber(12345);
    cout<<res<<endl;
    res = AnyNumber(123);
    cout<<res<<endl;
    return 0;
    
    
}
