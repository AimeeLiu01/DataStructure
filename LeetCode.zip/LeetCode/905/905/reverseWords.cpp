//
//  reverseWords.cpp
//  905
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <string>
#include <iostream>
using namespace std;

void reverseWords(string &str){
    
    for(int i = 0; i < str.size(); i++){
        
        while (i < str.size() && str[i] == ' ') {
            cout<<" ";
            i++;
        }//跳出循环后 i代表的是单词开始的位置
        
        int j = i;
        while (j < str.size() && str[j] != ' ') {
            j++;
        }//调出循环后 j代表的是一个单词结束的位置
        
        for(int k = j-1; k >= i; k--){
            cout<<str[k];
        }//输出这个单词
        
        i = j-1;

    }
    
}


int main1(){
    string str;
    getline(cin, str);
    reverseWords(str);
    cout<<endl;

    return 0;
}
