//
//  main.cpp
//  103. Binary Tree Zigzag Level Order Traversal
//
//  Created by 刘畅 on 2017/6/11.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

class Solution{
public:
    vector<vector<int>> zigzagLevelOrder(TreeNode* root){
        
        vector<vector<int>> ret;
        queue<TreeNode*> queue;
        if(root == NULL) return ret;
        queue.push(root);
        int i = 0;
        
        while(!queue.empty()){
            vector<int> subret;
            int size = queue.size();
            while(size--){
                root = queue.front();
                queue.pop();
                subret.push_back(root->val);
                if(root->left != NULL) queue.push(root->left);
                if(root->right != NULL) queue.push(root->right);
            }
            
            if(i++ % 2 == 1)
                reverse(subret.begin(),subret.end());
            ret.push_back(subret);
        }
        
        return ret;
    }
};


int main(int argc, const char * argv[]) {
    
    TreeNode *root = new TreeNode(0);
    TreeNode *node1 = new TreeNode(1);
    TreeNode *node2 = new TreeNode(2);
    
    TreeNode *node3 = new TreeNode(3);
    TreeNode *node4 = new TreeNode(4);
    TreeNode *node5 = new TreeNode(5);
    TreeNode *node6 = new TreeNode(6);
    
    root->left = node1;
    root->right = node2;
    
    node1->left = node3;
    node1->right = node4;
    
    node2->left = node5;
    node2->right = node6;
    
    Solution s = *new Solution();
    vector<vector<int>> result;
    result = s.zigzagLevelOrder(root);
    cout<<result[0][0]<<endl;
    
    for(int i = 1; i < result.size(); i++){
        for(int j = 0; j < result[2].size(); j++){
          
            if(result[i][j] != 0){
                cout<<result[i][j];
            }
        }
        cout<<endl;
    }
    
    
    return 0;
    
   
}
