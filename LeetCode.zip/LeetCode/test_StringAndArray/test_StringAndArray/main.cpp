//
//  main.cpp
//  test_StringAndArray
//
//  Created by 刘畅 on 2017/8/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

int main(int argc, const char * argv[]) {
    
    char s11[100];
    cin.getline(s11, 100);
    cout<<s11<<endl;

    int n;
    cin>>n;
    int * value2 = new int[n];
    for(int i = 0; i < n; i++){
        value2[i] = 2 * i;
    }
    for(int i = 0; i < n; i++){
        cout<<value2[i]<<" ";
    }
    delete []value2;
    cout<<endl;
    
    char *a= "Golden Global View";
    char d[20];
    strcpy(d, a);
    cout<<d<<endl;
    
    const char * q = "hello world!";
    cout<<q<<endl;
    
    string s = "Hello World!";
    cout<<s.length()<<endl;
    
    
    char *p="Hello world!", *temp=p;
    const char *q2="Nice to see you!";
    cout<<p<<q2<<endl;
    cout<<*p<<","<<*(q2+1)<<endl;
    
    p=temp;
    cout<<"p is made by:\n";
    for(int i=0;i<strlen(p);i++)
        cout<<*temp++<<endl;
    
    
    const char * pc = "a try";
    string s1 = pc;
    cout<<s1<<endl;
    
    const char* strchar = s1.c_str();
    char * strchar1 = (char*)s1.c_str();
    
    cout<<strchar<<endl;
    cout<<strchar1<<endl;
    
    
    char mychr[] = "Liu Chang";
    string str4(mychr);
    cout<<str4<<endl;
    
    string str5 = mychr;
    cout<<str5<<endl;
    
   

    return 0;
}
