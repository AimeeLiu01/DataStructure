//
//  main.cpp
//  SingleList
//
//  Created by 刘畅 on 2017/8/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//  目标： 单链表  实现链表的创建  并能够访问链表中的值  进行添加结点和删除结点的操作方便

#include <iostream>
#include <string>
using namespace std;

class List;

//结点类
class ListNode{
    
friend class List;
friend class ListIterator;
    
public:
    ListNode(int x = 0);//构造函数中可以写默认值
private:
    int data;
    ListNode* link;
};

//链表类
class List{

friend class ListIterator;
    
public:
    List(){
        first = 0;
    };
    void Create2();
    void Insert80(ListNode *x);
    void Delete(ListNode *y);
private:
    ListNode *first;
};

//ListNode的构造函数
ListNode::ListNode(int element){//节点的构造函数
    data = element;
    link = 0;
}


//List的成员函数
void List::Create2(){
    first = new ListNode(10);
    first->link = new ListNode(20);
}

//List的成员函数(插入操作）
void List::Insert80(ListNode *x){//将80插入到x之后
    ListNode *t = new ListNode(80);
    if(!first){
        first = t;
        return;
    }
    t->link = x->link;
    x->link = t;
    
}
//List的删除函数（删除操作）
void List::Delete(ListNode *y){
    ListNode *x;
    if(!y){
        x = first;
        first = first->link;
    }
    else{
        x = y->link;
        y->link = x->link;
    }
}

//游标类  用来访问结点 并输出每一个结点的值
class ListIterator{
public:
    ListIterator(const List& a): list(a),current(a.first){};
    bool NotNull();
    bool NextNotNull();
    int *first();
    int *Next();
    int sum(const List& a);
private:
    const List& list;
    ListNode* current;
    
};

//游标类来判断链表是否为空
bool ListIterator::NotNull(){
    if(current) return true;
    else
        return false;
}

//游标类来判断链表的下一个字段是否为空
bool ListIterator::NextNotNull(){
    if(current && current->link)
        return true;
    else
        return false;
}
//返回链表的首元素的值的地址
int* ListIterator::first(){
    
    if(list.first) return &list.first->data;
    else
        return 0;
    
}
//返回链表的游标所在元素的下一个结点的值的地址
int* ListIterator::Next(){
    if(current){
        current = current->link;
        if(current)
            return &current->data;
    }
    return 0;
}

//对于链表中的每一个元素进行求和操作
int ListIterator::sum(const List& a){
    
    ListIterator ai(a);
    if(!ai.NotNull())//如果链表为空表
        return 0;
    int retvalue = *ai.first();
    while (ai.NextNotNull()) {
        retvalue += *ai.Next();
    }
    return retvalue;
}


int main(int argc, const char * argv[]) {
    List l;
    l.Create2();//创建出来两个结点 分别为10和20
    ListIterator iter(l);
    

    cout<<"链表创建完成。"<<endl;
    
    
  
    cout<<"我的链表元素分别为:"<<endl;
    
    if(iter.NotNull()){
        cout<<*iter.first()<<" ";
        while (iter.NextNotNull()) {
            cout<<*iter.Next()<<" ";
        }
    }
    
    cout<<endl;
    cout<<"我的链表元素的和为："<<iter.sum(l)<<endl;
    
    
    
    return 0;
}









