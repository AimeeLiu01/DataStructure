//
//  main.cpp
//  86. Partition List
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//
#include <iostream>
#include <stack>
#include <vector>
using namespace std;

/*
 For example,
 Given 1->4->3->2->5->2 and x = 3,
 return 1->2->2->4->3->5.
 思路：1.建立一个less链表和一个great链表，遍历head链表
 2.小于给定值的放于less之后  大于等于给定值的放于great之后
 3.最后把great链表接到less链表之后
 */

struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution {
public:
    ListNode* partition(ListNode* head, int x)
    {
        //将两部分分别链接出来，用lh记录左边部分，gh记录右边部分
        if(head == NULL || head->next == NULL) return head;
        ListNode *lessHead = new ListNode(0);
        ListNode *greateHead = new ListNode(0);
        
        ListNode *p = head, *less = lessHead, *greate = greateHead;
        
        while(p != NULL)
        {
            if (p->val < x)
            {
                less->next = p;
                less = less->next;
            }
            else
            {
                greate->next = p;
                greate = greate->next;
            }
            
            p = p->next;
        }
        
        //最后两部分链接起来即可
        less->next = NULL;
        greate->next = NULL;
        less->next = greateHead->next;
        return lessHead->next;
    }
};


int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(4);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(2);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    
    Solution s = *new Solution();
    ListNode *result ;
    result = s.partition(node1, 4);
    
    while (result) {
        cout<<result->val<<" ";
        result = result->next;
    }
    cout<<endl;
    
    return 0;
}


