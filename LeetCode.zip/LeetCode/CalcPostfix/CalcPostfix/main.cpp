//
//  main.cpp
//  CalcPostfix
//  Amiee's code
//  Created by 刘畅 on 2017/8/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
#include <stack>
using namespace std;

int calcPostfix(string str){
    
    stack<int> nums;
    
    for(int i = 0; i < str.length(); i++){
        if(str[i]-'0' > 0 && str[i]-'0' < 9){
            nums.push(str[i]-'0');
        }
        else{
            int num1 = nums.top();
            nums.pop();
            int num2 = nums.top();
            nums.pop();
            if(str[i] == '+')
                nums.push(num1+num2);
            if(str[i] == '-')
                nums.push(num2-num1);
            if(str[i] == '*')
                nums.push(num1*num2);
            if(str[i] == '/')
                nums.push(num2/num1);
        }
    }
    return nums.top();
}

int main(int argc, const char * argv[]) {
    string s;
    cout<<"请输入一个后缀表达式："<<endl;
    cin>>s;
    cout<<"经过计算得到的结果为："<<calcPostfix(s)<<endl;
    return 0;
}
