//
//  main.cpp
//  test
//
//  Created by 刘畅 on 2017/6/11.
//  Copyright © 2017年 刘畅. All rights reserved.
//
#include <vector>
#include <iostream>
#include <queue>
using namespace std;

class Solution{
public:
    void solve(vector<vector<char>> &board){
        
        int row = board.size();
        if(row == 0) return;
        int col = board[0].size();
        if(col == 0) return;
        
        for(int i = 0; i < row; i++){
            if(board[i][0] == '0'){
                DFS(board, i , 0);
            }
            if(board[i][col-1] == '0'){
                DFS(board, i, col-1);
            }
        }
        
        for(int j = 0; j < col; j++){
            if(board[0][j] == '0'){
                DFS(board, 0, j);
            }
            if(board[row-1][j] == '0'){
                DFS(board, row-1, j);
            }
        }
        
        for(int i = 0; i < row; i++){
            for(int j = 0; j < col; j++){
                
                if(board[i][j] == '0'){
                    board[i][j] = 'X';
                }
                if(board[i][j] == '1'){
                    board[i][j] = '0';
                }
            }
        }
        
    }
    
    void DFS(vector<vector<char>> &board, int x, int y){
        int row = board.size();
        int col = board[0].size();
        int X[4] = {1,0,-1,0};
        int Y[4] = {0,1,0,-1};
        queue<pair<int,int>> q;
        q.push(make_pair(x,y));
        
        board[x][y] = '1';
        while(!q.empty()){
            auto t =  q.front();
            q.pop();
            for(int i = 0; i < 4; i++){
                int xx = x + X[i];
                int yy = y + Y[i];
                
                if(xx > 0 && xx < row && yy > 0 && yy < col){
                    
                    if(board[xx][yy] == '0'){
                        board[xx][yy] = '1';
                        q.push(make_pair(xx, yy));
                    }
                }
            }
        }
        
    }
    
};


int main(){
    
    vector<vector<char>> b(4, vector<char>(4));;
    b[0][0] = 'X';
    b[0][1] = 'X';
    b[0][2] = '0';
    b[0][3] = 'X';
    
    b[1][0] = '0';
    b[1][1] = '0';
    b[1][2] = '0';
    b[1][3] = 'X';
    
    b[2][0] = 'X';
    b[2][1] = 'X';
    b[2][2] = '0';
    b[2][3] = 'X';
    
    b[3][0] = 'X';
    b[3][1] = '0';
    b[3][2] = 'X';
    b[3][3] = 'X';
    
    Solution a = *new Solution();
    a.solve(b);
    for(int i = 0; i < 4; i++){
        for(int j = 0; j < 4; j++){
            cout<<b[i][j];
        }
        cout<<endl;
    }
    
    return 0;
    
    
}







