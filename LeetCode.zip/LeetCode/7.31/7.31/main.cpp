//
//  main.cpp
//  7.31
//
//  Created by 刘畅 on 2017/7/31.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <string>
using namespace std;

int main1() {
    
    //7.31日任务  理解数组、字符串、KMP

    //字符数组
    char p[5] = "dddd";
    for(int i = 0; i < 5; i++){
        cout<<p[i]<<" ";
    }
    cout<<endl;
    
    //字符数组
    char acStr[] = "aaaaa";
    cout<<strlen(acStr)<<endl;

    
    //字符型数组指针
    char *pcStr = "aaaaa";
    for(int i = 0; *pcStr != '\0'; *pcStr++){
        cout<<*pcStr<<" ";
    }
    cout<<endl;
    
    //字符串的拼接
    string a = "abdcdse";
    string b = "dsds";
    string c = a + b;//无缝连接
    cout<<c<<endl;
    
    
    //声明定义
    char *f[2];//字符型数组指针
    int *ab[2];//整数型数组指针
    f[0] = "thank you";
    f[1] = "Good Morning";
    
    //*ab[0] = 1;
    //*ab[1] = 2;
    
    cout<<f[0]<<endl;
    cout<<f[1]<<endl;
    cout<<ab[0]<<" "<<ab[1]<<endl;
    
    //字符串赋值
    char k[10] = "abcdfghid";
    char j[10] = {'h','e','l','l','o'};
    char i[10];
    strcpy(i, "hihihi");
    cout<<k<<endl<<j<<endl<<i<<endl;
    
    //strcpy函数
    char aa[7] = "abcdef";
    char bb[4] = "ABC";
    strcpy(aa, bb);//把字符串s2中的内容copy到s1中,连字符串结束标志也一起copy.
    cout<<aa<<endl<<bb<<endl;

    //strcat函数
    strcat(aa, bb);//第二个字符接至第一个后面
    cout<<aa<<endl<<bb<<endl;
   /****************************************/
    char *pq = "Hello World!", *temp = pq;
    const char *qq = "Nice to see you!";
    cout<<pq<<","<<qq<<endl;
    cout<<*pq<<","<<*(qq+1)<<endl;
    /**************************************/
    string st("Hello Liuchang");
    cout<<st.size()<<endl;
    
    string s3(st);
    cout<<s3<<endl;
    
    string s1("Liuchang,");
    string s2("Liuchong.");
    string s4 = s1 + s2;
    cout<<s4<<endl;
    /**************************************/
    
    return 0;
}


int main2(){
    cout<<"获取一个字符串，可以有空格："<<endl;
    string str6;
    getline(cin,str6);
    cout<<str6<<endl;
    
    cout<<"获取一个字符串，无空格："<<endl;
    char str[15];
    cin>>str;
    cout<<str<<endl;
    
 
    
    return 0;
    
    
}

/****KMP算法********************************************/
void setOffsetIndex(string targstr, int *offsetIdex){
    
    //遍历字符串
    offsetIdex[0] = -1;
    for(int i = 1; i < targstr.size(); i++){
        //和之前的最大公共子序列的下一位进行比较
        if(targstr[i] == targstr[offsetIdex[i-1]+1]){
            //如果可以就让当前索引的最大子串变大
            offsetIdex[i] = offsetIdex[i-1] + 1;
        }else{
            offsetIdex[i] = -1;
        }
    }
    
    for(int i = 0; i < targstr.size(); i++){
        cout<<offsetIdex[i]<<endl;
    }
    
}


int main(){
    
    
    cout<<"请输入子串："<<endl;
    string substr = "";
    cin>>substr;
    cout<<"请输入被匹配的字符串："<<endl;
    string str = "";
    cin>>str;
    
    //算出每一位目标子串的偏移量
    int* offsetIndex = new int[substr.size()];
    
    setOffsetIndex(substr,offsetIndex);
    
    //两个索引在两个串上走
    int t = 0;//子串上走
    int i = 0;//字符串上走
    
    while(t < substr.size() && i < str.size()){
        
        if(substr[t] == str[i])
        {
            t++;
            i++;
        }else{
            if(offsetIndex[t] == -1){
                t = 0;
                i++;
            }else{
                t = offsetIndex[t];
            }
        }
        
    }
    
    //如果是子串走完了，则说明匹配成功
    if(t == substr.size())
    {
        cout<<"匹配成功，匹配的位置在  "<< i  -  substr.size() << endl;

    }else{
        cout<<"没有匹配成功！"<<endl;
    }
 
    
    
}
