//
//  main.cpp
//  1028.
//
//  Created by 刘畅 on 2017/7/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, const char * argv[]) {
    char temp[8], stack[255][255] = {"http://www.acm.org/"};
    int k = 0, n;
    while (cin>>temp) {
        if(temp[0] == 'Q')
            break;
        else if(temp[0] == 'V')
        {
            k++;
            cin>>stack[k];
            cout<<stack[k]<<endl;
            n = k;
        }
        else if(temp[0] == 'B')
        {
            k--;
            if(k < 0)
            {
                cout<<"Ignored\n";
                k = 0;
            }
            else
                cout<<stack[k]<<endl;
        }
        else
        {
            k++;
            if(k > n){
                cout<<"Ignored\n";
                k = n;
            }
            else
                cout<<stack[k]<<endl;
        }
    }
    return 0;
}
