//
//  main.cpp
//  ACM-03
//
//  Created by 刘畅 on 2017/7/9.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stdlib.h>
using namespace std;


int main(int argc, const char * argv[]) {
    
    int i,j,k;
    double ans;
    int n;
    int len[110];
    while(cin >> n && n != 0){
        for(int i = 1; i <= n; i++){
            cin>>len[i];
        }
        ans = -1;
        for(i = 1; i <= n; i++){
            for(j = i+1; j <= n; j++){
                for(k = j+1; k <=n; k++){
                    if(len[i] * len[i] + len[j] * len[j] == len[k] * len[k]){
                        if(0.5 * len[i] * len[j] > ans)
                            ans = 0.5 * len[i] * len[j];
                    }
                }
            }
        }
        if(ans == -1)
            cout<<"My Gods!"<<endl;
        else{
            cout<<ans;
        }
        
    }
    return 0;
}
