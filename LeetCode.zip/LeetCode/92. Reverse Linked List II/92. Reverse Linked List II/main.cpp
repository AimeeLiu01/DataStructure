//
//  main.cpp
//  92. Reverse Linked List II
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;

//本题是反转 链表中位置在m到n的子链表
//思路：在原链表的基础上直接进行反转

struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution{
public:
     ListNode* reverseBetween(ListNode* head, int m, int n) {
         
         if(head == NULL) return NULL;
         ListNode newHead(0);
         newHead.next = head;
         ListNode *pre = &newHead, *cur = head, *next = NULL;
        
         int i = 1;
         
         while (i < n) {
             if (i++ < m) {
                 pre = cur;
                 cur = cur->next;
             }//找到要交换链表的头节点
             else{
                 next = cur->next;
                 cur->next = cur->next->next;
                 next->next = pre->next;
                 pre->next = next;
             }
         }
         
         ListNode *temp = newHead.next;
         while (temp) {
             cout<<temp->val<<" ";
             temp = temp->next;
         }
         cout<<endl;
         
         return newHead.next;
     }
};


int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(4);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    
    Solution s = *new Solution();
    s.reverseBetween(node1, 2, 5);
    
    return 0;
}






