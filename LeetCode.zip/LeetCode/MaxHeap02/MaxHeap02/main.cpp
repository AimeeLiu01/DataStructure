//
//  main.cpp
//  MaxHeap02
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
#include <queue>
using namespace std;

class MaxHeap{
public:
    int *maxheap;
    int MaxSize;
    int n;
public:
    MaxHeap(int x){
        MaxSize = x;
        n = 0;
        maxheap = new int[MaxSize];
    }
    void Insert(int x){
        
        n++;
        
        int i;
        for(i = n; i > 1;){
            
            if(x <= maxheap[i/2]) break;
            maxheap[i] = maxheap[i/2];
            i = i/2;
            
        }
        maxheap[i] = x;
        cout<<"We have insert "<<x<<" into the heap~"<<endl;
    }
    
    
    void Delete(){
        int x = maxheap[1];
        int k = maxheap[n];
        n--;
        
        int i,j;//j为i的子女结点
        for(i = 1, j = 2; j <= n;){
            
            if(j < n && maxheap[j+1] > maxheap[j]) j++;
            if(k >= maxheap[j]) break;
            maxheap[i] = maxheap[j];
            i = j;
            j = 2*j;
        }
        maxheap[i] = k;
        cout<<"We have delete "<<x<<" successfully "<<endl;
    }
    
};

int main(int argc, const char * argv[]) {
    
    
    MaxHeap heap = *new MaxHeap(10);
    heap.Insert(2);
    heap.Insert(8);
    heap.Insert(3);
    heap.Insert(4);
    heap.Insert(10);
    for(int i = 1; i <= 5; i++){
        cout<<heap.maxheap[i]<<" ";
    }
    cout<<endl;
    heap.Delete();
    heap.Delete();
    heap.Delete();
    heap.Delete();
    heap.Delete();
    cout<<endl;

    
    

}
