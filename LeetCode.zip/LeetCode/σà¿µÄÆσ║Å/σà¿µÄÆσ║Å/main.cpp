//
//  main.cpp
//  全排序
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include<iostream>
using namespace std;

void Permutation(char p[], int start){
    
    int size = (int)strlen(p);
    if (start == size) {
        cout<<p<<endl;
    }
    else{
        for(int i = start; i != size; i++){
            swap(p[i], p[start]);
            Permutation(p, start+1);
            swap(p[i], p[start]);
        }
    }
}


int main(void)
{
    char str[] = "aabc";
    Permutation(str, 0);
    
    char p[] = "1234";
    Permutation(p, 0);
    
    char *input = "abc";
    string aaa = input;
    aaa[1] = 'a';
    cout<<aaa[1];
    
    return 0;
}
