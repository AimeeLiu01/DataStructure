//
//  IOWith,.cpp
//  全排序
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*#include <stdio.h>
#include <iostream>
#include <fstream>
using namespace std;


int main(){
    
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/text1.txt");
    
    char height, weight;
    char tem;
    icin>>height>>tem>>weight;
    
    cout<<height<<tem<<weight<<endl;
    
    int arr[height*weight];
    char tmp;
    int i = 0;
    while (icin>>tmp) {
        
        if(tmp == ','){
            cout<<tmp;
            continue;
        }
        else{
          int newTmp = tmp-'0' + 1;
          cout<<newTmp;
          arr[i] = newTmp;
          i++;
          if(i % 3 == 0){
             cout<<endl;
          }
        }
    }
    
    ofstream ocout;
    ocout.open("/Users/liuchang/Desktop/text1.txt");
    ocout.clear();
    ocout<<height<<","<<weight<<endl;
   
    for (int i = 0; i < 12; i++) {
        ocout<<arr[i]<<",";
        if ((i+1) % 3 == 0) {
            ocout<<endl;
        }
    }
    
    
    return 0;
    
}*/
