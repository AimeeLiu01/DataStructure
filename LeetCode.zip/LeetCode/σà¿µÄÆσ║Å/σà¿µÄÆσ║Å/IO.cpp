//
//  IO.cpp
//  全排序
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <iostream>
#include <fstream>
using namespace std;


int main(){
    
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/text.txt");
    
    int height, weight;
    icin>>height>>weight;
    
    cout<<height<<" "<<weight<<endl;
    
    int arr[height*weight];
    int tmp;
    int i = 0;
    while (icin>>tmp) {

        int newTmp = tmp + 1;
        cout<<newTmp<<" ";
        arr[i] = newTmp;
        i++;
        if(i % height == 0){
            cout<<endl;
        }
    }
    
    ofstream ocout;
    ocout.open("/Users/liuchang/Desktop/text.txt");
    ocout.clear();
    ocout<<height<<" "<<weight<<endl;
    
    for (int i = 0; i < height*weight; i++) {
        ocout<<arr[i]<<" ";
        if ((i+1) % height == 0) {
            ocout<<endl;
        }
    }
   
   
    return 0;
    
}*/
