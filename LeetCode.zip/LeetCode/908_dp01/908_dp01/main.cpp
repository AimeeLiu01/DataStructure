//
//  main.cpp
//  908_dp01
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//  股票在哪一天买 哪一天卖出的获利最大

/*#include <iostream>
using namespace std;

int maxfix(int arr[], int size){
    
    int res = 0;
    int maxValue = INT_MIN;
    
    for (int i = size - 1; i >= 0; i--) {
        maxValue = max(maxValue, arr[i]);
        res = max(res, maxValue - arr[i]);
    }
    cout<<res<<endl;
    return res;
}


int main(int argc, const char * argv[]) {
   
    int arr[6] = {7,1,5,3,6,4};
    maxfix(arr, 6);
    return 0;
}
*/
