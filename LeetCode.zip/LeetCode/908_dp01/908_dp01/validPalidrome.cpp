
//  908_dp01
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

void isPalindrome(string s){
    
    int i = 0;
    int j = s.size()-1;
    while (s[i] == s[j] && i < j) {
        i++;
        j--;
    }
    if(s.size() % 2 == 0 && i > j){
        cout<<"True"<<endl;
    }
    else if(s.size() % 2 == 1 && i == j){
        cout<<"True"<<endl;
    }
    else{
        cout<<"False"<<endl;
    }

}

int main(){
    string s;
    cin>>s;
    isPalindrome(s);
    return 0;
}
