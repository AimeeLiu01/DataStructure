//
//  dp02.cpp
//  908_dp01
//
//  Created by 刘畅 on 2017/9/8.
//  Copyright © 2017年 刘畅. All rights reserved.
//  可以随时买入和卖出 只需要把上升部分的值加进去就好了

/*#include <stdio.h>
#include <string>
#include <iostream>
using namespace std;

int maxProfit(int arr[], int size){
    
    int res = 0;
    if(size < 2)
        return 0;
    
    for (int i = 1; i < size; i++) {
        if(arr[i] > arr[i-1]){
            res += arr[i] - arr[i-1];
        }
    }
    cout<<res<<endl;
    return res;
}


int main(){
    

    int arr[6] = {7,1,5,3,6,4};
    maxProfit(arr, 6);
    return 0;
    
    
}*/
