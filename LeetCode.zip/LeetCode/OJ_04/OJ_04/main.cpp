//
//  main.cpp
//  OJ_04
//
//  Created by 刘畅 on 2017/7/11.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;


int main(int argc, const char * argv[]) {
   
    int s,d;
    while(cin>>d>>s){
        int i,ans;
        for(int i = 1; i <= 5; i++)
            if(s * (5-i)-d * i < 0)
                break;
        if(i == 4)
            ans = 3 * s - 9 * d;
        else
            ans = s * (12 - 2 * i) - d * 2 * i;
        
        if( i == 5 || ans < 0)
            cout<<"Deflicit"<<endl;
        else
            cout<<d<<endl;
    }
    return 0;
}
