//
//  main.cpp
//  Stack_class
//  Aimee's code
//  Created by 刘畅 on 2017/8/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

template<class Type>
class Stack{
    
public:
    Stack(int size);
    bool isEmpty();
    bool isFull();
    void push(const Type& x);
    Type top();
    void pop();
    Type Delete(Type&);
    int getSize();
    
private:
    int topIndex;
    int maxSize;
    Type* stack;//用数组来实现一个栈
    
};

template<class Type>
Stack<Type>::Stack(int size) :maxSize(size){
    topIndex = -1;
    stack = new Type[maxSize];
}

template<class Type>
bool Stack<Type>::isEmpty(){
    if(topIndex == -1){
        return true;
    }
    else
        return false;
}

template<class Type>
bool Stack<Type>::isFull(){
    if(index == maxSize-1)
        return true;
    else
        return false;
}

template<class Type>
void Stack<Type>::push(const Type& x){
   stack[++topIndex] = x;
}

template<class Type>
Type Stack<Type>::top(){
    return stack[topIndex];
}

template<class Type>
void Stack<Type>::pop(){
    topIndex--;
}


template<class Type>
int Stack<Type>::getSize(){
    return topIndex+1;
}






int main1(int argc, const char * argv[]) {
   
    
    
    Stack<int> stack(10);
    cout<<stack.getSize()<<endl;//0
    stack.push(2);
    stack.push(5);
    cout<<stack.top()<<endl;//5
    stack.pop();
    stack.push(8);
    stack.push(9);
    cout<<stack.top()<<endl;//9
    stack.pop();
    cout<<stack.getSize()<<endl;//2
    
    return 0;
    

}
