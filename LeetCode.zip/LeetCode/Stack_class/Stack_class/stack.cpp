//
//  stack.cpp
//  Stack_class
//
//  Created by 刘畅 on 2017/8/23.
//  Copyright © 2017年 刘畅. All rights reserved.
//  Aimee's code of stack

#include <stdio.h>
#include <iostream>
using namespace std;

template<class Type>

class Stack{
    
public:
    Stack(int size = 100){
        topIndex = -1;
        maxsize = size;
        stk = new Type[maxsize];
    }
    bool isEmpty();
    bool isFull();
    void push(Type x);
    Type top();
    void pop();
    int getSize();
    
private:
    int topIndex;
    Type* stk;
    int maxsize;
    
};


template<class Type>
bool Stack<Type>::isEmpty(){
    if(topIndex == -1){
        cout<<"The stack is empty."<<endl;
        return true;
    }
    else{
        cout<<"The stack is not empty."<<endl;
        return false;
    }
}

template<class Type>
bool Stack<Type>::isFull(){
    if(topIndex == maxsize-1){
        cout<<"The stack is Full."<<endl;
        return true;
    }
    else{
        cout<<"The stack is not Full."<<endl;
        return false;
    }
}


template<class Type>
void Stack<Type>::push(Type x){
    
    ++topIndex;
    stk[topIndex] = x;
    
}

template<class Type>
Type Stack<Type>::top(){
    return stk[topIndex];
}

template<class Type>
void Stack<Type>::pop(){
    
    --topIndex;
}

template<class Type>
int Stack<Type>::getSize(){
    return topIndex+1;
}


int main(){
    Stack<int> s(5);
    s.push(1);
    s.push(5);
    s.push(6);
    s.push(3);
    s.push(2);
    s.isFull();
    s.isEmpty();
    cout<<s.top()<<endl;
    s.pop();
    cout<<s.top()<<endl;
    s.pop();
    cout<<s.top()<<endl;
    s.pop();
    cout<<"Now, the stack's size is : "<<s.getSize()<<endl;
    
    return 0;
}



