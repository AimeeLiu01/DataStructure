//
//  main.cpp
//  IO_01
//
//  Created by 刘畅 on 2017/7/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int main() {
    
    int a,b;
    while (cin>>a>>b) {
        cout<<a+b<<endl;
    }
    return 0;
    
}
