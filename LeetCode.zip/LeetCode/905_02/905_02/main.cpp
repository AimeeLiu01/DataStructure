//
//  main.cpp
//  905_02
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//  将中缀表达式转化为后缀表达式
//  1.遇到符号就进栈  比如说遇到(  就将(进栈  遇到数字就打印出来  遇到）就弹栈
//  遇到符号时  和栈顶的符号进行比较 如果优先级比栈顶的元素高 就进栈 否则就弹栈

#include <iostream>
#include <string>
#include <stack>
using namespace std;

stack<char> stk;
stack<int> num;
bool isNumber(char s){
    
    if(s >= '0' && s <= '9'){
        return true;
    }
    else
        return false;
}

int returnNumber(char s){
    int tmp = s-'0';
    return tmp;
}

bool isChar(char s){
    if(s == '+' || s == '-' || s == '*' || s == '/')
        return true;
    else
        return false;
}

bool isHigh(char ch){
    
    if(ch == '*' && stk.top() == '+')
        return true;
    else if(ch == '*' && stk.top() == '-')
        return true;
    else if(ch == '/' && stk.top() == '+')
        return true;
    else if(ch == '/' && stk.top() == '-')
        return true;
    else
        return false;
}

void inExp2PostExp(string str){
    
    for(int i = 0; i < str.size(); i++){
        if(str[i] == '('){//如果是左括号我们就忽略
            stk.push('(');
        }
        else if(isNumber(str[i])){//如果是数字我们就将这个数字打印出来
            int tmp = 0;
            while (isNumber(str[i])) {
                tmp = tmp*10 + returnNumber(str[i]);
                i++;
            }
            i--;
            cout<<tmp<<" ";
        }
        //如果是字符 并且栈中为空时（栈中为左括号时） 进栈
        else if((isChar(str[i]) && stk.empty()) || (isChar(str[i]) && stk.top() == '(')){
            stk.push(str[i]);
        }
        //如果是字符 且优先级高于栈中元素时 进栈
        else if(isChar(str[i]) && isHigh(str[i])){
            stk.push(str[i]);
        }
        //如果是字符 但是优先级不比栈中元素高时  将栈中元素出栈 继续比较当前字符
        else if(isChar(str[i]) && !isHigh(str[i])){
            auto n = stk.top();
            cout<<n<<" ";
            stk.pop();
            i--;//继续比较当前元素
        }
        //如果是右括号时 我们就进行弹栈操作
        else if(str[i] == ')'&& stk.top() != '('){
            //如果当前元素为元素为）且栈中不为空 那么我们就进行弹栈操作
            cout<<stk.top()<<" ";
            stk.pop();//栈顶元素出栈
            i--;
        }
        else if(str[i] == ')' && stk.top() == '('){
            stk.pop();//此时我们将左括号弹栈
        }
        
    }
    
    while (!stk.empty()) {
        if(stk.top() != '('){
            cout<<stk.top()<<" ";
        }
        stk.pop();
    }
    
    
}

int calcPostExp(string s){
    
    for(int i = 0; i < s.size(); i++){
        if(isNumber(s[i])){
            int tmp = 0;
            while (isNumber(s[i])) {
                tmp = tmp * 10 + returnNumber(s[i]);
                i++;
            }
            num.push(tmp);
            i--;
        }
        
        if(isChar(s[i])){
            int num2 = num.top();
            num.pop();
            int num1 = num.top();
            num.pop();
            int res;
            switch (s[i]) {
                case '+':
                    res = num1 + num2;
                    break;
                case '-':
                    res = num1 - num2;
                    break;
                case '*':
                    res = num2 * num1;
                    break;
                case '/':
                    res = num1 / num2;
                    break;
                default:
                    break;
            }
            num.push(res);
        }
        
    }
    cout<<num.top()<<endl;
    return num.top();
    
}

int main(int argc, const char * argv[]) {
   
    string str;
    getline(cin,str);
    inExp2PostExp(str);
    cout<<endl;
    cout<<"Please enter your postExpre: "<<endl;

    string post;
    getline(cin, post);
    calcPostExp(post);
    return 0;
}

