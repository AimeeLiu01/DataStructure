//
//  calcExpress.cpp
//  905_02
//
//  Created by 刘畅 on 2017/9/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include <stack>
using namespace std;

stack<char> stk;
stack<int> num;

bool isNumber(char s){
    
    if(s >= '0' && s <= '9'){
        return true;
    }
    else
        return false;
}

int returnNumber(char s){
    int tmp = s-'0';
    return tmp;
}

bool isChar(char s){
    if(s == '+' || s == '-' || s == '*' || s == '/')
        return true;
    else
        return false;
}

bool isHigh(char ch){
    
    if(ch == '*' && stk.top() == '+')
        return true;
    else if(ch == '*' && stk.top() == '-')
        return true;
    else if(ch == '/' && stk.top() == '+')
        return true;
    else if(ch == '/' && stk.top() == '-')
        return true;
    else
        return false;
}

void calc(){
    auto n = stk.top();
    stk.pop();
    int number1 = num.top();
    num.pop();
    int number2 = num.top();
    num.pop();
    int tmp;
    switch (n) {
        case '+':
            tmp = number1 + number2;
            break;
        case '-':
            tmp = number2 - number1;
            break;
        case '*':
            tmp = number1 * number2;
            break;
        case '/':
            tmp = number2 / number1;
            break;
            
        default:
            break;
    }
    num.push(tmp);
}


int calcExpress(string s){
    
    for (int i = 0; i < s.size(); i++) {
        if(s[i] == '('){
            stk.push(s[i]);
        }
        else if(isNumber(s[i])){
            int tmp = 0;
            while (isNumber(s[i])) {
                tmp = tmp * 10 + returnNumber(s[i]);
                i++;
            }
            num.push(tmp);
            i--;
        }
        else if((isChar(s[i]) && stk.empty()) || (isChar(s[i]) && stk.top() == '(')){
            stk.push(s[i]);
        }
        
        else if(isChar(s[i]) && isHigh(s[i])){
            stk.push(s[i]);
        }
        
        else if(isChar(s[i]) && !isHigh(s[i])){
            calc();
            i--;
        }
        else if(s[i] == ')' && stk.top() != '('){
            calc();
            i--;
        }
        else if(s[i] == ')' && stk.top() == '('){
            stk.pop();
        }
    }
    
    while (!stk.empty()) {
        if(stk.top() != '('){
          calc();
        }
    }
    cout<<num.top()<<endl;
    return num.top();
    
}



int main(){
    
    
    string s;
    getline(cin,s);
    calcExpress(s);
    return 0;
    
    
}
