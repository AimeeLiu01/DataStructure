//
//  main.cpp
//  test12

////作用：将输入到控制台的字符流串转化为单词输出

//  Created by 刘畅 on 2017/6/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <sstream>
#include <string>

using namespace std;

int main(int argc, const char * argv[]) {
    
    istringstream istr;
    string line, str;
    while(getline(cin,line)){
        istr.str(line);
        while (istr >> str) {
            cout<<str<<endl;
        }
    }
    return 0;
}
