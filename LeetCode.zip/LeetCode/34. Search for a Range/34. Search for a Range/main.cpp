//
//  main.cpp
//  34. Search for a Range
//
//  Created by 刘畅 on 2017/6/14.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    vector<int> searchRange(vector<int>& nums, int target) {
        
        
        int start = INT_MIN, end = INT_MIN;
        vector<int> res;
        if(nums.size() == 0){
            res.push_back(-1);
            res.push_back(-1);
            return res;
        }
        
        for(int i = 0; i < nums.size(); i++){
            if(nums[i] == target){
                start = i;
                break;
            }
            else{
                continue;
            }
        }
        
        if(start >= 0){
            end = start;
            
            for(int i = start+1; i < nums.size()-1; i++){
                if(nums[i] == target){
                    ++end;
                }
            }
        }
        else{
            start = -1;
            end = -1;
        }
        
        res.push_back(start);
        res.push_back(end);
        
        
        for(int i = 0; i < res.size(); i++){
            cout<<res[i]<<" ";
        }
        return res;
        
        
    }
};

int main(int argc, const char * argv[]) {
    vector<int> vec;
    vec.push_back(1);
    Solution s = *new Solution();
    s.searchRange(vec, 1);
   
    return 0;
}
