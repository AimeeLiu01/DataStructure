//
//  二叉树遍历.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

struct TreeNode{
    char val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(char x){
        val = x;
        left = nullptr;
        right = nullptr;
    }
};

int i = 0;
TreeNode* createTree(string str){
    
    char c = str[i++];
    if(c == '#')
        return NULL;
    TreeNode *root = new TreeNode(c);
    root->left = createTree(str);
    root->right = createTree(str);
    return root;
   
   
}

void InorderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    InorderTraversal(root->left);
    cout<<root->val<<" ";
    InorderTraversal(root->right);
}

int main(){
    
    string str;
    getline(cin,str);
    int size = (int)str.size();
    TreeNode *root = createTree(str);
    InorderTraversal(root);
    return 0;
}
*/
