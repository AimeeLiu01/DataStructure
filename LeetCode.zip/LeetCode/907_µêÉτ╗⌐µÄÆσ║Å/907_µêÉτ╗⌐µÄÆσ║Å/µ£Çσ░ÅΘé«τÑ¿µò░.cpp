//
//  最小邮票数.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
/*
 状态迁移方程
 dp[j] = min{dp[j],dp[j-stamp[i]]+1}
 其中dp[j-stamp[i]]+1，表示将第i个邮票加入集合后 凑总量为j的面额 所需要的最少邮票数量
 */

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

#define MAXN 110
#define MAXM 99999
int stamp[MAXN], dp[MAXM];

void init(){
    for (int i = 0; i < MAXN; i++) {
        dp[i] = MAXM;
    }
}

int main(){
    
    int m,n;
    while (cin>>m>>n) {
        init();
        for (int i = 0; i < n; i++) {
            cin>>stamp[i];
        }
        
        dp[0] = 0;
        for (int i = 0; i < n; i++) {
            for (int j = m; j >= stamp[i]; j--) {
                dp[j] = min(dp[j], dp[j-stamp[i]] + 1);
            }
        }
        
        cout<<(dp[m] == MAXM ? 0 : dp[m])<<endl;
    }
    
    
}
