//
//  main.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <iostream>
#include <queue>
using namespace std;

struct ListNode{
    string name;
    int count;
    ListNode *next;
    ListNode(string ch, int x){
        name = ch;
        count = x;
        next = nullptr;
    }
};

ListNode* createListNode(int n){
    
    
    ListNode *head = new ListNode("", 0);
    

    for (int i = 1; i <= n; i++) {
        
       
        string str;
        int score;
        cin>>str>>score;
        ListNode *tmp = new ListNode(str, score);
        
        ListNode *p = head->next;
        ListNode *pre = head;
        
        while (p) {
            if(p->count > tmp->count){
                break;
            }
            pre = p;
            p = p->next;
        }
        
        tmp->next = pre->next;
        pre->next = tmp;
        
    }
    return head;
    
}

void sortPrint1(ListNode *res){
    
        ListNode *p = res->next;
        while (p) {
            cout<<p->name<<" "<<p->count<<endl;
            p = p->next;
        }
}

void sortPrint0(ListNode *head){
    
    ListNode *pre = nullptr;
    ListNode *cur = head->next;
    ListNode *p = cur;
    
    while (p) {
        p = p->next;
       
        cur->next = pre;
        pre = cur;
        cur = p;
    }
    head->next = pre;
    sortPrint1(head);
    
}
int main(int argc, const char * argv[]) {
    
    
   
    int n;
    int choose;
    while(cin>>n>>choose){
        ListNode *res = createListNode(n);
        if(choose == 1)
            sortPrint1(res);
        if (choose == 0) {
            sortPrint0(res);
        }
    }
    
    return 0;
    
   
    
    
}
*/
    
