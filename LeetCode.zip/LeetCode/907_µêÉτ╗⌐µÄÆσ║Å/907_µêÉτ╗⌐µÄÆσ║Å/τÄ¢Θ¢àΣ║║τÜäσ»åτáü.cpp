//
//  玛雅人的密码.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*
 输入包含多组测试数据，每组测试数据由两行组成。
 第一行为一个整数N，代表字符串的长度（2<=N<=13）。
 第二行为一个仅由0、1、2组成的，长度为N的字符串。
 输出描述:
 对于每组测试数据，若可以解出密码，输出最少的移位次数；否则输出-1。
 */
/*#include <stdio.h>
#include <string>
#include <queue>
#include <map>
#include <iostream>
using namespace std;


int n;

bool judge(string s){
    int len = s.size();
    for (int i = 0; i < len-3; i++) {
        if(s[i] == '2' && s[i+1] == '0' && s[i+2] == '1' && s[i+3] == '2')
            return true;
    }
    return false;
}

int bfs(string s){
    
    map<string, int> mp;//如果遍历过 将second标记为1
    mp.clear();//清空上一次的缓存
    queue<pair<string, int>> que;//用队列来保存搜索的路径
    que.push(make_pair(s, 0));//将第一个string入队列
    
    while (!que.empty()) {
        
        auto now = que.front();
        que.pop();
        string str = now.first;
        cout<<str<<endl;
        if(judge(str))
            return now.second;
        
        if(mp[str])//如果该队列已经judge过 则跳到下一个队列去
            continue;
        
        mp[str] = 1;//如果没有就标记为已遍历
        
        for (int i = 0; i < n-1; i++) {
            swap(str[i], str[i+1]);
            que.push(make_pair(str, now.second+1));
            swap(str[i], str[i+1]);
        }
    }
    
    
    return -1;
   
    
}

int main(){
    
    
    string s;
    while (cin>>n) {
        cin>>s;
        cout<<bfs(s)<<endl;
    }
    return 0;
    
}*/
