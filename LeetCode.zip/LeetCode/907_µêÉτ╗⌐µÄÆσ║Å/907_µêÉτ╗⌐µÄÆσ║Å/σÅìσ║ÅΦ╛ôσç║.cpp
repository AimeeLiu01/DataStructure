//
//  反序输出.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

void reverseStr(char temp[], int n){
    
    for (int i = n-2; i >= 0; i--) {
        cout<<temp[i];
    }
    cout<<endl;
    
}
int main(){

    char temp[5];
    while (cin.getline(temp, 5)) {
        reverseStr(temp,5);
    }
    return 0;
    
}*/
