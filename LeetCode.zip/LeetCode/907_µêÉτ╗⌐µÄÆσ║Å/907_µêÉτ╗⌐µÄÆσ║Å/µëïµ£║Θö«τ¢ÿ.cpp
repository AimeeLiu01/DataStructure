//
//  手机键盘.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;



int main(){
    
    char temp[100];
    while (cin.getline(temp, 100)) {
        int num = 0;
        for (int i = 0; temp[i] != '\0'; i++) {
            num += (temp[i]-'a'+1)%3;
        }
        cout<<num<<endl;
    }  
    return 0;
}
