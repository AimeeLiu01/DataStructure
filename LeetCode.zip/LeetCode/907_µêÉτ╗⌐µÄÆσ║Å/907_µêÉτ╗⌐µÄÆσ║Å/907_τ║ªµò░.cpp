//
//  907_约数.cpp
//  907_成绩排序
//
//  Created by 刘畅 on 2017/9/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include<iostream>
using namespace std;


int main2(){
    int n;
    cin>>n;
    int temp[n];
    for(int i = 1; i <= n; i++){
        cin>>temp[i];
    }
    
    for(int i = 1; i <= n; i++){
        if(temp[i] == 0)
            break;
        int count = 0;
        for(int j = 1; j <= temp[i]; j++){
            if(temp[i] % j == 0){
                count++;
            }
        }
        cout<<count<<endl;
        
    }
    
    return 0;
}
