//
//  main.cpp
//  906_Graph_Island
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//  求小岛的数量

#include <iostream>
#include <stack>
using namespace std;

int dirX[4] = {1,0,-1,0};
int dirY[4] = {0,1,0,-1};


int main1(int argc, const char * argv[]) {
   
    int x,y;
    cin>>x>>y;
    int **island = new int*[x];
    for (int i = 0; i < x; i++) {
        island[i] = new int[y];
        for(int j = 0; j < y; j++){
            cin>>island[i][j];
        }
    }
    
    bool **visited = new bool*[x];
    for (int i = 0; i < x; i++) {
        visited[i] = new bool[y];
        for (int j = 0; j < y; j++) {
            visited[i][j] = false;
        }
        
    }
    
    stack<pair<int, int>> stk;
    
    int count = 0;
    for (int i = 0; i < x; i++) {
        for (int j = 0; j < y; j++) {
            
            if(island[i][j] == 1 && visited[i][j] == false){
                stk.push(make_pair(i, j));
                count++;
                while (!stk.empty()) {
                    auto n = stk.top();
                    stk.pop();
                    int x1 = n.first;
                    int y1 = n.second;
                    for (int k = 0; k < 4; k++) {
                        int xx = x1 + dirX[k];
                        int yy = y1 + dirY[k];
                        //临界判断很重要 不能忽视
                        if(xx < 0 || yy < 0 || xx >= x || yy >= y)
                            continue;
                        if(island[xx][yy] == 1 && visited[xx][yy] == false){
                            stk.push(make_pair(xx, yy));
                            visited[xx][yy] = true;
                        }
                    }
                }
            }
        }
    }
    
    
    cout<<"There are "<<count<<" island."<<endl;
    return count;
    
    
}
