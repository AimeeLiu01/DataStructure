//
//  01.cpp
//  906_Graph_Island
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include <stack>
using namespace std;

int dirX[4] = {1,0,-1,0};
int dirY[4] = {0,1,0,-1};

int main(){
    
    int height, weight;
    cin>>height>>weight;
    
    int **islands = new int*[height];
    for (int i = 0; i < height; i++) {
        islands[i] = new int[weight];
        for(int j = 0; j < weight; j++){
            cin>>islands[i][j];
            
        }
    }
    
    int **ans = new int*[height];
    for (int i = 0; i < height; i++) {
        ans[i] = new int[weight];
        for(int j = 0; j < weight; j++){
            ans[i][j] = 999;
            
        }
    }
    
    stack<pair<int, int>> stk;
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < weight; j++) {
            if(islands[i][j] == 0){
                stk.push(make_pair(i, j));
                ans[i][j] = 0;
            }
        }
    }
    
    //此题 用队列或者栈都可以
    while (!stk.empty()) {
        auto n = stk.top();
        stk.pop();
        int x = n.first;
        int y = n.second;
        for(int k = 0; k < 4; k++){
            int xx = x + dirX[k];
            int yy = y + dirY[k];
            if(xx < 0 || yy < 0 || xx >= height || yy >= weight){
                continue;
            }
            else{
                if(ans[xx][yy] > ans[x][y] + 1){
                    ans[xx][yy] = ans[x][y] + 1;
                    stk.push(make_pair(xx, yy));
                }
            }
        }
    }
    
    for(int i = 0; i < height; i++){
        for (int j = 0; j < weight; j++) {
            cout<<ans[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
    
}
