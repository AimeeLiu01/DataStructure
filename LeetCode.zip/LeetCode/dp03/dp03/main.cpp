//
//  main.cpp
//  dp03
//
//  Created by 刘畅 on 2017/5/14.
//  Copyright © 2017年 刘畅. All rights reserved.
/*
 案例3：
 给定数组arr，返回arr的最长递增子序列的长度，比如arr=[2,1,5,3,6,4,8,9,7]，最长递增子序列为[1,3,4,8,9]返回其长度为5.
 */
/*
 分析：
 首先生成dp[n]的数组，dp[i]表示以必须arr[i]这个数结束的情况下产生的最大递增子序列的长度。对于第一个数来说，很明显dp[0]为1，当我们计算dp[i]的时候，我们去考察i位置之前的所有位置，找到i位置之前的最大的dp值，记为dp[j](0=<j<i),dp[j]代表以arr[j]结尾的最长递增序列，而dp[j]又是之前计算过的最大的那个值，我们在来判断arr[i]是否大于arr[j],如果大于dp[i]=dp[j]+1.计算完dp之后，我们找出dp中的最大值，即为这个串的最长递增序列。
 */

#include <iostream>
#include <algorithm>
using namespace std;
int dp[5] = {};

int main(int argc, const char * argv[]) {
    
    int arr[6] = {2,4,5,3,1,6};
    dp[0] = 1;//
    const int oo = 0;//
    
    for(int i = 0; i < 6; i++){
        int max = oo;
        for(int j = 0; j < i; j++){
            
            if(dp[j] > max && arr[i] > arr[j])
                max = dp[j];
            
            dp[i] = max + 1;
        }
    }
    
    /*
     第一次循环时 dp[0] = 1, 
                i == 1 时，dp[j] == dp[1] > 0 && arr[1] > arr[0]        max = dp[0] = 1;   dp[1] = 2;
     
                i == 2 时，dp[0] > 0 && arr[2] > arr[0]      max = dp[0] = 1;    dp[2] = 1 + 1 = 2;
                           dp[1] > 0 && arr[2] > arr[1]      max = dp[1] = 2;    dp[2] = 2 + 1 = 3;
     
                i == 3时，dp[0] > 0 && arr[3] > arr[0]     max = dp[0] = 1; dp[3] = 1 + 1 = 2;
                
                i == 4时，dp[0] > 0 && arr[4] < arr[0]     dp[4] = 0 + 1 = 1
    */
    
    int maxlist = 0;
    
    for(int i = 0; i < 6; i++){
        
        if(dp[i] > maxlist)
            
            maxlist = dp[i];
    }
    
    cout<< maxlist << endl;//找到最大的数值
    
    return 0;
}











