//
//  math2.cpp
//  Math
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//  给定一个矩阵M，从左上角到右下角只能向右走或者向下走  求路径中所有数字累加起来的路径和 返回所有路径的最小路径和

/*#include <stdio.h>
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int dp[4][4] = {};



int main(){
    int arr[4][4] = {1,3,5,9,8,1,3,4,5,0,6,1,8,8,4,0};
    const int MAX = INT_MAX;
    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++) {
            dp[i][j] = MAX;
        }
    }
    
    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++) {
            if(dp[i][j] == MAX){
                if(i == 0 && j == 0){
                    dp[i][j] = arr[i][j];
                }
                else if(i == 0 && j != 0){
                    dp[i][j] = dp[i][j-1] + arr[i][j];
                }
                else if(i != 0 && j == 0){
                    dp[i][j] = dp[i-1][j] + arr[i][j];
                }
                else{
                    dp[i][j] = min(dp[i-1][j] , dp[i][j-1]) + arr[i][j];
                }
            }
        }
    }
    
    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++) {
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
    
}*/


