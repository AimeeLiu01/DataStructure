//
//  math3.cpp
//  Math
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//  求一个数组的最大递增的数组长度

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

int dp[5] = {};//生成动态规划表

int main(){
    
    int arr[5] = {2,4,5,3,1};
    dp[0] = 1;
    const int MAX = 0;
    for(int i = 1; i < 5; i++){
        int max = MAX;
        for(int j = 0; j < i; j++){
            if(dp[j] > MAX && arr[j] < arr[i])
                max = dp[j];
        }
        dp[i] = max + 1;
    }
    for(int i = 0; i < 5; i++){
        cout<<dp[i]<<" ";
    }
    cout<<endl;
    
    int maxlist = 0;
    for (int i = 0; i < 5; i++) {
        if(dp[i] > maxlist)
            maxlist = dp[i];
    }
    cout<<maxlist<<endl;
    return 0;
    
    
    
    
}*/


