//
//  main.cpp
//  Math
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//

/*#include <iostream>
#include <string>
using namespace std;

//有0级台阶、一个人每次上一级活着两级、问有多少种方法走完n个台阶
int func(int n){
    
    int dp[100] = {0};
    if(n == 1 || n ==2){
        return n;
    }
    if(!dp[n-1])
        dp[n-1] = func(n-1);
    if(!dp[n-2])
        dp[n-2] = func(n-2);
    
    return dp[n-1] + dp[n-2];
    
}

int main(int argc, const char * argv[]) {
   
    int n = 10;
    cout<<"There are 10 Taijie~"<<endl;
    int res = func(n);
    cout<<res<<endl;
    return 0;
}*/
