//
//  math4.cpp
//  Math
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//  计算2个字符串的最长公共子序列

/*#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;


int findLCS(string A, int m, string B, int n){
   
    int dp[500][500] = {0};
    
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if(A[i] == B[j])
                dp[i+1][j+1] = dp[i][j] + 1;
            else
                dp[i+1][j+1] = max(dp[i+1][j], dp[i][j+1]);
        }
    }
    
    return dp[m][n];
    
}


int main(){
    
    string A = "ABCSSER";
    string B = "ACDER";
    int res = findLCS(A, 7, B, 5);
    
    cout<<res<<endl;
    return 0;
    
    
}*/
