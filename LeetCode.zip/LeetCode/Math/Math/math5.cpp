//
//  math5.cpp
//  Math
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//  动态规划问题  问一个背包承重W 有N件物品  每件物品有自己的价值  记在数组V中
//  也有自己的重量 记在数组W中
//  假设数组dp[x][y]表示的是前x件、不超过重量y的时候的最大价值
//

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;


int main(){
    
    int n = 4;//代表物品的数量
    int cap = 10;//代表背包承重
    int v[4] = {42,32,40,25};//代表的是每个物品的价值
    int w[4] = {7,3,4,5};//代表每个物品的重量
    int dp[n+1][cap+1];//代表的是前x件物品、不超过重量y的时候的最大价值
    
    for (int i = 1; i <= n; i++) {
        
        for (int j = 1; j <= cap; j++) {
            
            if(j- w[i-1] >= 0)//说明可以选择当前的物品
                dp[i][j] = max(dp[i-1][j], dp[i-1][j-w[i-1]] + v[i-1]);
            else
                dp[i][j] = dp[i-1][j];
        
        }
    }
    
    cout<<dp[n][cap]<<endl;
    return 0;
    
    
}
