//
//  main.cpp
//  PKU-01
//
//  Created by 刘畅 on 2017/7/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

int main(int argc, const char * argv[]) {
    
    char a[20];
    cin.get(a,20);
    int size = sizeof(a)/2;
    
    cout<<a<<endl;
    return 0;
}
