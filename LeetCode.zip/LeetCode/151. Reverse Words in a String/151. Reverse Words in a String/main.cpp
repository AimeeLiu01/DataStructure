//
//  main.cpp
//  151. Reverse Words in a String
//
//  Created by 刘畅 on 2017/6/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//
#include <iostream>
#include <sstream>
#include <istream>
#include <string>
using namespace std;

int main(){
    

        string s = "The sky is blue";
        istringstream is(s);
        s.clear();
        string tem;
        while(is >> tem)
            s = tem + " " + s;
        s = s.substr(0, s.size()-1);//因为尾部多了一个空格
        cout<<s<<endl;
    
    
}