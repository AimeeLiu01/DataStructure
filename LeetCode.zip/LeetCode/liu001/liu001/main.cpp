//
//  main.cpp
//  liu001
//
//  Created by 刘畅 on 2017/5/2.
//  Copyright © 2017年 刘畅. All rights reserved.
//
//进制转化   利用栈
#include <iostream>
#include <stack>
using namespace std;

void invert(stack<char> &s, int64_t num, int n){
    
    static char digit[18] = {'0','1','2','3','4','5','6','7','8','9','A','B',
        'C','D','E','F','G'};
    
    while(num > 0){
        s.push(digit[num%n]);
        num = num / n;
    }
    
    
    
}

int main(int argc, const char * argv[]) {
    
    
    stack<char>  mystack;
    invert(mystack, 98, 2);
    
    while(!mystack.empty()){
        
        char tmp = mystack.top();
        mystack.pop();
        cout<<tmp<<endl;
        
    }
    return 0;
    
}

