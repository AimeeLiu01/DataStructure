//
//  main.cpp
//  1003.
//
//  Created by 刘畅 on 2017/7/7.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    float c,temp, a;
    while (cin>>c, c != 0.00) {
        temp = 0;
        a = 2;
        while (temp < c) {
            temp = temp + 1 / a;
            a ++;
        }
        cout<<a-2<<" card(s)"<<endl;
    }
    return 0;
}
