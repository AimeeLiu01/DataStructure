//
//  main.cpp
//  String2Tree
//
//  Created by 刘畅 on 2017/8/12.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*
 1. 遍历字符串s，用变量j记录当前位置i，然后看当前遍历到的字符是什么.
 2. 如果遇到的是左括号，什么也不做继续遍历；
 3. 如果遇到的是数字或者负号，那么我们将连续的数字都找出来，然后转为整型并新建结点;
 4. 此时我们看stack中是否有结点，如果有的话，当前结点就是栈顶结点的子结点，如果栈顶结点没有左子结点，那么此结点就是其左子结点，反之则为其右子结点。
 5. 之后要将此结点压入栈中。如果我们遍历到的是右括号，说明栈顶元素的子结点已经处理完了，将其移除栈
 */

#include <iostream>
#include <stack>
#include <queue>
#include <map>
#include <cstdlib>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x)
    :val(x),left(NULL),right(NULL){}
};

TreeNode * str2tree(string s){
    
    if (s.empty())  return NULL;

    stack<TreeNode *> stack;
    for(int i = 0 ; i < s.size(); i++){
        int j = i;//j是用来标记当前位置的 看当前遍历到的元素是什么
        
        if(s[i] == ')')//如果是右扩号 就弹栈 表示当前元素不能再做根结点
            stack.pop();
        
        else if((s[i] >= '0' && s[i] <= '9') || s[i] == '-'){//遍历到数字的时候，将连续的数字都找出来
            
            while (i+1 < s.size() && s[i+1] >= '0' && s[i+1] <= '9')  i++;
            TreeNode *cur = new TreeNode(stoi(s.substr(j,i-j+1)));//找到这个值并将其转化为结点
            
            if(!stack.empty()){

                TreeNode *p = stack.top();
                //如果栈顶结点没有左子结点，那么此结点就是其左子结点，反之则为其右子结点。
                if(!p->left)
                    p->left = cur;
                else
                    p->right = cur;
            }
            stack.push(cur);
            
        }
    }
    
    return stack.top();
}



void InOrderTraversal(TreeNode *root){
    
    if(root == NULL) return;
    InOrderTraversal(root->left);
    cout<<root->val<<" ";
    InOrderTraversal(root->right);
}


void PreOrderTraversal(TreeNode * root){
    
    if(root == NULL) return;
    cout<<root->val<<" ";
    PreOrderTraversal(root->left);
    PreOrderTraversal(root->right);
}

void FindAllOfNums(string str){
    
    
    for(int i = 0; i < str.size(); i++){
        int j = i;//标记当前元素
        
        if(str[i] >= '0' && str[i] <= '9'){
            
            while (i+1 < str.size() && str[i+1] >= '0' && str[i+1] <= '9') i++;

            int tempNum = stoi(str.substr(j,i-j+1));
            cout<<tempNum<<" ";
            
        }
    }
    
}

TreeNode* myStr2Tree(string s){
    
    
    //现在自己来尝试写一遍
    /*思路如下：利用栈 对当前的字符串进行遍历  
     1.如果是左括号 我们忽略
     2.如果是右括号，我们弹栈操作
     3.如果是数字，我们找到连续是数字的部分，将其提取出来，并将其转化为当前的结点
     4.如果当前栈中元素不为空，则当前结点为栈顶结点的子结点，进行处理
     5.将当前结点入栈
    */
    if(s.empty()) return NULL;
    
    stack<TreeNode *> stack;
    TreeNode * p;
    
    
    for(int i = 0; i < s.size(); i++){
        
        int j = i;
        if(s[i] == ')')
            stack.pop();
        else if((s[i] >= '0' && s[i] <= '9')|| s[i] == '-'){
            while (i+1 < s.size() && s[i+1] >= '0' && s[i+1] <= '9') {
                i++;
            }
            TreeNode * cur = new TreeNode(stoi(s.substr(j,i-j+1)));//找到了当前的结点
            if(!stack.empty()){
                p = stack.top();
                if(!p->left)
                    p->left = cur;
                else
                    p->right = cur;
            }
            stack.push(cur);
        }
        
    }
    
    return stack.top();
  
}


int main(int argc, const char * argv[]) {
    
    string s = "4(23(3)(1))(6(51))";
    
    cout<<"字符串中的数字分别为："<<endl;
    FindAllOfNums(s);
    cout<<endl;
    
    TreeNode *root = str2tree(s);
    cout<<"中序遍历的结果为："<<endl;
    InOrderTraversal(root);
    cout<<endl;
    
    cout<<"前序遍历的结果为："<<endl;
    PreOrderTraversal(root);
    cout<<endl;
    
    cout<<"**********下面验证自己写的函数：***********"<<endl;
    
  
    
    TreeNode *myroot = myStr2Tree(s);
    
    cout<<"中序遍历的结果为："<<endl;
    InOrderTraversal(myroot);
    cout<<endl;
    cout<<"前序遍历的结果为："<<endl;
    PreOrderTraversal(myroot);
    cout<<endl;
    
    return 0;
    
    
    
    
    
    
    
    
    
    
    
    
    
}
