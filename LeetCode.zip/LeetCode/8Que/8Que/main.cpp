//
//  main.cpp
//  8Que
//
//  Created by 刘畅 on 2017/9/1.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

const int N = 8;
int position[N];
int count = 0;

