//
//  main.cpp
//  82. Remove Duplicates from Sorted List II
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;


//题意：在一个链表中， 去除有重复的元素，只留下只出现了一次的元素
//解题思路：
/*
 递归法：头指针head 和  p指针两个指针
 如果p->val == head->val  证明这个head值不能留  我们将p指向不等于这个值的地方   返回这个函数的递归
 如果p->val != head->val  证明head的值不重复  我们直接将head->next 指向函数的递归
 */

/*
 非递归法：利用三个指针   pre  cur post 联合去除有重复的指针
 */

struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};

class Solution{
public:
    ListNode* deleteDuplicates(ListNode* head) {
        if(!head) return NULL;
        if(!head->next) return head;
        
        int val = head->val;
        ListNode *p = head->next;
        
        if(p->val != val){//如果p的值和head的值不一样  我们就让head指向deleteDuplicates(p)
            head->next = deleteDuplicates(p);
            return head;
        }
        else{
            while (p && p->val == val) {//如果p的值和head的值一样 这个时候我们就找到不一样的那个值
                p = p->next;
            }
            return deleteDuplicates(p);//直接返回deleteDuplicates(p)
        }
    }
};

class Solution1{
public:
    ListNode *deleteDuplicates1(ListNode *head){
        if(!head || !head->next) return head;
        
        ListNode *dummy = new ListNode(-1);
        ListNode *pre = dummy;
        ListNode *cur = head;
        ListNode *post = head->next;
        pre->next = head;
        
        while (post != NULL) {
            //第一种情况：post的值和pre的值相同 那么将post向后移动  直至值不同
             if(post->val == cur->val){
                 post = post->next;
            }
             else if (post != cur->next){//第二种情况：此时的post已经向后移动了位置  证明当前的值有重复
                 pre->next = post;
                 cur = post;
                 post = post->next;
             }
             else{
                //第三种情况：post的值和cur不相同 且位置不紧邻  此时移动三个指针
                 pre = pre->next;
                 cur = cur->next;
                 post = post->next;
                 
             }
        }
        
        if (cur->next != NULL) {//最后一个元素为重复的时候
            pre->next = NULL;
        }
        
        return dummy->next;
    }
};



int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(3);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    
    //用第一种递归的方法测试
    Solution s = *new Solution();
    ListNode *res;
    res = s.deleteDuplicates(node1);
    
    while (res) {
        cout<<res->val<<" ";
        res = res->next;
    }
    cout<<endl;
    cout<<" ----------------------------"<<endl;
    
    //用第二种非递归的方法测试
    Solution1 s1 = *new Solution1();
    ListNode *res1;
    res1 = s1.deleteDuplicates1(node1);
    while (res1) {
        cout<<res1->val<<" ";
        res1 = res1->next;
    }
    
    return 0;
}







