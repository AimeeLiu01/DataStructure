//
//  main.cpp
//  MaxHeap
//
//  Created by 刘畅 on 2017/8/16.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

template<class Type>
class MaxHeap{
    
public:
    
    MaxHeap(int sz = 10);
    bool isFull();//判断堆是否满了
    bool isEmpty(); //判断堆是否为空 若堆中元素个数为0 返回true 否则返回false
    void Insert(Type x);
    Type* Delete();//如果堆为空，返回0，否则将最大元素放入x，并从堆中删除它，返回x的指针
private:
    Type *heap;//因为最大堆为一棵完全二叉树，因此可以用数组来实现
    int n;//最大堆的当前元素个数
    int MaxSize;//堆中可以容纳的元素的最大个数
    

};


template<class Type>
MaxHeap<Type>::MaxHeap(int sz){
    
    heap = new Type[sz+1];
    n = 0;
    MaxSize = sz;
    
}

template<class Type>
bool MaxHeap<Type>::isFull(){
    
    if(n == MaxSize)
        return true;
    else
        return false;
}

template<class Type>
bool MaxHeap<Type>::isEmpty(){
    if(n == 0)
        return true;
    else
        return false;
}

template<class Type>
void MaxHeap<Type>::Insert(Type x){
    
    if(isFull()){
        cout<<"Heap is Full. Can't insert. "<<endl;
    }
    n++;//这里表示结点已经+1
    
    int i;
    for(i = n; i > 1; ){
        
        if(x <= heap[i/2]) break;//如果要插入的结点值比父节点要小 直接跳出循环 将x放到i处
        
        heap[i] = heap[i/2];//如果要插入的结点值比较大，heap[i]没有被占用，此时我们将双亲结点移到结点i中
        i /= 2; //i继续向上
    }
    heap[i] = x;//直到合适的位置时，将x放入
    cout<<"We have insert "<< x << " into the maxHeap!"<<endl;
    
}


template<class Type>
Type* MaxHeap<Type>::Delete(){//从最大堆中删除元素
    
    if(isEmpty())
        return 0;
    
    Type x = heap[1];//代表的是根元素
    Type k = heap[n];//代表最后一个元素
    
    n--;//删除一个结点
    int i,j;//j为i的子女
    
    for(i = 1, j = 2; j <= n;){
        
        if(j < n){
           if(heap[j] < heap[j+1]) j++;//找到子女中的较大者
        }
        if(k >= heap[j]) break; //如果k比最大者还要大，我们跳出循环 直接将k置放到父节点（i的位置）
       
        heap[i] = heap[j];//否则的话，我们让子结点中的较大者当父节点
        i = j;
        j *= 2;//i继续向下  这里我们的根结点是a[1] 因此子女结点这样表示
        
    }
    heap[i] = k;//直到找到k可以放置的位置，将其放下
    cout<<"We have delete "<< x << " successfully~~~"<<endl;
    return &x;//返回根结点的地址
}




int main(int argc, const char * argv[]) {
    
    
    
    
    
    
    MaxHeap<int> mp;
    // int a[11] = {-11,5,2,12,3,55,21,7,9,11,9};
    
    if(mp.isEmpty())
        cout<<"The heap is empty~"<<endl;
    mp.Insert(5);
    mp.Insert(7);
    mp.Delete();
    mp.Delete();
    
    
    if(!mp.isEmpty()){
        cout<<"The heap is not empty now~~~!"<<endl;
    }
    else
        cout<<"The heap is empty now~~~!"<<endl;
    
 
    
    
    
    return 0;
    
    
}
