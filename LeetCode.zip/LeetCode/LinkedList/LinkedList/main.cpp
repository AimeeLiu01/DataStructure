//
//  main.cpp
//  LinkedList
//
//  Created by 刘畅 on 2017/5/16.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

struct LinkedListNode{
    int val;
    LinkedListNode *next;
};

void AddAtHead(LinkedListNode *&head,int data){
    
    LinkedListNode *node = new LinkedListNode;
    node->val = data;
    node->next = head;
    head = node;
}

void AddAtTail(LinkedListNode *head, int data){
    
    if(head == NULL) return;
    LinkedListNode *node = new LinkedListNode;
    node->val = data;
    node->next = NULL;
    
    while (head->next != NULL) {
        head = head->next;
    }
    head->next = node;
}

void BuildLinkedList(LinkedListNode *&head, int a[], int n){
    AddAtHead(head,a[0]);
    for(int i = 1; i < n; i++){
        AddAtHead(head,a[i]);
    }
}

void Traverse(LinkedListNode *head){
    while (head!=NULL) {
        cout<<head->val<<" ";
        head = head->next;
    }
    cout<<"\n";
    
}

int GetSize(LinkedListNode *head){
    int size = 0;
    while (head != NULL) {
        head = head->next;
        size++;
    }
    return size;
}

bool IsEmpty(LinkedListNode *head){
    if(head == NULL)
        return true;
    return false;
}

/*void MakeEmpty(LinkedListNode *&head){
    if(head != NULL)
    {
        MakeEmpty(head->next);
        delete head;
    }
    head = NULL;
}*/

void MakeEmpty(LinkedListNode *&head){
    while(head != NULL){
        LinkedListNode *p = head;
        head = head->next;
        delete p;
        p = NULL;
    }
}

bool Find(LinkedListNode *head, int data){
    while (head !=NULL) {
        if(head->val == data)
            return true;
        head = head->next;
    }
    return false;
}

void Insert(LinkedListNode *&head, int pos, int data){
    
    if(pos < 1) return ;
    
    LinkedListNode *p = head;
    LinkedListNode *node = new LinkedListNode;
    node->val = data;
    node->next = NULL;
    
    if(pos == 1){
        node->next = head;
        head = node;
        return ;
    }
    
    int cnt = 0;
    while (cnt < pos-2 && p!= NULL) {
        p = p->next;
        cnt++;
    }
    
    if(p == NULL)
        return;
    
    node->next = p->next;
    p->next = node;
}

void Remove(LinkedListNode *&head, int pos){
    if(pos < 1 || head == NULL) return;
    LinkedListNode *p = head;
    
    if(pos == 1){
        head = p->next;
        delete p;
        return;
    }
    
    int cnt = 0;
    while (cnt < pos - 2 && p->next != NULL) {
        p = p->next;
        cnt++;
    }
    
    if(p->next == NULL)
        return;
    
    LinkedListNode *tmp = p->next;
    p->next = p->next->next;
    delete tmp;
}




int main(int argc, const char * argv[]) {
   
    
    
    int a[] = {4,2,6,1,3,5,7};
    
    LinkedListNode *head = NULL;
    AddAtHead(head, 0);
    BuildLinkedList(head, a, sizeof(a)/sizeof(a[0]));
    Insert(head,1,8);
    Traverse(head);
    Remove(head,1);
    AddAtHead(head,9);
    Traverse(head);
    MakeEmpty(head);
    
    return 0;
    

    
}
