//
//  main.cpp
//  Pre2Post
//
//  Created by 刘畅 on 2017/8/27.
//  Copyright © 2017年 刘畅. All rights reserved.
/*1.中缀表达式转为后缀表达式
  我们的主要思路是利用一个栈来存储处理符号   遇到数字就直接打印出来   遇到符号（不是右括号）就进栈
  各个符号有一个优先级  优先级低的就进栈  优先级若比栈顶优先级低（或相等） 则弹栈
*/

/*计算后缀表达式的思想
 在一个字符串中 遇到数字就进栈  遇到符号就弹栈（弹出两个数字  然后经过计算后再入栈  最后栈中留下的元素即为结果）
 */

#include <iostream>
#include <stack>
using namespace std;

stack<char> stk;

bool isChar(char ch){
    if(ch == '+' || ch == '-' || ch == '*' || ch == '/'){
        return true;
    }
    else
        return false;
}

bool isNum(char c){
    if(c - '0' >= 0 && c - '0' <= 9){
        return true;
    }
    else
        return false;
}

int returnNum(char s){
    int num = s - '0';
    return num;
}

bool isHigh(char ch){//当前符号的优先级是否高于栈顶符号
    

    if(ch == '*' && stk.top() == '+'){
        return true;
    }
    if(ch == '*' && stk.top() == '-'){
        return true;
    }
    if(ch == '/' && stk.top() == '+'){
        return true;
    }
    if(ch == '/' && stk.top() == '-'){
        return true;
    }
    return false;
 
}

void In2PostExpression(string s){
    
    
   
    for(int i = 0; i < s.size(); i++){
        
       
        if(s[i] == '('){//如果是左括号 我们直接入栈
            stk.push(s[i]);
        }
        
        else if(isNum(s[i])){//如果当前符号为数字
            int tmp = 0;
            while (isNum(s[i])) {
                tmp = tmp * 10 + returnNum(s[i]);
                i++;
            }
            i--;
            cout<<tmp<<" ";//输出数字
          
        }
        
        else if((isChar(s[i]) && stk.empty()) || (isChar(s[i]) && stk.top() == '(')){
            //如果当前元素为运算符 且栈中没有元素(或者为左括号)  我们就直接入栈
            stk.push(s[i]);
        }
        
        else if(isChar(s[i]) && isHigh(s[i])){//如果当前符号为运算符 且当前元素的优先级高于栈顶元素
            stk.push(s[i]);
        }
        else if(isChar(s[i]) && !isHigh(s[i])){//如果当前符号为运算符 且当前元素的优先级不高于栈顶元素 弹栈后再放入
            
            auto n = stk.top();
            cout<<n<<" ";
 
            stk.pop();//先将当前栈顶的元素弹出
            
            i--;//继续当前元素的比较
        }
        
        else if(s[i] == ')' && stk.top() != '('){
            //如果当前元素为右括号 我们将栈顶的元素输出 并让左括号也出栈
            cout<<stk.top()<<" ";
            stk.pop();//将栈顶的符号出栈
            i--;
        }
        
        
    }//end for
    
    while (!stk.empty()) {
        if(stk.top() != '('){
           cout<<stk.top()<<" ";
        }
        stk.pop();
    }

}

int calacPostExpress(string s){
    //给定一个后缀表达式  我们如何来计算 利用栈来存储数字
    stack<int> stk;
    for(int i = 0; i < s.size(); i++){
        
        if(isNum(s[i])){//如果当前符号为数字
            int tmp = 0;
            while (isNum(s[i])) {
                tmp = tmp * 10 + returnNum(s[i]);
                i++;
            }
            i--;
            stk.push(tmp);
        }
        
        if(isChar(s[i])){//如果当前符号是运算符  那么我们就在栈中弹出两个数字  运算后放回
            int num1 = stk.top();
            stk.pop();
            int num2 = stk.top();
            stk.pop();
            int tmp;
            switch (s[i]) {
                case '+':
                    tmp = num2 + num1;
                    break;
                case '-':
                    tmp = num2 - num1;
                    break;
                case '*':
                    tmp = num2 * num1;
                    break;
                case '/':
                    tmp = num2 / num1;
                    break;
                default:
                    break;
            }
            stk.push(tmp);
        }
    }//end for
    
    cout<<"The result of express is: "<<stk.top()<<endl;
    
    
    return 0;
}

int main(int argc, const char * argv[]) {
    
    string s;
    cout<<"Please enter your expression :" <<endl;
    
    getline(cin, s);
    
    In2PostExpression(s);
    
    string post;
    cout<<"\nPlease enter you post expression: "<<endl;
    getline(cin, post);
    calacPostExpress(post);
    cout<<endl;
    
    
   
    return 0;
    
    
    
    
}
 

