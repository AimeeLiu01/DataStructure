//
//  CalcExpression.cpp
//  Pre2Post
//
//  Created by 刘畅 on 2017/8/27.
//  Copyright © 2017年 刘畅. All rights reserved.
//  我们利用两个栈 直接计算表达式的值  这个时候我们一个栈用来存数字  另一个栈用来存运算符和括号

/*#include <stdio.h>
#include <iostream>
#include <string>
#include <stack>
using namespace std;

stack<int> numStack;
stack<char> chStack;

bool isNumber(char ch){
    if(ch >= '0' && ch <= '9'){
        return true;
    }
    else
        return false;
}

int returnNumber(char ch){
    
    return ch-'0';

}

bool isChar(char ch){
    if(ch == '+' || ch == '-' || ch == '/' || ch == '*')
        return true;
    else
        return false;
}

bool isHigh(char ch){//当前符号的优先级低于栈顶符号 那么我们让栈顶元素出栈
    
    
    if(ch == '*' && chStack.top() == '+'){
        return true;
    }
    if(ch == '*' && chStack.top() == '-'){
        return true;
    }
    if(ch == '/' && chStack.top() == '+'){
        return true;
    }
    if(ch == '/' && chStack.top() == '-'){
        return true;
    }
    return false;
    
}

void calc(){
    auto n = chStack.top();
    chStack.pop();//将这个运算符出栈
    int num1 = numStack.top();
    numStack.pop();
    int num2 = numStack.top();
    numStack.pop();
    
    int tmp;
    switch (n) {
        case '+':
            tmp = num2 + num1;
            break;
        case '-':
            tmp = num2 - num1;
            break;
        case '*':
            tmp = num2 * num1;
            break;
        case '/':
            tmp = num2 / num1;
            break;
        default:
            break;
    }
    numStack.push(tmp);
}


int calcExpression(string s){
    
    for(int i = 0; i < s.size(); i++){
        
        if(s[i] == '('){//如果是左括号 那么直接进栈

            chStack.push(s[i]);
        }
        else if(isNumber(s[i])){//如果是数字 我们将这个数提取出来  并且放入数字栈中
            int tmp = 0;
            while (isNumber(s[i])) {
                tmp = tmp * 10 + returnNumber(s[i]);
                i++;
            }
            i--;
            numStack.push(tmp);
        }
        
        else if(isChar(s[i]) && chStack.empty()){//如果是运算符且当前栈中为空 那么我们就入栈
            chStack.push(s[i]);
        }
        else if(isChar(s[i]) && chStack.top() == '('){//如果运算符栈顶元素为( 那么我们也直接入栈
            chStack.push(s[i]);
        }
        else if(isChar(s[i]) && isHigh(s[i])){//如果是运算符 且优先级高于栈顶元素  那么我们也直接入栈
            chStack.push(s[i]);
        }
        
        else if(isChar(s[i]) && !isHigh(s[i])){
            //是运算符 且优先级没有栈顶的元素高 我们就要先将栈顶的运算符出栈 进行计算
            calc();
            i--;//继续看当前运算符

            
        }
        else if(s[i] == ')'){
            calc();
            chStack.pop();//删除左括号
        }
        
    }//end for
    
    
    while (!chStack.empty()) {
        calc();
    }
    
    cout<<numStack.top()<<endl;
    
    return 0;
}

int main1(){
    
    string s;
    cout<<"Please enter your expression: "<<endl;
    getline(cin,s);
    calcExpression(s);
    return 0;
    
}*/
