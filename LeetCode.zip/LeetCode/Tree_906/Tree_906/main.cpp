//
//  main.cpp
//  Tree_906
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//
/*#include <iostream>
#include <stack>
#include <vector>
using namespace std;

struct TreeNode{
    
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
    
};

TreeNode* createTree(int arr[], int start, int length){
    
    if(arr[start] == -1)
        return NULL;
    
    TreeNode *root = new TreeNode(arr[start]);
    int left = 2 *  start + 1;
    int right = 2 * start + 2;
    if(left >= length){
        root->left = NULL;
    }
    else{
        root->left = createTree(arr, left, length);
    }
   
    
    if(right >= length){
        root->right = NULL;
    }
    else{
        root->right = createTree(arr, right, length);
    }
   
    return root;
    
}
void postOrder(TreeNode *root){
    if(root == NULL)
        return;
    postOrder(root->left);
    postOrder(root->right);
    cout<<root->val<<" ";
    
}
void printArray(int paths[], int pathLen){
    for(int i = 0; i < pathLen; i++){
        cout<<paths[i]<<" ";
    }
    cout<<endl;
}

void PrintRoadRecursive(TreeNode *root, int paths[], int pathLen, int sum){
    
    if(root == NULL)
        return;
    paths[pathLen] = root->val;
    pathLen++;
    sum -= root->val;

    if(root->left == NULL && root->right == NULL && sum == 0){
        printArray(paths, pathLen);
    }
    PrintRoadRecursive(root->left, paths, pathLen, sum);
    PrintRoadRecursive(root->right, paths, pathLen, sum);
    
}


void printAllRoads(TreeNode *root){
    
    int paths[100];
    PrintRoadRecursive(root, paths, 0, 10);
    
}

int main1(int argc, const char * argv[]) {
    int tree[7] = {1,2,3,-1,5,6,7};
    TreeNode *tmp = createTree(tree, 0, 7);
    postOrder(tmp);
    cout<<endl;
    printAllRoads(tmp);

   
    return 0;
    
}*/
