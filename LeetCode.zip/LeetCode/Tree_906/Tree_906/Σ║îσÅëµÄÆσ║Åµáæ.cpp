//
//  二叉排序树.cpp
//  Tree_906
//
//  Created by 刘畅 on 2017/9/6.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(nullptr),right(nullptr){}
};



void buildTree(TreeNode *root,int a)
{
    if(a<(root->val))
    {
        if((root->left) == NULL)
        {
            TreeNode* nr = new TreeNode(a);
            root->left = nr;
        }
        else
            buildTree(root->left,a);
    }
    else if(a>root->val)
    {
        if(root->right == NULL)
        {
            TreeNode* nr = new TreeNode(a);
            root->right = nr;
        }
        else
            buildTree(root->right,a);
    }
}


void InorderTraversal(TreeNode *root){
    if(root == NULL)
        return;
    InorderTraversal(root->left);
    cout<<root->val<<" ";
    InorderTraversal(root->right);
}

int main(){
    
    int n;
    cin>>n;
    int arr[100];
    for(int i = 0; i < n; i++){
        cin>>arr[i];
    }
   
    TreeNode *root = new TreeNode(arr[0]);
    for(int i = 1; i < n; i++){
        buildTree(root,arr[i]);
    }
    
    InorderTraversal(root);
    
    
        
    return 0;
    
}
