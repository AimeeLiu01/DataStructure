//
//  queue.cpp
//  Queue_class
//
//  Created by 刘畅 on 2017/8/23.
//  Copyright © 2017年 刘畅. All rights reserved.
//  Aimee's code of Queue

#include <stdio.h>
#include <iostream>
using namespace std;

template<class Type>
class Queue{
    
public:
    Queue(int size = 10){
        maxsize = size;
        frontIndex = 0;
        rearIndex = 0;
        que = new Type[maxsize+1];
    }
    bool isFull();
    bool isEmpty();
    void push(Type x);
    Type front();
    void pop();
    int getSize();
    
    
private:
    
    Type* que;
    int maxsize;
    int frontIndex;
    int rearIndex;
    
    
};


template<class Type>
bool Queue<Type>::isEmpty(){
    
    if(frontIndex == rearIndex){
        cout<<"The queue is empty."<<endl;
        return true;
    }
    else{
        cout<<"The queue is not empty."<<endl;
        return false;
    }
}

template<class Type>
bool Queue<Type>::isFull(){
    
    if(rearIndex == maxsize){
        cout<<"The queue is full."<<endl;
        return true;
    }
    else{
        cout<<"The queue is not full."<<endl;
        return false;
    }
}

template<class Type>
void Queue<Type>::push(Type x){
    
    if(rearIndex < maxsize){
      que[rearIndex] = x;
      rearIndex++;
    }
    else{
        cout<<"The queue is full, can't push element into it!"<<endl;
    }
    
}

template<class Type>
Type Queue<Type>::front(){
    
    if(rearIndex != frontIndex){
       return que[frontIndex];
    }
    else{
        return 0;
    }
}


template<class Type>
void Queue<Type>::pop(){
    frontIndex++;
}

template<class Type>
int Queue<Type>::getSize(){
    return rearIndex-frontIndex;
}

int main2(){
    Queue<int> q(10);
    q.isEmpty();
    q.isFull();
    q.push(3);
    q.push(5);
    q.push(8);
    q.push(1);
    q.push(6);
    q.push(4);
    cout<<q.front()<<endl;
    q.pop();
    q.push(5);
    cout<<q.getSize()<<endl;
    return 0;
   
    
    return 0;
    
    
}

