//
//  main.cpp
//  Queue_class
//
//  Created by 刘畅 on 2017/8/5.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include<string>
using namespace std;

template<class Type>
class Queue{
public:
    Queue(int size);
    bool isFull();
    bool isEmpty();
    void push(const Type& x);
    Type& front();
    void Delete();
    int getSize();
    
private:
    int maxSize;
    Type* que;
    Type frontIndex,rearIndex;
    
};

template<class Type>
Queue<Type>::Queue(int size) :maxSize(size){//队列的构造函数
    frontIndex = rearIndex = -1;
    que = new Type[size];
}

template<class Type>
bool Queue<Type>::isFull(){//队列是否满了
    
    if(frontIndex == maxSize-1)
        return true;
    else
        return false;
}

template<class Type>
bool Queue<Type>::isEmpty(){//队列是否为空
    
    if(frontIndex == rearIndex)
        return true;
    else
        return false;
}

template<class Type>
void Queue<Type>::push(const Type&x){//向队列中添加元素.从尾部加入
    que[++rearIndex] = x;
}

template<class Type>
Type& Queue<Type>::front(){//取出队列首元素的值
    return que[frontIndex+1];
}

template<class Type>
void Queue<Type>::Delete(){
    
    frontIndex++;
}

template<class Type>
int Queue<Type>::getSize(){
    return rearIndex-frontIndex;
}






int main1(int argc, const char * argv[]) {

    
    Queue<char> queue(10);
    queue.push('A');
    queue.push('B');
    queue.push('C');
    queue.push('D');
    queue.push('E');
    
    for(int i = 0; i < queue.getSize(); i++){
        cout<<queue.front()<<" ";
    }
    cout<<endl;
    cout<<"The que is empty?(1 is empty, 0 is notempty) : "<<queue.isEmpty()<<endl;//
    cout<<"The que's size is: "<<queue.getSize()<<endl;
    cout<<"The que's front element is : "<<queue.front()<<endl;
    queue.Delete();
    cout<<"After delete A, The que's front element is : "<<queue.front()<<endl;
    cout<<"Now the que's size is: "<<queue.getSize()<<endl;
    return 0;
    
    
    
    
    
    
    
    
    
    
}
