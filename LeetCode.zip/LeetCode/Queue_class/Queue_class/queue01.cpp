//
//  queue01.cpp
//  Queue_class
//
//  Created by 刘畅 on 2017/8/24.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <queue>
using namespace std;

int main(){
    queue<int> q;
    if(q.empty()){
        cout<<"The que is empty."<<endl;
    }
    q.push(3);
    q.push(5);
    q.push(8);
    q.push(1);
    q.push(6);
    q.push(4);
    cout<<q.front()<<endl;
    q.pop();
    q.push(5);
    cout<<q.size()<<endl;
    return 0;

}
