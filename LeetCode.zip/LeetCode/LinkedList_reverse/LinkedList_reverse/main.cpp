//
//  main.cpp
//  LinkedList_reverse
//
//  Created by 刘畅 on 2017/5/16.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace std;

struct ListNode {
         int val;
        ListNode *next;
         ListNode(int x) : val(x), next(NULL) {}
};

ListNode *reverse(ListNode *l){
    ListNode *pre = new ListNode(-1);
    
    ListNode *cur = NULL;
    while(l != NULL){
        
        cur = l->next;
        l->next = pre->next;
        pre->next = l;
        l = cur;
    }
    
    return pre->next;
}

int main(int argc, const char * argv[]) {
    
    ListNode *l1 = new ListNode(5);
    ListNode *l2 = new ListNode(4);
    ListNode *l3 = new ListNode(3);
    l1->next = l2;
    l2->next = l3;
    

    
}
