//
//  main.cpp
//  99. Recover Binary Search Tree
//
//  Created by 刘畅 on 2017/6/21.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
using namespace  std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(NULL),right(NULL){};
};

class Solution{
    TreeNode *first = NULL;
    TreeNode *second = NULL;
    TreeNode *pre = new TreeNode(INT_MIN);
public:
    void recoverTree(TreeNode *root){
        help(root);
        int tmp;
        tmp = first->val;
        first->val = second->val;
        second->val = tmp;
        
    }
    
    void help(TreeNode *root){
        
        if(root == NULL) return;
        help(root->left);
        if(first == NULL && pre->val >= root->val) first = pre;
        if(first != NULL && pre->val >= root->val) second = root;
        help(root->right);
        
    }
};
int main(int argc, const char * argv[]) {
    TreeNode *root = new TreeNode(4);
    TreeNode *t1 = new  TreeNode(2);
    TreeNode *t2 = new TreeNode(7);
    root->left = t1;
    root->right = t2;
    
    return 0;
}












