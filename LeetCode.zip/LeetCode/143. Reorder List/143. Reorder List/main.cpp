//
//  main.cpp
//  143. Reorder List
//
//  Created by 刘畅 on 2017/6/15.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;
struct ListNode{
    int val;
    ListNode *next;
    ListNode(int x) :val(x),next(NULL){}
};


class Solution{

public:
     void reorderList(ListNode *head) {
         
         if(!head || !head->next || !head->next->next) return;
         //第一步：利用快慢指针找到中点位置
         ListNode *slow = head;
         ListNode *fast = head;
         
         while(fast->next && fast->next->next){
             slow = slow->next;
             fast = fast->next->next;
         }
         ListNode *mid = slow->next;
         slow->next = NULL;
         
         //第二步：对mid之后的链表进行反转
         ListNode *pre = NULL;
         ListNode *cur = mid;
         
         while (cur) {
             ListNode *next = cur->next;
             cur->next = pre;
             pre = cur;
             cur= next;
         }
         
         ListNode *temp = head;
         //第三步：反转过后的后半段链表的头部结点为pre  那么我们对pre和head进行交叉合并
         while (head && pre) {
             ListNode *next = head->next;
             head->next = pre;
             pre = pre->next;
             head->next->next = next;
             head = next;
         }
         
         while (temp) {
             cout<<temp->val<<" ";
             temp = temp->next;
         }
         cout<<endl;
     }
};


int main(int argc, const char * argv[]) {
    
    ListNode *node1 = new ListNode(1);
    ListNode *node2 = new ListNode(2);
    ListNode *node3 = new ListNode(3);
    ListNode *node4 = new ListNode(4);
    ListNode *node5 = new ListNode(5);
    node1->next = node2;
    node2->next = node3;
    node3->next = node4;
    node4->next = node5;
    Solution s = *new Solution();
    s.reorderList(node1);
    
    return 0;
}













