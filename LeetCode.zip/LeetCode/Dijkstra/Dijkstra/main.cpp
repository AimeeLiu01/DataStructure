//
//  main.cpp
//  Dijkstra
//
//  Created by 刘畅 on 2017/8/20.
//  Copyright © 2017年 刘畅. All rights reserved.
/*
 最短路径算法
 Dijkstra(迪杰斯特拉)算法是典型的单源最短路径算法，用于计算一个节点到其他所有节点的最短路径。
 
 */


#include <iostream>
using namespace std;

const int maxnum = 100;
const int maxint = 999999;

//各数组下标都是从1开始的

// n -- n nodes
// v -- the source node
// dist[] -- the distance from the ith node to the source node
// prev[] -- the previous node of the ith node
// c[][] -- every two nodes' distance

void Dijkstra(int n, int v, int *dist, int *prev, int c[maxnum][maxnum]){
    
    bool s[maxnum];
    for(int i = 1; i <= n; i++)
    {
        dist[i] = c[v][i];
        s[i] = 0;
        if(dist[i] == maxint)
            prev[i] = 0;
        else
            prev[i] = v;
    }
    dist[v] = 0;
    s[v] = 1;
    
    // 依次将未放入S集合的结点中，取dist[]最小值的结点，放入结合S中
    // 一旦S包含了所有V中顶点，dist就记录了从源点到所有其他顶点之间的最短路径长度
    // 注意是从第二个节点开始，第一个为源点
    for(int i = 2; i <= n; i++){
        int tmp = maxint;
        int u = v;
        
        // 找出当前未使用的点j的dist[j]最小值
        for(int j=1; j<=n; j++){
            if((!s[j]) && dist[j]<tmp)
            {
                u = j;              // u保存当前邻接点中距离最小的点的号码
                tmp = dist[j];
            }
        }
        
        s[u] = 1;    // 表示u点已存入S集合中
        
        // 更新dist
        for(int j=1; j<=n; ++j){
            if((!s[j]) && c[u][j]<maxint)
            {
                int newdist = dist[u] + c[u][j];//经过U点后，距离变近了，那么就更新
                if(newdist < dist[j])
                {
                    dist[j] = newdist;
                    prev[j] = u;
                }
            }
        }
    }
}


//查找从源点v到终点u的路径，并输出
void searchPath(int *prev, int v,int u)
{
    int que[maxnum];
    int top = 1;
    que[top] = u;//代表到到达的节点  即路线中的最后一个顶点
    top++;//队列++
    int tmp = prev[u];// u的前一个结点
    while (tmp != v) {//当temp不为源点时
        que[top] = tmp;
        top++;
        tmp = prev[tmp];
    }
    que[top] = v;//代表的是源点  即已经找到了源点  路径中的结点已经全部找到
    
    for (int i = top; i >= 1; i--) {//将路径中的结点输出
        if(i != 1)
            cout<<que[i]<<"->";
        else
            cout<<que[i]<<endl;
    }
}



int main(int argc, const char * argv[]) {
    
    //各数组下标都是从1开始的
    int dist[maxnum];//表示当前点到源点的最短路径长度
    int prev[maxnum];// 记录当前点的前一个结点
    int c[maxnum][maxnum];//记录图的两点间路径长度
    int n,line;//图的结点数和路径数
    
    //输入结点数
    cin>>n;
    
    //输入路径数
    cin>>line;
    
    int p,q,len;// 输入p, q两点及其路径长度
    
    //初始化c[][]为maxint
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            c[i][j] = maxint;
        }
    }
    
    for(int i = 1; i <= line; i++){
        cin>>p>>q>>len;
        if(len < c[p][q]){//有重边
            c[p][q] = len; // p指向q
            c[q][p] = len; // q指向p，这样表示无向图
        }
    }
    
    for(int i=1; i<=n; i++)
        dist[i] = maxint;
    
    cout<<"由输入边构造的邻接矩阵为："<<endl;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            cout<<c[i][j]<<" ";
        }
        cout<<endl;
    }
    
    Dijkstra(n, 1, dist, prev, c);
    
    cout<<"\nAfter Dijkstra, the dist[i] are as follows: "<<endl;
    for(int i = 1; i <= n; i++){
        cout<<dist[i]<<" ";
    }
    cout<<endl;
    
    cout<<"\nAfter Dijkstra, The prev[i] are as followings: "<<endl;
    for(int i = 1; i <= n; i++){
        cout<<prev[i]<<" ";
    }
    cout<<"\n\n";
    
    
    

    for(int i = 2; i <= n; i++){
        cout<<"源点到第"<<i<<" 个顶点的最短路径长度为： "<<dist[i]<<endl;
        cout<<"源点到第"<<i<<" 个顶点的路径为： ";
        searchPath(prev, 1, i);
        cout<<endl;
    }
    

    return 0;
}
