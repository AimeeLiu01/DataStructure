//
//  main.cpp
//  84. Largest Rectangle in Histogram
//
//  Created by 刘畅 on 2017/6/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;

class Solution {
public:
   int largestRectangleArea(vector<int> &height) {
    
    if(height.empty()) return 0;
    stack<int> stk;
    int len = height.size();
    int maxArea = 0;
    
    for(int i = 0; i < len; i++){
        if(stk.empty() || stk.top() <= height[i])
            stk.push(height[i]);//满足升序排列
        
        else{//如果不满足升序的情况
            int count = 0;
            while(!stk.empty() && stk.top() > height[i]){//栈顶的元素大于当前的元素
                count++;//记录大于当前元素的个数
                maxArea = max(maxArea, stk.top()*count);//最大值进行更新
                stk.pop();//将其弹出
            }
            while(count--)//对于大于当前元素的个数
                stk.push(height[i]);//我们将每一个元素都替换成为当前元素
            stk.push(height[i]);//再把当前元素放入栈中
        }
    }
    
    int count = 1;
    while(!stk.empty()){
        maxArea = max(maxArea, stk.top()*count);//利用升序法再一次求面积  从右边看
        stk.pop();
        count++;
    }
    cout<<"The max is "<<maxArea<<endl;
    return maxArea;
  }
    
};

int main(int argc, const char * argv[]) {
    Solution s = *new Solution();
    vector<int> height;
    height.push_back(2);
    height.push_back(1);
    height.push_back(5);
    height.push_back(6);
    height.push_back(2);
    height.push_back(3);
    
    s.largestRectangleArea(height);
   
    return 0;
}




