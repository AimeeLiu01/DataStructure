//
//  main.cpp
//  KMP03
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;


int *fail = new int[100];


void setFail(string s){
    
    
    const char *sch = s.c_str();
    
   
    fail[0] = -1;
    for (int i = 1; i < s.size(); i++) {
        
        if (sch[i] == sch[fail[i-1]+1]) {
            fail[i] = fail[i-1]+1;
        }
        else
            fail[i] = -1;

    }
    
    for(int i = 0; i < s.size(); i++){
        cout<<fail[i]<<" ";
    }
    cout<<endl;
}


int main(int argc, const char * argv[]) {
    
    
    
    string str, substr;
    cout<<"Please enter your str:"<<endl;
    cin>>str;
    cout<<"Please enter your substr:"<<endl;
    cin>>substr;
    setFail(substr);
    
    
    int size = str.size();
    int subsize = substr.size();
    int i = 0;
    int j = 0;
    /*while (i < size && j < subsize) {
        
        if(str[i] == substr[j]){
            i++;
            j++;
        }
        else if(str[i] != substr[j]){
            if(fail[j] == -1){
                i++;
                j = 0;
            }
            else{
                j = fail[j];
            }
        }
    }*/
    while (i < size && j < subsize) {
        
        if(str[i] == substr[j]){
            i++;
            j++;
        }
        else{
            if(j == 0)//当子序列还在开头
                i++;
            else//否则的话  i不用移动位置  j移动位置即可
                j = fail[i-1] + 1;
        }
       
    }
    
    if(j == subsize){
        cout<< i - j + 1<<endl;
    }
    else{
        cout<<-1<<endl;
    }
    
    return 0;
    
    
}
