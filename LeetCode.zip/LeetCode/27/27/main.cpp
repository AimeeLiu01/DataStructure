//
//  main.cpp
//  27
//
//  Created by 刘畅 on 2017/8/27.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;


//输入一个句子（一行），将句子中的每一个单词翻转后输出。
int main1(int argc, const char * argv[]) {
    
    string s;
    getline(cin,s);
    
    for (int i = 0;  i < s.size(); i++) {
        
        int start = i;
        while (s[i] != ' ' && i < s.size()) {
            i++;
        }
        int end = i;
        
        for(int k = end-1; k >= start; k--){
            cout<<s[k];
        }
        cout<<" ";
    }
    cout<<endl;
    
    
    return 0;
    
}


//给定一棵二叉树的前序遍历和中序遍历的结果，求其后序遍历。
struct TreeNode{
    char val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(char c): val(c),left(nullptr),right(nullptr){}
    
};

TreeNode* PostExpression(string preExp, string inExp){
    
    if(preExp.size() == 0 && inExp.size() == 0){
        return nullptr;
    }
    TreeNode *root = new TreeNode(preExp[0]);
    
    int middle = 0;
    for(; middle < inExp.size(); middle++){
        if(inExp[middle] == root->val){
            break;
        }
    }
    
    root->left = PostExpression(preExp.substr(1,middle), inExp.substr(0,middle));
    root->right = PostExpression(preExp.substr(middle+1, preExp.size()-middle-1), inExp.substr(middle+1,inExp.size()-middle-1));
                                 
    
    
    return root;
}

void PostTraversal(TreeNode *root){
    
    if(root == NULL)
        return;
    PostTraversal(root->left);
    PostTraversal(root->right);
    cout<<root->val;
}

int main2(){
    
    string preExp;
    getline(cin,preExp);
    string inExp;
    getline(cin,inExp);
    TreeNode* root = PostExpression(preExp,inExp);
    PostTraversal(root);
    cout<<endl;
    return 0;
    
}

//3.判断是否有一条路径的和为给定值







