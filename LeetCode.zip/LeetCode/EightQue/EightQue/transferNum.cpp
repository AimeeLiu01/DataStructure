//
//  transferNum.cpp
//  EightQue
//
//  Created by 刘畅 on 2017/8/21.
//  Copyright © 2017年 刘畅. All rights reserved.
//  RUC's problem in the CampofSummer
//将任意一位数转化为任意进制的数字

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;


//将num转化成k进制的数
void transfer(int num, int k){
    
    const char ch[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
    char temp[100];
    
    int i = 0;
    while (num > 0) {
        int tm = num%k;//余数
        num = num/k;//除数
        temp[i] = ch[tm];
        i++;
    }
    
    int j = 0;
    while (temp[j] != '\0') {
        j++;
    }
    
    for(int k = j-1; k >= 0; k--){
        cout<<temp[k];
    }
    cout<<endl;
    
}

int main2(){
    int num,k;
    cin>>num>>k;
    transfer(num, k);
    return 0;
}

