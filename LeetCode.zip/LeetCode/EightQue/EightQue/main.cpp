//
//  main.cpp
//  EightQue
//
//  Created by 刘畅 on 2017/8/21.
//  Copyright © 2017年 刘畅. All rights reserved.


#include <iostream>
using namespace std;

int ans;
int vis[10];

bool check(int row, int col){
    
    for(int i = 1; i < row; i++){
        if(vis[i] == col)
            return false;
        if(row - i == col - vis[i] || i - row == col - vis[i])
            return false;
    }
    return true;
}

void dfs(int x){
    
    if(x > 8){
        ans++;
        for(int i = 1; i <= 8; i++){//控制行
            for(int j = 1; j <= 8; j++){//控制列
                if(vis[i] == j)
                    cout<<i<<" ";
                else
                    cout<<'-'<<" ";
            }
            cout<<endl;
        }//输出了一种结果
        
        cout<<endl;
        return;
    }
    
    for(int i = 1; i <= 8; i++){
        
        if(check(x,i)){
            vis[x] = i;//代表的是第X行的皇后坐在第i列
            dfs(x+1);//进行递归
            vis[x] = 0;
        }
    }
}

int main(){
    dfs(1);
    cout<<ans<<endl;
    for (int i = 0; i < 10; i++) {
        cout<<vis[i]<<" ";
    }
    return 0;
}




