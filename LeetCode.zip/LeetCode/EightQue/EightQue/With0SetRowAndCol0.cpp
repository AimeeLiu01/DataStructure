//
//  With0SetRowAndCol0.cpp
//  EightQue
//
//  Created by 刘畅 on 2017/8/21.
//  Copyright © 2017年 刘畅. All rights reserved.
//  输入一个二维数组  有0的行和列均置为0
//  setRowAndCol这个函数不仅需要传进来行和列的值，还要传入0所在的位置

#include <stdio.h>
#include <iostream>
using namespace std;

void setRowAndCol(int **maze, int row, int col, int x, int y){
    
    for(int i = 0; i < col; i++){
        maze[x][i] = 0;
    }
    
    for(int j = 0; j < row; j++){
        maze[j][y] = 0;
    }
    
}


int main1(){
    
    int row, col;
    cin>>row>>col;
    
    int **maze = new int*[row];
    for(int i = 0; i < row; i++){
        maze[i] = new int[col];
        for(int j = 0; j < col; j++){
            cin>>maze[i][j];
        }
    }
    
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            if(maze[i][j] == 0){
                maze[i][j] = -1;
            }
        }
    }
    
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            if(maze[i][j] == -1){
                setRowAndCol(maze,row,col,i,j);
            }
        }
    }
    
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            cout<<maze[i][j]<<" ";
        }
        cout<<endl;
    }
    
    
    
    return 0;
    
    
}
