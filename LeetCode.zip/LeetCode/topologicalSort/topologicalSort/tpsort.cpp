#include <iostream>
#include <stack>
using namespace std;

const int MAX_VERTEX_NUM = 30;//最大结点数
stack<int> s;

typedef struct ArcNode//边结点
{
    int adjvex;
    struct  ArcNode* next;
    ArcNode(){ next = 0; }
}ArcNode;

typedef struct VNode//点结点
{
    int data;
    ArcNode *first;
    VNode(){ first = 0; }
}VNode, AdjList[MAX_VERTEX_NUM];

typedef struct ALGraph
{
    AdjList vertices;
    int vexnum, arcnum;
}ALGraph;

ALGraph g;//用邻接矩阵表示的图
int indegree[MAX_VERTEX_NUM];

bool TopologicalSort(ALGraph G, int *indegree)
{
    int i, k;
    //入度为0入栈
    for (i = 1; i <= G.vexnum; ++i)
    {
        if (!indegree[i])
            s.push(i);
    }
    int count = 0;
    ArcNode *p;
    while (!s.empty())
    {
        i = s.top();
        s.pop();
        cout << G.vertices[i].data << "-->";
        count++;
        for (p = G.vertices[i].first; p; p = p->next)
        {
            k = p->adjvex;
            indegree[k]--;
            if (!indegree[k])
                s.push(k);
        }
    }
    if (count < G.vexnum)
    {
        return false;
    }
    return true;
}

int  main()
{
    cout << "请输入结点数和边数：";
    cin >> g.vexnum >> g.arcnum;
    //这里设置为第i个结点的data值为i i从一开始
    for (int i = 1; i <= g.vexnum; ++i)
        g.vertices[i].data = i;
    int b, e;
    ArcNode *p;
    
    cout << "分别输入边的顶点对 例如3 5" << endl;
    for (int i = 1; i <= g.arcnum; ++i)
    {
        cout << "第" << i << "条边";
        cin >> b >> e;
        p = new ArcNode();
        p->adjvex = e;
        p->next = g.vertices[b].first;
        g.vertices[b].first = p;
        indegree[e]++;
        cout << endl;
    }
    
    if (TopologicalSort(g, indegree))
        cout << "拓扑排序成功！" << endl;
    else
        cout << "该有向图有环" << endl;
    
    return  0;
}
