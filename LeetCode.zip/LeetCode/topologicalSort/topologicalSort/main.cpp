//
//  main.cpp
//  topologicalSort
//
//  Created by 刘畅 on 2017/8/22.
//  Copyright © 2017年 刘畅. All rights reserved.
//  拓扑排序朴素实现


#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

//邻接表的实现思路
#define maxn 100 //最大顶点个数
int n,m;  //顶点数，边数

struct arcnode{//边结点
    int vertex; //与表头结点相邻的顶点编号
    arcnode* next;//指向下一相邻结点
    arcnode() {}
    arcnode(int v):vertex(v),next(NULL){}
};

struct vernode{//顶点结点 为每一条邻接表的表头结点
    int vex;//当前顶点编号
    arcnode* firarc;//与该顶点相连的第一个顶点组成的边
}Ver[maxn];


void Init(){//建立图的邻接表要先初始化，建立顶点结点
    
    for (int i = 1; i <= n; i++) {
        
        Ver[i].vex = i;
        Ver[i].firarc = NULL;
    }
    
}

void Insert(int a,int b){//插入以a为起点 b为终点 无权的边
    
    arcnode* q = new arcnode(b);
    
    if(Ver[a].firarc == NULL)
        Ver[a].firarc = q;
    
    else{
        arcnode* p = Ver[a].firarc;
        while (p->next != NULL) {
            p = p->next;
        }
        p->next = q;
    }
}


/*
家谱树：类似与大学里的课程选修问题
有一个家族很大，辈分关系很乱，请你整理一下家族的关系，使得每个人的后辈都比那个人后列出
很明显，这是一个AOV网（顶点活动网络），整理后的序列即是一个拓扑序列，因此进行拓扑排序即可
*/

struct Info{//Info用于存储每个人的信息
    
    int num;//该节点的孩子结点数量
    int rudu;//该节点的入度值
    int child[101];//该节点的孩子节点
    Info(){
        num = 0;
        rudu = 0;
    }
    
};


Info people[101];



int main3(int argc, const char * argv[]) {
    
    
    
    int Number, p;//Number代表的是人数信息  p代表的是孩子信息
    cin>>Number;
    for (int i = 1; i <= Number; i++) {
        
        int tot = 0;
        cin>>p;
        while (p) {
            people[i].child[++tot] = p;//p是i节点的孩子
            people[i].num++;
            people[i].rudu++;
            cin>>p;
            
        }
    }
    
    //利用栈实现拓扑排序
    int Stack[101] = {0}, top = 0;
    for (int i = 1; i <= Number; i++) {//首先，将入度为0的节点全部入栈
        
        cout<<people[i].num<<" "<<people[i].rudu<<endl;
        if(people[i].rudu == 0)
            Stack[++top] = i;//将其入栈
    }
    
    while (top) {////当栈不为空的时候，循环操作（注意只有AOV网最终栈才会为0，否则可能会造成死循环）
        
        int temp = Stack[top];//首先栈顶元素出栈，并删除与该元素相连接的边（相当于该节点所有孩子节点的入度都减 1）
        cout<<temp<<" ";//输出当前栈顶元素
        top--;
        for(int i = 1; i <= people[temp].num; i++){//遍历该栈顶元素的孩子节点，入度均减 1
            
            people[people[temp].child[i]].rudu--;
            if(people[people[temp].child[i]].rudu==0)//如果孩子节点入度减1后，入度变成0了，该孩子节点入栈
            {
                Stack[++top] = people[temp].child[i];
            }
        }
    }
    
    
    //使用队列来模拟实现AOV网的拓扑排序
    int Que[101],head,tail;
    head=tail=1;
    for(int i=1;i<=Number;i++)
    {
        if(people[i].rudu==0) Que[tail++]=i;
    }
    while(head<tail)
    {
        int temp=Que[head];
        cout<<temp<<" ";
        head++;
        for(int i=1;i<=people[temp].num;i++)
        {
            people[people[temp].child[i]].rudu--;
            if(people[people[temp].child[i]].rudu==0)
                Que[tail++]=people[temp].child[i];
        }
    }
    
    
    
    return 0;
    
    
    
    
    

    
    
}
