//
//  main.cpp
//  PathOfTree829
//
//  Created by 刘畅 on 2017/8/29.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};


void printStack(stack<TreeNode*> stk){
    
    if(stk.empty())
        return;
    
    string res;
    while (!stk.empty()) {
        
        TreeNode *p = stk.top();
        res = to_string(p->val) + " " + res;
        stk.pop();
    }
    cout<<res<<endl;
}



void printAllRoad(TreeNode *root){
    
   
    stack<TreeNode*> stk;
    TreeNode *p = root;
    stk.push(p);//将首元素进栈
    TreeNode *visited = p;
    
    while (!stk.empty()) {
        
        p = stk.top();
        while(p->left){
            //入栈
            stk.push(p->left);
            //visited = p->left;//结点入栈 将其标记为visited
            //检查是不是叶结点
            if(p->left->left == NULL && p->left->right == NULL){
                printStack(stk);
                break;
            }
            p = p->left;
        }
        
        while (true) {
            
            p = stk.top();
            stk.pop();
            visited = p;//只要有结点出栈  那么将visited指向它
            
            if(stk.empty())
                break;
            
            p = stk.top();
            if(p->right != NULL && visited != p->right){
                
                while(p->right){
                    //入栈
                    stk.push(p->right);
                    visited = p->right;//结点入栈 指向入栈的点
                    //检查是不是叶结点
                    if(p->right->left == NULL && p->right->right == NULL){
                        printStack(stk);
                        break;
                    }
                    p = p->right;
                }

            }
        }
        
    
    }
    
}


int main1(int argc, const char * argv[]) {

    
    TreeNode *root = new TreeNode(1);
    
    TreeNode *n1 = new TreeNode(4);
    TreeNode *n2 = new TreeNode(5);
    TreeNode *n3 = new TreeNode(6);
    TreeNode *n4 = new TreeNode(7);
    TreeNode *n5 = new TreeNode(9);
    
    root->left = n1;
    root->right = n2;
    n1->left = n3;
    n1->right = n5;
    n2->right = n4;
    
    printAllRoad(root);
    

    
    return 0;
}
