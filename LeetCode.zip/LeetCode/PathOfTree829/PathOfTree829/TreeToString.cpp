//
//  TreeToString.cpp
//  PathOfTree829
//
//  Created by 刘畅 on 2017/8/29.
//  Copyright © 2017年 刘畅. All rights reserved.
//  给定一棵树  给出它的string表示  1(2(3)(4))(6)

#include <stdio.h>
#include <stack>
#include <string>
#include <iostream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};

void ToString(TreeNode *root){
    
    //string res;
    if(root == NULL)
        return;
    
    cout<<root->val;
    if(root->left || root->right){
        
        cout<<"(";
        ToString(root->left);
        cout<<")";
        
        if(root->right){
            cout<<"(";
            ToString(root->right);
            cout<<")";
        }
    }
    
}

int main(){
    
    TreeNode *root = new TreeNode(1);
    
    TreeNode *n1 = new TreeNode(4);
    TreeNode *n2 = new TreeNode(5);
    TreeNode *n3 = new TreeNode(6);
    TreeNode *n4 = new TreeNode(7);
    TreeNode *n5 = new TreeNode(9);
    
    root->left = n1;
    root->right = n2;
    n1->left = n3;
    n1->right = n5;
    n2->right = n4;
    
    
    ToString(root);
    cout<<endl;
    
    return 0;
    
    
}
