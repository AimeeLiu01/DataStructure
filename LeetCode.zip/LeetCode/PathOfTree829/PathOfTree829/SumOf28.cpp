//  SumOf28.cpp
//  PathOfTree829
//
//  Created by 刘畅 on 2017/8/29.
//  Copyright © 2017年 刘畅. All rights reserved.


#include <iostream>
#include <stack>
using namespace std;

struct TreeNode{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x): val(x),left(nullptr),right(nullptr){}
};


//打印栈中元素
void printStack(stack<TreeNode*> stk, int sum){
    
    if(stk.empty())
        return;
    
    int tmp = 0;
    string res;
    while (!stk.empty()) {
        
        TreeNode *p = stk.top();
        tmp += p->val;
        res = to_string(p->val) + " " + res;
        stk.pop();
        
    }
    
    if(tmp == sum)
        cout<<res<<endl;
    
}


//打印所有路径和为sum的路径
void printAllRoad(TreeNode *root, int sum){
    
    
    stack<TreeNode*> stk;
    TreeNode *p = root;
    stk.push(p);//将首元素进栈
    TreeNode *visited = p;
    
    while (!stk.empty()) {
        
        p = stk.top();
        while(p->left){
            //入栈
            stk.push(p->left);
            visited = p->left;//结点入栈 将其标记为visited
            //检查是不是叶结点
            if(p->left->left == NULL && p->left->right == NULL){
                printStack(stk,sum);
                break;//很重要  找到一条路径后就跳出循环  开始弹栈
            }
            p = p->left;
        }
        
        while (true) {
            
            p = stk.top();
            stk.pop();
            visited = p;//只要有结点出栈  那么将visited指向它
            
            if(stk.empty())
                break;
            
            p = stk.top();
            if(p->right != NULL && visited != p->right){
                
                while(p->right){
                    //入栈
                    stk.push(p->right);
                    visited = p->right;//结点入栈 指向入栈的点
                    //检查是不是叶结点
                    if(p->right->left == NULL && p->right->right == NULL){
                        printStack(stk,sum);
                        break;//很重要 找到右子路径时  跳出循环 进行弹栈操作
                    }
                    p = p->right;
                }
                
            }
        }
        
        
    }
    
}

//判断一棵树是否有路径的和为sum
bool isSumOfNum(TreeNode* root, int sum){
    
    if(root->val == sum && root->left == NULL && root->right == NULL)
        return true;
    return isSumOfNum(root->left, sum-root->val);
    return isSumOfNum(root->right, sum-root->val);
    
    
}


/************************************************************************/
//给定一个序列转化为树
TreeNode* stringToTree(string s,int start){
    
    int rootNum = s.at(start)-'0';
    TreeNode *root = new TreeNode(rootNum);
    
    if(start* 2 + 1 < s.length() && s.at(start*2+1) != '#'){
        root->left = stringToTree(s, start*2+1);
    }
    else
        root->left = nullptr;
    
    if(start* 2 + 2 < s.length() && s.at(start*2+2) != '#'){
        root->right = stringToTree(s, start*2+2);
    }
    else
        root->right = nullptr;
    
    return root;
    
}

//中序打印这棵树
void PostOrderTraversal(TreeNode *root){
    
    if(root == NULL)
        return;
    PostOrderTraversal(root->left);
    cout<<root->val<<" ";
    PostOrderTraversal(root->right);
    
}

/******************************************************************/
//根据用户输入的数据 生成一棵树
TreeNode* ArrayToTree(int a[], int start,int size){
    
    TreeNode *root = new TreeNode(a[start]);
    int left = start*2 + 1;
    int right = start*2 + 2;
    if(left < size && a[left] != -1){
        root->left = ArrayToTree(a, left, size);
    }
    else{
        root->left = NULL;
    }
    
    if(right < size && a[right] != -1){
        root->right = ArrayToTree(a, right, size);
    }
    else{
        root->right = NULL;
    }
    return root;
   
}

void createTree(){
    
    int num[100];
    int tmp;
    int i = 0;
    cout<<"Please enter you number(-999 to end):"<<endl;
    while (cin>>tmp && tmp != -999) {
        num[i] = tmp;
        i++;
    }
    
    int size = i;
    TreeNode *root = ArrayToTree(num, 0, size);
    cout<<"Post order is :"<<endl;
    PostOrderTraversal(root);
    cout<<endl;
}
/**************************************************************************/

int main2(int argc, const char * argv[]) {
    
    
    TreeNode *root = new TreeNode(1);
    
    TreeNode *n1 = new TreeNode(4);
    TreeNode *n2 = new TreeNode(5);
    TreeNode *n3 = new TreeNode(6);
    TreeNode *n4 = new TreeNode(7);
    TreeNode *n5 = new TreeNode(9);
    
    //root->left = n1;
    root->right = n2;
    n1->left = n3;
    n1->right = n5;
    n2->right = n4;
    
    if(isSumOfNum(root, 11)){
        cout<<"Yes"<<endl;
    }
    else{
        cout<<"False"<<endl;
    }
    
    printAllRoad(root,11);
    
    
    string str;
    cout<<"Please enter your strings :"<<endl;
    getline(cin,str);
    
    
    TreeNode* tmp = stringToTree(str, 0);
    cout<<"Post order is: "<<endl;
    PostOrderTraversal(tmp);
    cout<<endl;
    
    createTree();
    return 0;
}
