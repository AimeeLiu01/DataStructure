//
//  main.cpp
//  test123
//
//  Created by 刘畅 on 2017/8/27.
//  Copyright © 2017年 刘畅. All rights reserved.
//  百练 / 2017计算机学科夏令营上机考试 已经结束

#include <iostream>
#include <string>
#include <stack>

using namespace std;


//B:编码字符串
/*int main(int argc, const char * argv[]) {
    
    string s;
    cin>>s;
    
  

    int i;
    for(i = 0; i < s.size(); i++){
        
        char ch = tolower(s[i]);
        int count = 1;
        
        while (1) {
            while(tolower(s[++i]) == ch){
                ++count;
            }
            i--;
            cout<<'('<<ch<<','<<count<<')';
            break;
            
        }
        
    }
    cout<<endl;
  
    
    return 0;
}*/


//A:判决素数个数
/*int main(){
    
    int num1,num2;
    cin>>num1>>num2;
    int count = 0;
    int i,j;
    for(i = num1; i <= num2; i++){
        for(j = 2; j < i; j++){
            if(i % j == 0){
                break;
            }
        }
        if(j == 1)
           count++;
        
        if(j == i)
           count++;
    }
    
    cout<<count<<endl;
    return 0;
}*/



//C:岛屿面积  求的是1的个数
/*int main(){
    
    int count = 0;//代表有多少个1
    int row,col;
    cin>>row>>col;
    int **island;
    bool **visited;
    int dirX[] = {0,1,0,-1};
    int dirY[] = {1,0,-1,0};
    
    stack<pair<int, int>> stk;
    
    island = new int*[row];
    for(int i = 0; i < row; i++){
        island[i] = new int[col];
        for(int j = 0; j < col; j++){
            cin>>island[i][j];
        }
    }
    
    visited = new bool*[row];
    for(int i = 0; i < row; i++){
        visited[i] = new bool[col];
        for(int j = 0; j < col; j++){
            visited[i][j] = false;
        }
    }
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
        
            if(island[i][j] == 1 && visited[i][j] == false){
                stk.push(make_pair(i, j));
                ++count;//标记个数
                visited[i][j] = true;//标记为已访问
                
                while (!stk.empty()) {
                    
                    auto n = stk.top();
                    stk.pop();
                    int x = n.first;
                    int y = n.second;
                    for (int k = 0; k < 4; k++) {
                        int xx = x + dirX[k];
                        int yy = y + dirY[k];
                        //做一个安全检测 检查是否越界
                        if(xx < 0 || xx >= row || yy < 0 || yy >= row)
                            continue;
                        
                        if(island[xx][yy] == 1 && visited[xx][yy] == false){
                            stk.push(make_pair(xx, yy));
                            ++count;
                            visited[xx][yy] = true;
                        }
                    }
                    
                    
                }
                
            }
            
        }
    }
    cout<<"count = "<<count<<endl;
    
    if(count == 1){
        cout<<4<<endl;
    }
    else if(count > 1){
        cout<<2*count + 2<<endl;
    }
    else
        cout<<0<<endl;
    return 0;
    
}*/

//下面我们求一共多少个岛屿  连在一起的称做小岛
int main(){
    
    int count = 0;
    
    int row,col;
    cin>>row>>col;
    int **island;
    bool **visited;
    int dirX[] = {0,1,0,-1};
    int dirY[] = {1,0,-1,0};
    
    stack<pair<int, int>> stk;
    
    //初始化二维数组
    island = new int*[row];
    for(int i = 0; i < row; i++){
        island[i] = new int[col];
        for(int j = 0; j < col; j++){
            cin>>island[i][j];
        }
    }
    
    //初始化访问二维数组
    visited = new bool*[row];
    for(int i = 0; i < row; i++){
        visited[i] = new bool[col];
        for(int j = 0; j < col; j++){
            visited[i][j] = false;
        }
    }
    
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            
            if(island[i][j] == 1 && visited[i][j] == false){
                stk.push(make_pair(i, j));
                ++count;//标记个数  代表的是小岛的个数
                visited[i][j] = true;//标记为已访问
                
                while (!stk.empty()) {
                    
                    auto n = stk.top();
                    stk.pop();
                    int x = n.first;
                    int y = n.second;
                    for (int k = 0; k < 4; k++) {
                        int xx = x + dirX[k];
                        int yy = y + dirY[k];
                        //做一个安全检测 检查是否越界
                        if(xx < 0 || xx >= row || yy < 0 || yy >= row)
                            continue;
                        
                        if(island[xx][yy] == 1 && visited[xx][yy] == false){
                            stk.push(make_pair(xx, yy));
                            //++count;
                            visited[xx][yy] = true;
                        }
                    }
                    
                    
                }
                
            }
            
        }
    }
    cout<<"count = "<<count<<endl;
    
    if(count == 1){
        cout<<4<<endl;
    }
    else if(count > 1){
        cout<<2*count + 2<<endl;
    }
    else
        cout<<0<<endl;
    return 0;
    
}




