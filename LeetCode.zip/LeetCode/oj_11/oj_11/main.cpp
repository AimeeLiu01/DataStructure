//
//  main.cpp
//  oj_11
//
//  Created by 刘畅 on 2017/7/13.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <strstream>

using namespace std;

int main(int argc, const char * argv[]) {
   
    
    char cStr[50] = "12 34 65 -23 33 61 99 321 32";
    int nArray[10];
    cout<<cStr<<endl;
    
    istrstream strin(cStr, sizeof(cStr));
    int i, temp;
    for(int i = 0; i < 10; i++){
        strin >> nArray[i];
    }
    
    for(int i = 0; i < 9; i++)
        cout<<nArray[i]<<" ";
    cout<<endl;
    
    
    return 0;
}
