//
//  main.cpp
//  904test
//
//  Created by 刘畅 on 2017/9/4.
//  Copyright © 2017年 刘畅. All rights reserved.
//

#include <iostream>
#include <fstream>
using namespace std;

//1.写一句话到文件中
void writeOneLine(){
    ofstream fout;
    fout.open("/Users/liuchang/Desktop/904.txt");
    fout<<"Hello Liuchang. I wish everyone here have a bright future."<<endl;
    fout.close();
}

//2. 将字母表写进文件中去
void write26CharToFile(){
    
    ofstream fout;
    fout.open("/Users/liuchang/Desktop/90402.txt");
    char a = 'a';
    int count = 1;
    for( ; a<='z'; a++){
        fout<<count<<" "<<a<<endl;
        count++;
    }
    fout.close();
}

//3. 逐字符的读取文件
void readFromFile(){
    
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/90402.txt");
    char tmp;
    while (icin>>tmp) {
        cout<<tmp<<" ";
    }
    cout<<endl;
    return;
}

//4.逐行读取文件
void readFromFileByLine(){
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/90402.txt");
    char temp[100];
    while (icin.getline(temp,100,'\n')) {
        cout<<temp<<endl;
        
    }
    return;
}

//5.逐取文件中的某一行的内容
void readFromFileByLineOfN(int n){
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/90402.txt");
    char temp[100];
    int num = 1;
    while (num < n) {
        ++num;
        icin.getline(temp, 100);
    }
    icin.getline(temp, 100);
    cout<<num<<"行:"<<temp;
    cout<<endl;

}

//6. 如何统计文本的行数
void CountLine(){
    ifstream icin;
    icin.open("/Users/liuchang/Desktop/90402.txt");
    char temp[100];
    int num = 0;
    while (icin.getline(temp, 100)) {
        num++;
    }
    cout<<"一共有:"<<num<<"行"<<endl;

}

int main(int argc, const char * argv[]) {
    
    writeOneLine();
    write26CharToFile();
    readFromFile();
    readFromFileByLine();
    readFromFileByLineOfN(4);
    CountLine();
    return 0;
   
   
    
}
